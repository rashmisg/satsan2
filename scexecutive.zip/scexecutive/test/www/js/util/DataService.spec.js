describe('The DataService utility', function() {
    describe('The buildCognosUrl function', function() {
        var pageUuid = Jda.SCExecutive.util.AppContext.getPageUuid();
        var previousIsDemoMode;
        var buildDataServiceUrlSpy;

        beforeEach(function() {
            previousIsDemoMode = Jda.SCExecutive.util.DataService.isDemoMode;
            Jda.SCExecutive.util.DataService.isDemoMode = false;

            buildDataServiceUrlStub = sinon.stub(Jda, 'buildDataServiceUrl');
        });

        afterEach(function() {
            Jda.SCExecutive.util.DataService.isDemoMode = previousIsDemoMode;

            buildDataServiceUrlStub.restore();
        });

        var getLastBean = function() {
            return buildDataServiceUrlStub.lastCall.args[1];
        };

        var getLastParams = function() {
            return buildDataServiceUrlStub.lastCall.args[2];
        };

        var report = Ext.create('Jda.SCExecutive.model.CognosReport', {
            reportName: 'Foo',
            reportFolder: 'Bar'
        });

        // test input parameters
        var rootPeriod = Ext.create('Jda.SCExecutive.model.PeriodHierarchy', {
            isRoot: true
        });
        var firstLevelPeriod = Ext.create('Jda.SCExecutive.model.PeriodHierarchy', {
            parent: rootPeriod,
            value: '2013',
            type: Jda.SCExecutive.model.PeriodHierarchy.types.YEAR
        });
        var secondLevelPeriod = Ext.create('Jda.SCExecutive.model.PeriodHierarchy', {
            parent: firstLevelPeriod,
            value: '2013-Q1',
            type: Jda.SCExecutive.model.PeriodHierarchy.types.QUARTER
        });

        var rootLocation = Ext.create('Jda.SCExecutive.model.LocationHierarchy', {
            isRoot: true
        });
        var firstLevelLocation = Ext.create('Jda.SCExecutive.model.LocationHierarchy', {
            parent: rootLocation,
            code: 'USA',
            level: 'Country'
        });
        var secondLevelLocation = Ext.create('Jda.SCExecutive.model.LocationHierarchy', {
            parent: firstLevelLocation,
            code: 'North',
            level: 'Region'
        });

        // TODO probably move this
        it('Should include the DataSet format param by default', function() {
            Jda.SCExecutive.util.DataService.buildCognosUrl(report);

            getLastParams().should.eql({ fmt: 'DataSet', uuid: pageUuid });

        });

        it('Should use the report\'s bean path', function() {
            Jda.SCExecutive.util.DataService.buildCognosUrl(report);

            getLastBean().should.equal(report.getBeanPath());
        });

        it('Should include the location tree when one is provided', function() {
            var config = {
                locationHierarchy: secondLevelLocation
            };

            Jda.SCExecutive.util.DataService.buildCognosUrl(report, config);

            getLastParams().should.eql({ fmt: 'DataSet', uuid: pageUuid, p_Country: 'USA', p_Region: 'North' });
        });

        it('Should include the period tree when one is provided', function() {
            var config = {
                periodHierarchy: secondLevelPeriod
            };

            var url = Jda.SCExecutive.util.DataService.buildCognosUrl(report, config);

            getLastParams().should.eql({ fmt: 'DataSet', uuid: pageUuid, p_Year: '2013', p_Quarter: '2013-Q1' });
        });

        it('Should include both the location and period hierarchy when provided', function() {
            var config = {
                locationHierarchy: secondLevelLocation,
                periodHierarchy: secondLevelPeriod
            };

            Jda.SCExecutive.util.DataService.buildCognosUrl(report, config);

            getLastParams().should.eql({ fmt: 'DataSet', uuid: pageUuid, p_Country: 'USA', p_Region: 'North', p_Year: '2013', p_Quarter: '2013-Q1' });
        });

        it('Should build demo data urls that point to the file system', function() {
            Jda.SCExecutive.util.DataService.isDemoMode = true;

            var config = {
                locationHierarchy: secondLevelLocation,
                periodHierarchy: secondLevelPeriod
            };

            var url = Jda.SCExecutive.util.DataService.buildCognosUrl(report, config);

            url.should.equal('./resources/data/Foo/Foo-Country-USA-Region-North-Year-2013-Quarter-2013-Q1.json');
        });

        // once we have test cases specifically for the these reports, the following couple of tests should probably be moved
        it('Should build a custom url for the location hierarchy report', function() {
            var locationHierarchyReport = Ext.create('Jda.SCExecutive.model.LocationHierarchyReport');
            var expectedBeanPath = "metadataXml/rds/outputFormat/searchPath/content/folder[@name='JDABA']/folder[@name='Template%20Reports']/folder[@name='SCExec%20Analytics%208.2']/folder[@name='Interface']/folder[@name='Hierarchy']/report[@name='Location_Hierarchy']/XML";

            Jda.SCExecutive.util.DataService.buildCognosUrl(locationHierarchyReport);

            getLastParams().should.eql({ version: 'LATEST' });
            getLastBean().should.equal(locationHierarchyReport.getBeanPath());
            expectedBeanPath.should.equal(locationHierarchyReport.getBeanPath());
        });

        it('Should build a custom url for the period hierarchy report', function() {
            var periodHierarchyReport = Ext.create('Jda.SCExecutive.model.PeriodHierarchyReport');
            var expectedBeanPath = "metadataXml/rds/outputFormat/searchPath/content/folder[@name='JDABA']/folder[@name='Template%20Reports']/folder[@name='SCExec%20Analytics%208.2']/folder[@name='Interface']/folder[@name='Hierarchy']/report[@name='Period_Hierarchy']/XML";

            Jda.SCExecutive.util.DataService.buildCognosUrl(periodHierarchyReport);

            getLastParams().should.eql({ version: 'LATEST' });
            getLastBean().should.equal(periodHierarchyReport.getBeanPath());
            expectedBeanPath.should.equal(periodHierarchyReport.getBeanPath());
        });
    });
});
