describe('The Metric Formatter', function() {

    var savedCulture, savedCurrency;

    // Save off culture and currency
    before(function() {
        savedCulture = Globalize.culture();
        savedCurrency = Jda.SCExecutive.util.Formatters.MetricFormatter.getCorporateCurrencyRegionSymbol();
    });

    // Restore culture and currency
    after(function() {
        Globalize.culture(savedCulture);
        Jda.SCExecutive.util.Formatters.MetricFormatter.setCorporateCurrencyRegionSymbol(savedCurrency);
    });

    describe('The formatNumber function', function() {
        it('Should trim to precision properly', function() {
            var base = 1.23456,
                lowExpectations = '1',
                mediumExpectations = '1.23',
                highExpectations = '1.2345',
                formatter = Jda.SCExecutive.util.Formatters.MetricFormatter,
                precisions = Jda.SCExecutive.constant.Precision;

            var lowObserved = formatter.formatNumber(base, precisions.Low);
            var mediumObserved = formatter.formatNumber(base, precisions.Medium);
            var highObserved = formatter.formatNumber(base, precisions.High);

            lowObserved.should.equal(lowExpectations);
            mediumObserved.should.equal(mediumExpectations);
            highObserved.should.equal(highExpectations);
        });

        it('Should not round at any precision level', function() {
            var base = 9.999999,
                lowExpectations = '9',
                mediumExpectations = '9.99',
                highExpectations = '9.9999',
                formatter = Jda.SCExecutive.util.Formatters.MetricFormatter,
                precisions = Jda.SCExecutive.constant.Precision;

            var lowObserved = formatter.formatNumber(base, precisions.Low);
            var mediumObserved = formatter.formatNumber(base, precisions.Medium);
            var highObserved = formatter.formatNumber(base, precisions.High);

            lowObserved.should.equal(lowExpectations);
            mediumObserved.should.equal(mediumExpectations);
            highObserved.should.equal(highExpectations);
        });

        it('Should trim trailing zeroes by default', function() {
            var base = 3406420,
                lowExpectations = '3M',
                mediumExpectations = '3.4M',
                highExpectations = '3.4064M',
                formatter = Jda.SCExecutive.util.Formatters.MetricFormatter,
                precisions = Jda.SCExecutive.constant.Precision;

            var lowObserved = formatter.formatNumber(base, precisions.Low);
            var mediumObserved = formatter.formatNumber(base, precisions.Medium);
            var highObserved = formatter.formatNumber(base, precisions.High);

            lowObserved.should.equal(lowExpectations);
            mediumObserved.should.equal(mediumExpectations);
            highObserved.should.equal(highExpectations);
        });

        it('Should not trim trailing zeroes on a whole number', function() {
            var base = 30406420,
                lowExpectations = '30M',
                mediumExpectations = '30.4M',
                highExpectations = '30.4064M',
                formatter = Jda.SCExecutive.util.Formatters.MetricFormatter,
                precisions = Jda.SCExecutive.constant.Precision;

            var lowObserved = formatter.formatNumber(base, precisions.Low);
            var mediumObserved = formatter.formatNumber(base, precisions.Medium);
            var highObserved = formatter.formatNumber(base, precisions.High);

            lowObserved.should.equal(lowExpectations);
            mediumObserved.should.equal(mediumExpectations);
            highObserved.should.equal(highExpectations);
        });

        it('Should pad zeroes up to precision when desired', function() {
            var base = 1.1,
                lowExpectations = '1',
                mediumExpectations = '1.10',
                highExpectations = '1.1000',
                formatter = Jda.SCExecutive.util.Formatters.MetricFormatter,
                precisions = Jda.SCExecutive.constant.Precision;

            var lowObserved = formatter.formatNumber(base, precisions.Low, true);
            var mediumObserved = formatter.formatNumber(base, precisions.Medium, true);
            var highObserved = formatter.formatNumber(base, precisions.High, true);

            lowObserved.should.equal(lowExpectations);
            mediumObserved.should.equal(mediumExpectations);
            highObserved.should.equal(highExpectations);
        });

        it('Should suffix numbers > 999 with a K', function() {
            var val = 1000,
                expected = '1K';

            var observed = Jda.SCExecutive.util.Formatters.MetricFormatter.formatNumber(val);

            observed.should.equal(expected);
        });

        it('Should suffix numbers > 999,999 with a M', function() {
            var val = 1000000,
                expected = '1M';

            var observed = Jda.SCExecutive.util.Formatters.MetricFormatter.formatNumber(val);

            observed.should.equal(expected);
        });

        it('Should suffix numbers > 999,999,999 with a B', function() {
            var val = 1000000000,
                expected = '1B';

            var observed = Jda.SCExecutive.util.Formatters.MetricFormatter.formatNumber(val);

            observed.should.equal(expected);
        });

        it('Should suffix numbers > 9999,999,999,999 with a T', function() {
            var val = 1000000000000,
                expected = '1T';

            var observed = Jda.SCExecutive.util.Formatters.MetricFormatter.formatNumber(val);

            observed.should.equal(expected);
        });

        it('Should trim suffixed numbers with the same rules as non-suffixed numbers', function() {
            var valNoPadding = 12345,
                valWithPadding = 12000,
                expectedNoPadding = '12.34K',
                expectedWithPadding = '12.00K',
                formatter = Jda.SCExecutive.util.Formatters.MetricFormatter,
                precision = Jda.SCExecutive.constant.Precision.Medium;

            var observedNoPadding = formatter.formatNumber(valNoPadding, precision);
            var observedWithPadding = formatter.formatNumber(valWithPadding, precision, true);

            observedNoPadding.should.equal(expectedNoPadding);
            observedWithPadding.should.equal(expectedWithPadding);
        });

        it('Should use proper decimal separator for culture', function() {
            Globalize.culture('de');

            var value = 5.45,
                expected = '5,45',
                formatter = Jda.SCExecutive.util.Formatters.MetricFormatter;

            var observed = formatter.formatNumber(value);

            observed.should.equal(expected);

            Globalize.culture('en');

            expected = '5.45';

            observed = formatter.formatNumber(value);

            observed.should.equal(expected);
        });
    });

    describe('The formatCurrency function', function() {
        it('Should trim to precision properly', function() {
            var base = 1.23456,
                lowExpectations = '$1',
                mediumExpectations = '$1.23',
                highExpectations = '$1.2345',
                formatter = Jda.SCExecutive.util.Formatters.MetricFormatter,
                precisions = Jda.SCExecutive.constant.Precision;

            var lowObserved = formatter.formatCurrency(base, precisions.Low);
            var mediumObserved = formatter.formatCurrency(base, precisions.Medium);
            var highObserved = formatter.formatCurrency(base, precisions.High);

            lowObserved.should.equal(lowExpectations);
            mediumObserved.should.equal(mediumExpectations);
            highObserved.should.equal(highExpectations);
        });

        it('Should not round at any precision level', function() {
            var base = 9.999999,
                lowExpectations = '$9',
                mediumExpectations = '$9.99',
                highExpectations = '$9.9999',
                formatter = Jda.SCExecutive.util.Formatters.MetricFormatter,
                precisions = Jda.SCExecutive.constant.Precision;

            var lowObserved = formatter.formatCurrency(base, precisions.Low);
            var mediumObserved = formatter.formatCurrency(base, precisions.Medium);
            var highObserved = formatter.formatCurrency(base, precisions.High);

            lowObserved.should.equal(lowExpectations);
            mediumObserved.should.equal(mediumExpectations);
            highObserved.should.equal(highExpectations);
        });

        it('Should trim trailing zeroes by default', function() {
            var base = 3406420,
                lowExpectations = '$3M',
                mediumExpectations = '$3.4M',
                highExpectations = '$3.4064M',
                formatter = Jda.SCExecutive.util.Formatters.MetricFormatter,
                precisions = Jda.SCExecutive.constant.Precision;

            var lowObserved = formatter.formatCurrency(base, precisions.Low);
            var mediumObserved = formatter.formatCurrency(base, precisions.Medium);
            var highObserved = formatter.formatCurrency(base, precisions.High);

            lowObserved.should.equal(lowExpectations);
            mediumObserved.should.equal(mediumExpectations);
            highObserved.should.equal(highExpectations);
        });

        it('Should not trim trailing zeroes on a whole number', function() {
            var base = 30406420,
                lowExpectations = '$30M',
                mediumExpectations = '$30.4M',
                highExpectations = '$30.4064M',
                formatter = Jda.SCExecutive.util.Formatters.MetricFormatter,
                precisions = Jda.SCExecutive.constant.Precision;

            var lowObserved = formatter.formatCurrency(base, precisions.Low);
            var mediumObserved = formatter.formatCurrency(base, precisions.Medium);
            var highObserved = formatter.formatCurrency(base, precisions.High);

            lowObserved.should.equal(lowExpectations);
            mediumObserved.should.equal(mediumExpectations);
            highObserved.should.equal(highExpectations);
        });

        it('Should pad zeroes up to precision when desired', function() {
            var base = 1.1,
                lowExpectations = '$1',
                mediumExpectations = '$1.10',
                highExpectations = '$1.1000',
                formatter = Jda.SCExecutive.util.Formatters.MetricFormatter,
                precisions = Jda.SCExecutive.constant.Precision;

            var lowObserved = formatter.formatCurrency(base, precisions.Low, true);
            var mediumObserved = formatter.formatCurrency(base, precisions.Medium, true);
            var highObserved = formatter.formatCurrency(base, precisions.High, true);

            lowObserved.should.equal(lowExpectations);
            mediumObserved.should.equal(mediumExpectations);
            highObserved.should.equal(highExpectations);
        });

        it('Should suffix numbers > 9,999 with a K', function() {
            var val = 10000,
                expected = '$10K';

            var observed = Jda.SCExecutive.util.Formatters.MetricFormatter.formatCurrency(val);

            observed.should.equal(expected);
        });

        it('Should suffix numbers > 999,999 with a M', function() {
            var val = 1000000,
                expected = '$1M';

            var observed = Jda.SCExecutive.util.Formatters.MetricFormatter.formatCurrency(val);

            observed.should.equal(expected);
        });

        it('Should suffix numbers > 999,999,999 with a B', function() {
            var val = 1000000000,
                expected = '$1B';

            var observed = Jda.SCExecutive.util.Formatters.MetricFormatter.formatCurrency(val);

            observed.should.equal(expected);
        });

        it('Should suffix numbers > 9999,999,999,999 with a T', function() {
            var val = 1000000000000,
                expected = '$1T';

            var observed = Jda.SCExecutive.util.Formatters.MetricFormatter.formatCurrency(val);

            observed.should.equal(expected);
        });

        it('Should trim suffixed numbers with the same rules as non-suffixed numbers', function() {
            var valNoPadding = 12345,
                valWithPadding = 12000,
                expectedNoPadding = '$12.34K',
                expectedWithPadding = '$12.00K',
                formatter = Jda.SCExecutive.util.Formatters.MetricFormatter,
                precision = Jda.SCExecutive.constant.Precision.Medium;

            var observedNoPadding = formatter.formatCurrency(valNoPadding, precision);
            var observedWithPadding = formatter.formatCurrency(valWithPadding, precision, true);

            observedNoPadding.should.equal(expectedNoPadding);
            observedWithPadding.should.equal(expectedWithPadding);
        });

        it('Should put negative sign before currency symbol', function() {
            var val = -5,
                formatter = Jda.SCExecutive.util.Formatters.MetricFormatter,
                expected = '-$5';

            var observed = formatter.formatCurrency(val);

            observed.should.equal(expected);
        });

        it('Should put use the correct currency symbol for the corporate locale, and always place in front, regardless of locale standard', function() {
            var val = -5,
                formatter = Jda.SCExecutive.util.Formatters.MetricFormatter,
                expected = '-€5';

            formatter.setCorporateCurrencyRegionSymbol('€');

            var observed = formatter.formatCurrency(val);

            observed.should.equal(expected);
        });

        it('Should use proper decimal separator for culture, regardless of corporate currency', function() {
            var value = 5.45,
                formatter = Jda.SCExecutive.util.Formatters.MetricFormatter;

            // Test that euro signs are used, but user format preference is preserved
            formatter.setCorporateCurrencyRegionSymbol('€');
            Globalize.culture('de');

            var expected = '€5,45';
            var observed = formatter.formatCurrency(value);
            observed.should.equal(expected);

            Globalize.culture('en');

            expected = '€5.45';
            observed = formatter.formatCurrency(value);
            observed.should.equal(expected);

            // Test that dollar signs are used, but user format preference is preserved
            formatter.setCorporateCurrencyRegionSymbol('$');
            Globalize.culture('de');

            expected = '$5,45';
            observed = formatter.formatCurrency(value);
            observed.should.equal(expected);

            Globalize.culture('en');

            expected = '$5.45';
            observed = formatter.formatCurrency(value);
            observed.should.equal(expected);
        });
    });

    describe('The formatPercent function', function() {
        it('Should trim to precision properly', function() {
            var base = 1.23456,
                lowExpectations = '1%',
                mediumExpectations = '1.23%',
                highExpectations = '1.2345%',
                formatter = Jda.SCExecutive.util.Formatters.MetricFormatter,
                precisions = Jda.SCExecutive.constant.Precision;

            var lowObserved = formatter.formatPercent(base, precisions.Low);
            var mediumObserved = formatter.formatPercent(base, precisions.Medium);
            var highObserved = formatter.formatPercent(base, precisions.High);

            lowObserved.should.equal(lowExpectations);
            mediumObserved.should.equal(mediumExpectations);
            highObserved.should.equal(highExpectations);
        });

        it('Should not round at any precision level', function() {
            var base = 9.999999,
                lowExpectations = '9%',
                mediumExpectations = '9.99%',
                highExpectations = '9.9999%',
                formatter = Jda.SCExecutive.util.Formatters.MetricFormatter,
                precisions = Jda.SCExecutive.constant.Precision;

            var lowObserved = formatter.formatPercent(base, precisions.Low);
            var mediumObserved = formatter.formatPercent(base, precisions.Medium);
            var highObserved = formatter.formatPercent(base, precisions.High);

            lowObserved.should.equal(lowExpectations);
            mediumObserved.should.equal(mediumExpectations);
            highObserved.should.equal(highExpectations);
        });

        it('Should pad trailing zeroes by default', function() {
            var base = 1.1,
                lowExpectations = '1%',
                mediumExpectations = '1.10%',
                highExpectations = '1.1000%',
                formatter = Jda.SCExecutive.util.Formatters.MetricFormatter,
                precisions = Jda.SCExecutive.constant.Precision;

            var lowObserved = formatter.formatPercent(base, precisions.Low);
            var mediumObserved = formatter.formatPercent(base, precisions.Medium);
            var highObserved = formatter.formatPercent(base, precisions.High);

            lowObserved.should.equal(lowExpectations);
            mediumObserved.should.equal(mediumExpectations);
            highObserved.should.equal(highExpectations);
        });

        it('Should use proper decimal separator for culture', function() {
            Globalize.culture('de');

            var value = 5.45,
                expected = '5,45%',
                formatter = Jda.SCExecutive.util.Formatters.MetricFormatter,
                precisions = Jda.SCExecutive.constant.Precision;

            var observed = formatter.formatPercent(value, precisions.Medium);

            observed.should.equal(expected);

            Globalize.culture('en');

            expected = '5.45%';

            observed = formatter.formatPercent(value, precisions.Medium);

            observed.should.equal(expected);
        });
    });
});
