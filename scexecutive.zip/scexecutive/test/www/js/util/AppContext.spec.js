describe('The AppContext', function() {
    var firstPeriodHierarchy = Ext.create('Jda.SCExecutive.model.PeriodHierarchy');
    var secondPeriodHierarchy = Ext.create('Jda.SCExecutive.model.PeriodHierarchy');
    var firstLocationHierarchy = Ext.create('Jda.SCExecutive.model.LocationHierarchy');
    var secondLocationHierarchy = Ext.create('Jda.SCExecutive.model.LocationHierarchy');

    var observedPeriodHierarchy, observedLocationHierarchy;

    var contextObserver = { 
        onContextChange: function(context) {
            observedPeriodHierarchy = context.periodHierarchy;
            observedLocationHierarchy = context.locationHierarchy;
        }
    };

    // Add observer before tests, remove after
    before(function() {
        Jda.SCExecutive.util.AppContext.on('contextchanged', contextObserver.onContextChange);
    });

    after(function() {
        Jda.SCExecutive.util.AppContext.un('contextchanged', contextObserver.onContextChange);
    });

    // Clear last observed value between tests
    beforeEach(function() {
        observedLocationHierarchy = observedPeriodHierarchy = undefined;
    });

    it('Should fire context changed when setAppContext is called, with the new items.', function() {
        Jda.SCExecutive.util.AppContext.setAppContext(firstLocationHierarchy, firstPeriodHierarchy);

        observedLocationHierarchy.should.equal(firstLocationHierarchy);
        observedPeriodHierarchy.should.equal(firstPeriodHierarchy);
    });

    it('Should fire context changed when updateCurrentLocationHierarchy is called, with the new items.', function() {
        // Prefill with first
        Jda.SCExecutive.util.AppContext.setAppContext(firstLocationHierarchy, firstPeriodHierarchy);

        Jda.SCExecutive.util.AppContext.updateCurrentLocationHierarchy(secondLocationHierarchy);

        observedLocationHierarchy.should.equal(secondLocationHierarchy);
        observedPeriodHierarchy.should.equal(firstPeriodHierarchy);
    });

    it('Should fire context changed when updateCurrentPeriodHierarchy is called, with the new items.', function() {
        // Prefill with first
        Jda.SCExecutive.util.AppContext.setAppContext(firstLocationHierarchy, firstPeriodHierarchy);

        Jda.SCExecutive.util.AppContext.updateCurrentPeriodHierarchy(secondPeriodHierarchy);

        observedLocationHierarchy.should.equal(firstLocationHierarchy);
        observedPeriodHierarchy.should.equal(secondPeriodHierarchy);
    });

    it('Should fire context changed when refresh is called, with the old items.', function() {
        // Prefill with first
        Jda.SCExecutive.util.AppContext.setAppContext(firstLocationHierarchy, firstPeriodHierarchy);

        // Clear observed
        observedPeriodHierarchy = observedLocationHierarchy = undefined;

        Jda.SCExecutive.util.AppContext.refresh();

        observedLocationHierarchy.should.equal(firstLocationHierarchy);
        observedPeriodHierarchy.should.equal(firstPeriodHierarchy);
    });
});
