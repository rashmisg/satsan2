describe('The DisplayValueSorter', function() {
    function _createRecord(value) {
        return {
            get: function() { return value; }
        };
    }

    it('Should treat any values between 1 and 2 as equal when precision is 0.', function() {
        var sorter = Jda.SCExecutive.util.Sorters.DisplayValueSorter.createSorter({
            precision: 0,
            field: 'value'
        });

        var rec1 = _createRecord(1.0);
        var rec2 = _createRecord(1.5);
        var rec3 = _createRecord(1.9);

        sorter.sorterFn(rec1, rec2).should.equal(0);
        sorter.sorterFn(rec1, rec3).should.equal(0);
        sorter.sorterFn(rec2, rec3).should.equal(0);
    });

    it('Should properly sort values between 1 and 2 as equal when precision is 2.', function() {
        var sorter = Jda.SCExecutive.util.Sorters.DisplayValueSorter.createSorter({
            precision: 2,
            field: 'value'
        });

        var rec1 = _createRecord(1.0);
        var rec2 = _createRecord(1.5);
        var rec3 = _createRecord(1.9);

        sorter.sorterFn(rec1, rec2).should.equal(-1);
        sorter.sorterFn(rec1, rec3).should.equal(-1);
        sorter.sorterFn(rec2, rec3).should.equal(-1);
        sorter.sorterFn(rec2, rec1).should.equal(1);
        sorter.sorterFn(rec3, rec1).should.equal(1);
        sorter.sorterFn(rec3, rec2).should.equal(1);
        sorter.sorterFn(rec1, rec1).should.equal(0);
    });

});
