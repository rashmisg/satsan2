describe('The Renderers utility', function() {
    var yearPeriodHierarchy = Ext.create('Jda.SCExecutive.model.PeriodHierarchy', {
        type: Jda.SCExecutive.model.PeriodHierarchy.types.YEAR,
        start: '2014-01-01T00:00:00',
        end: '2014-12-31T00:00:00'
    });

    var quarterPeriodHierarchy = Ext.create('Jda.SCExecutive.model.PeriodHierarchy', {
        type: Jda.SCExecutive.model.PeriodHierarchy.types.QUARTER,
        parent: yearPeriodHierarchy,
        value: '2014-Q4',
        start: '2014-10-01T00:00:00',
        end: '2014-12-31T00:00:00'
    });

    var monthPeriodHierarchy = Ext.create('Jda.SCExecutive.model.PeriodHierarchy', {
        type: Jda.SCExecutive.model.PeriodHierarchy.types.MONTH,
        parent: quarterPeriodHierarchy,
        start: '2014-10-01T00:00:00',
        end: '2014-10-31T00:00:00'
    });

    var weekPeriodHierarchy = Ext.create('Jda.SCExecutive.model.PeriodHierarchy', {
        type: Jda.SCExecutive.model.PeriodHierarchy.types.WEEK,
        parent: monthPeriodHierarchy,
        value: '2014-W42',
        start: '2014-10-12T00:00:00',
        end: '2014-10-18T00:00:00'
    });

    var datePeriodHierarchy = Ext.create('Jda.SCExecutive.model.PeriodHierarchy', {
        type: Jda.SCExecutive.model.PeriodHierarchy.types.DATE,
        parent: weekPeriodHierarchy,
        start: '2014-10-17T00:00:00',
        end: '2014-10-17T00:00:00'
    });

    describe('The getBarChartXAxisRenderer function', function() {
        var showAllRenderer = Jda.SCExecutive.util.Renderers.getBarChartXAxisRenderer(true);
        var everyOtherRenderer = Jda.SCExecutive.util.Renderers.getBarChartXAxisRenderer();

        it('Should return day name for even ticks for an item whose parent is a week', function() {
            var attr = { data: [ datePeriodHierarchy ] }; // even index

            var observed = showAllRenderer(datePeriodHierarchy, attr);

            observed.should.equal('Fri');
        });

        it('Should return empty string for odd ticks for an item whose parent is a week when show all is not specified', function() {
            var attr = { data: [ undefined, datePeriodHierarchy ] }; // odd index

            var observed = everyOtherRenderer(datePeriodHierarchy, attr);

            observed.should.equal('');
        });

        it('Should return day name for odd ticks for an item whose parent is a week when show all is specified', function() {
            var attr = { data: [ undefined, datePeriodHierarchy ] }; // odd index

            var observed = showAllRenderer(datePeriodHierarchy, attr);

            observed.should.equal('Fri');
        });

        it('Should return week ending date for an item whose parent is a month', function() {
            var observed = showAllRenderer(weekPeriodHierarchy);

            observed.should.equal('10/18');
        });

        it('Should return start and end date for an item whose parent is a quarter', function() {
            var spiedFormat = sinon.spy(Ext.String, 'format');

            showAllRenderer(monthPeriodHierarchy);

            spiedFormat.calledWith(sinon.match.any, '10/01', '10/31').should.be.true;

            Ext.String.format.restore();
        });

        it('Should return quarter name for an item whose parent is a year', function() {
            var spiedFormat = sinon.spy(Ext.String, 'format');

            showAllRenderer(quarterPeriodHierarchy);

            spiedFormat.calledWith(sinon.match.any, '4').should.be.true;

            Ext.String.format.restore();
        });
    });

    describe('The lineChartXAxisRenderer', function() {
        var showAllRenderer = Jda.SCExecutive.util.Renderers.getLineChartXAxisRenderer(true);
        var everyOtherRenderer = Jda.SCExecutive.util.Renderers.getLineChartXAxisRenderer();

        var contextPeriodHierarcy;
        var scopeObject = {
            getAxis: function() {
                return this;
            },
            getChart: function() {
                return this;
            },
            getStore: function() {
                return this;
            },
            getAt: function(index) {
                return {
                    get: function() { return contextPeriodHierarcy; }
                };
            }
        };

        // Clear object to be looked up.
        beforeEach(function() {
            contextPeriodHierarcy = undefined;
        });

        it('Should return day name for even ticks for an item whose context is a week', function() {
            var attr = { data: [ datePeriodHierarchy ] }; // even index
            contextPeriodHierarcy = weekPeriodHierarchy;

            var observed = showAllRenderer.call(scopeObject, datePeriodHierarchy, attr);

            observed.should.equal('Fri');
        });

        it('Should return empty string for odd ticks for an item whose context is a week when show all is not specified', function() {
            var attr = { data: [ undefined, datePeriodHierarchy ] }; // odd index
            contextPeriodHierarcy = weekPeriodHierarchy;

            var observed = everyOtherRenderer.call(scopeObject, datePeriodHierarchy, attr);

            observed.should.equal('');
        });

        it('Should return empty string for odd ticks for an item whose context is a week when show all is specified', function() {
            var attr = { data: [ undefined, datePeriodHierarchy ] }; // odd index
            contextPeriodHierarcy = weekPeriodHierarchy;

            var observed = showAllRenderer.call(scopeObject, datePeriodHierarchy, attr);

            observed.should.equal('Fri');
        });

        it('Should return week ending date for an item whose context is a month', function() {
            var attr = { data: [ weekPeriodHierarchy ] }; // odd index
            contextPeriodHierarcy = monthPeriodHierarchy;

            var observed = showAllRenderer.call(scopeObject, weekPeriodHierarchy, attr);

            observed.should.equal('10/18');
        });

        it('Should return week number for even ticks for an item whose parent is a quarter', function() {
            var attr = { data: [ weekPeriodHierarchy ] }; // even index
            contextPeriodHierarcy = quarterPeriodHierarchy;

            var observed = showAllRenderer.call(scopeObject, weekPeriodHierarchy, attr);

            observed.should.equal('W42');
        });

        it('Should return week number for odd ticks for an item whose parent is a quarter when show all is not specified', function() {
            var attr = { data: [ undefined, weekPeriodHierarchy ] }; // odd index
            contextPeriodHierarcy = quarterPeriodHierarchy;

            var observed = everyOtherRenderer.call(scopeObject, weekPeriodHierarchy, attr);

            observed.should.equal('');
        });

        it('Should return week number for odd ticks for an item whose parent is a quarter when show all is specified', function() {
            var attr = { data: [ undefined, weekPeriodHierarchy ] }; // odd index
            contextPeriodHierarcy = quarterPeriodHierarchy;

            var observed = showAllRenderer.call(scopeObject, weekPeriodHierarchy, attr);

            observed.should.equal('W42');
        });

        it('Should short month for an item whose parent is a year', function() {
            var attr = { data: [ monthPeriodHierarchy ] }; // odd index
            contextPeriodHierarcy = yearPeriodHierarchy;

            var observed = showAllRenderer.call(scopeObject, monthPeriodHierarchy, attr);

            observed.should.equal('Oct');
        });
    });

    describe('The getAdjustedLineChartYAxisConfig function', function() {

        var testGetAdjustedLineChartYAxisConfig = function(testCases) {
            var errors = [];
            testCases.forEach(function(testCase, index) {
                var config = Jda.SCExecutive.util.Renderers.getAdjustedLineChartYAxisConfig({
                    lowestValue: testCase.lowestValue,
                    highestValue: testCase.highestValue,
                    minimumCap: testCase.minimumCap,
                    maximumCap: testCase.maximumCap,
                    hasDoubleTicks: testCase.hasDoubleTicks,

                    percentPaddingTop: 0.0,
                    minRange: 0.25,
                    percentPaddingBottom: 0.20
                });

                try {
                    config.should.have.property('minimum', testCase.expectedMinimum);
                }
                catch (e) {
                    errors.push('Case ' + (index + 1) + ': ' + e.toString());
                }

                try {
                    config.should.have.property('maximum', testCase.expectedMaximum);
                }
                catch (e) {
                    errors.push('Case ' + (index + 1) + ': ' + e.toString());
                }

                try {
                    config.should.have.property('majorTickSteps', testCase.expectedMajorTickSteps);
                }
                catch (e) {
                    errors.push('Case ' + (index + 1) + ': ' + e.toString());
                }
            });

            return errors;
        };

        it('Should calculate adjusted values based on the lowestValue', function() {
            var testCases = [ //highestValue defaults to 100
                //hits the minRange of 25%, 100 - .25*100 = 75
                //paddingTop is 0%, so the maximum ends up the same as the highestValue
                { lowestValue: 100,  expectedMinimum: 75,  expectedMaximum: 100, expectedMajorTickSteps: 5 },//steps of 5
                { lowestValue: 95,   expectedMinimum: 75,  expectedMaximum: 100, expectedMajorTickSteps: 5 },
                //hits paddingBottom of 20%, .20*100 = 20
                { lowestValue: 90,   expectedMinimum: 70,  expectedMaximum: 100, expectedMajorTickSteps: 3 },//steps of 10
                { lowestValue: 89,   expectedMinimum: 60,  expectedMaximum: 100, expectedMajorTickSteps: 4 },
                { lowestValue: 85,   expectedMinimum: 60,  expectedMaximum: 100, expectedMajorTickSteps: 4 },
                { lowestValue: 80,   expectedMinimum: 60,  expectedMaximum: 100, expectedMajorTickSteps: 4 },
                { lowestValue: 75,   expectedMinimum: 50,  expectedMaximum: 100, expectedMajorTickSteps: 5 },
                { lowestValue: 70,   expectedMinimum: 50,  expectedMaximum: 100, expectedMajorTickSteps: 5 },
                { lowestValue: 65,   expectedMinimum: 40,  expectedMaximum: 100, expectedMajorTickSteps: 3 },//steps of 20
                { lowestValue: 60,   expectedMinimum: 40,  expectedMaximum: 100, expectedMajorTickSteps: 3 },
                { lowestValue: 55,   expectedMinimum: 20,  expectedMaximum: 100, expectedMajorTickSteps: 4 },
                { lowestValue: 50,   expectedMinimum: 20,  expectedMaximum: 100, expectedMajorTickSteps: 4 },
                { lowestValue: 45,   expectedMinimum: 20,  expectedMaximum: 100, expectedMajorTickSteps: 4 },
                { lowestValue: 40,   expectedMinimum: 20,  expectedMaximum: 100, expectedMajorTickSteps: 4 },
                { lowestValue: 35,   expectedMinimum: 0,   expectedMaximum: 100, expectedMajorTickSteps: 5 },
                { lowestValue: 30,   expectedMinimum: 0,   expectedMaximum: 100, expectedMajorTickSteps: 5 },
                { lowestValue: 25,   expectedMinimum: 0,   expectedMaximum: 100, expectedMajorTickSteps: 5 },
                { lowestValue: 20,   expectedMinimum: 0,   expectedMaximum: 100, expectedMajorTickSteps: 5 },
                { lowestValue: 15,   expectedMinimum: 0,   expectedMaximum: 100, expectedMajorTickSteps: 5 },
                { lowestValue: 10,   expectedMinimum: 0,   expectedMaximum: 100, expectedMajorTickSteps: 5 },
                { lowestValue: 5,    expectedMinimum: 0,   expectedMaximum: 100, expectedMajorTickSteps: 5 },
                { lowestValue: 0,    expectedMinimum: 0,   expectedMaximum: 100, expectedMajorTickSteps: 5 },

                { lowestValue: 90.9685,   expectedMinimum: 70,  expectedMaximum: 100, expectedMajorTickSteps: 3 },//should floor
                { lowestValue: 89.9865,   expectedMinimum: 60,  expectedMaximum: 100, expectedMajorTickSteps: 4 } //should floor
            ];

            var errors = testGetAdjustedLineChartYAxisConfig(testCases);

            if (errors.length > 0) {
                throw new Error('\n' + errors.join('\n'));
            }
        });

        it('Should calculate adjusted values based on the highestValue', function() {
            var testCases = [ //lowestValue defaults to 0
                //This case is expected, because without the lowestValue set, setting highestValue to zero
                //essentially means there is no data on the graph. This is kind of a garbage usecase.
                { highestValue: 0, expectedMinimum: 0, expectedMaximum: 0,   expectedMajorTickSteps: 0 },

                //minRange and paddingBottom should never come into play for these tests because we're defaulting
                //to a lowestValue of zero. With paddingTop at 0%, the expectedMaximum should adjust to the next
                //good looking unit above the largestValue. 
                { highestValue: 1,   expectedMinimum: 0, expectedMaximum: 1,   expectedMajorTickSteps: 5 },
                { highestValue: 2,   expectedMinimum: 0, expectedMaximum: 2,   expectedMajorTickSteps: 4 },
                { highestValue: 3,   expectedMinimum: 0, expectedMaximum: 3,   expectedMajorTickSteps: 3 },
                { highestValue: 4,   expectedMinimum: 0, expectedMaximum: 4,   expectedMajorTickSteps: 4 },
                { highestValue: 5,   expectedMinimum: 0, expectedMaximum: 5,   expectedMajorTickSteps: 5 },
                { highestValue: 6,   expectedMinimum: 0, expectedMaximum: 6,   expectedMajorTickSteps: 3 },
                { highestValue: 7,   expectedMinimum: 0, expectedMaximum: 8,   expectedMajorTickSteps: 4 },
                { highestValue: 8,   expectedMinimum: 0, expectedMaximum: 8,   expectedMajorTickSteps: 4 },
                { highestValue: 9,   expectedMinimum: 0, expectedMaximum: 10,  expectedMajorTickSteps: 5 },
                { highestValue: 10,  expectedMinimum: 0, expectedMaximum: 10,  expectedMajorTickSteps: 5 },
                { highestValue: 11,  expectedMinimum: 0, expectedMaximum: 15,  expectedMajorTickSteps: 3 },
                { highestValue: 16,  expectedMinimum: 0, expectedMaximum: 20,  expectedMajorTickSteps: 4 },
                { highestValue: 23,  expectedMinimum: 0, expectedMaximum: 25,  expectedMajorTickSteps: 5 },
                { highestValue: 28,  expectedMinimum: 0, expectedMaximum: 30,  expectedMajorTickSteps: 3 },
                { highestValue: 39,  expectedMinimum: 0, expectedMaximum: 40,  expectedMajorTickSteps: 4 },
                { highestValue: 42,  expectedMinimum: 0, expectedMaximum: 50,  expectedMajorTickSteps: 5 },
                { highestValue: 55,  expectedMinimum: 0, expectedMaximum: 60,  expectedMajorTickSteps: 3 },
                { highestValue: 61,  expectedMinimum: 0, expectedMaximum: 80,  expectedMajorTickSteps: 4 },
                { highestValue: 77,  expectedMinimum: 0, expectedMaximum: 80,  expectedMajorTickSteps: 4 },
                { highestValue: 83,  expectedMinimum: 0, expectedMaximum: 100, expectedMajorTickSteps: 5 },
                { highestValue: 91,  expectedMinimum: 0, expectedMaximum: 100, expectedMajorTickSteps: 5 },
                { highestValue: 100, expectedMinimum: 0, expectedMaximum: 100, expectedMajorTickSteps: 5 },
                { highestValue: 101, expectedMinimum: 0, expectedMaximum: 150, expectedMajorTickSteps: 3 },
                { highestValue: 111, expectedMinimum: 0, expectedMaximum: 150, expectedMajorTickSteps: 3 },
                { highestValue: 120, expectedMinimum: 0, expectedMaximum: 150, expectedMajorTickSteps: 3 },
                { highestValue: 135, expectedMinimum: 0, expectedMaximum: 150, expectedMajorTickSteps: 3 },
                { highestValue: 149, expectedMinimum: 0, expectedMaximum: 150, expectedMajorTickSteps: 3 },
                { highestValue: 150, expectedMinimum: 0, expectedMaximum: 150, expectedMajorTickSteps: 3 },
                { highestValue: 151, expectedMinimum: 0, expectedMaximum: 200, expectedMajorTickSteps: 4 },
                { highestValue: 200, expectedMinimum: 0, expectedMaximum: 200, expectedMajorTickSteps: 4 },
                { highestValue: 250, expectedMinimum: 0, expectedMaximum: 250, expectedMajorTickSteps: 5 },
                { highestValue: 300, expectedMinimum: 0, expectedMaximum: 300, expectedMajorTickSteps: 3 },
                { highestValue: 400, expectedMinimum: 0, expectedMaximum: 400, expectedMajorTickSteps: 4 },

                { highestValue: 1456345, expectedMinimum: 0, expectedMaximum: 1500000,  expectedMajorTickSteps: 3 },
                { highestValue: 2956345, expectedMinimum: 0, expectedMaximum: 3000000,  expectedMajorTickSteps: 3 },
                { highestValue: 3356345, expectedMinimum: 0, expectedMaximum: 4000000,  expectedMajorTickSteps: 4 },
                { highestValue: 4756345, expectedMinimum: 0, expectedMaximum: 5000000,  expectedMajorTickSteps: 5 },
                { highestValue: 5156345, expectedMinimum: 0, expectedMaximum: 6000000,  expectedMajorTickSteps: 3 },
                { highestValue: 6856345, expectedMinimum: 0, expectedMaximum: 8000000,  expectedMajorTickSteps: 4 },
                { highestValue: 7256345, expectedMinimum: 0, expectedMaximum: 8000000,  expectedMajorTickSteps: 4 },
                { highestValue: 8856345, expectedMinimum: 0, expectedMaximum: 10000000, expectedMajorTickSteps: 5 },
                { highestValue: 9056345, expectedMinimum: 0, expectedMaximum: 10000000, expectedMajorTickSteps: 5 },
                { highestValue: 956345,  expectedMinimum: 0, expectedMaximum: 1000000,  expectedMajorTickSteps: 5 },
                { highestValue: 490781234,     expectedMinimum: 0, expectedMaximum: 500000000,     expectedMajorTickSteps: 5 },
                { highestValue: 1000000000,    expectedMinimum: 0, expectedMaximum: 1000000000,    expectedMajorTickSteps: 5 },
                { highestValue: 1000000000000, expectedMinimum: 0, expectedMaximum: 1000000000000, expectedMajorTickSteps: 5 },


                { highestValue: 59.958,  expectedMinimum: 0, expectedMaximum: 60,  expectedMajorTickSteps: 3 },//should ceil
                { highestValue: 60.958,  expectedMinimum: 0, expectedMaximum: 80,  expectedMajorTickSteps: 4 } //should ceil
            ];

            var errors = testGetAdjustedLineChartYAxisConfig(testCases);

            if (errors.length > 0) {
                throw new Error('\n' + errors.join('\n'));
            }
        });

        it('Should calculate adjusted values based on both the lowestValue and the highestValue', function() {
            var testCases = [
                //defaults to 0 lowest and 100 highest
                { lowestValue: undefined, highestValue: undefined, expectedMinimum: 0, expectedMaximum: 100, expectedMajorTickSteps: 5 },
                { lowestValue: 0, highestValue: 0, expectedMinimum: 0, expectedMaximum: 0, expectedMajorTickSteps: 0 }, //empty case

                { lowestValue: 0, highestValue: 1, expectedMinimum: 0, expectedMaximum: 1, expectedMajorTickSteps: 5 },
                { lowestValue: 1, highestValue: 2, expectedMinimum: 0, expectedMaximum: 2, expectedMajorTickSteps: 4 },
                { lowestValue: 1, highestValue: 99, expectedMinimum: 0, expectedMaximum: 100, expectedMajorTickSteps: 5 },

                //paddingBottom 20%
                { lowestValue: 1,  highestValue: 10, expectedMinimum: 0, expectedMaximum: 10, expectedMajorTickSteps: 5 },
                { lowestValue: 2,  highestValue: 10, expectedMinimum: 0, expectedMaximum: 10, expectedMajorTickSteps: 5 },
                { lowestValue: 3,  highestValue: 10, expectedMinimum: 0, expectedMaximum: 10, expectedMajorTickSteps: 5 },
                { lowestValue: 4,  highestValue: 10, expectedMinimum: 2, expectedMaximum: 10, expectedMajorTickSteps: 4 },
                { lowestValue: 5,  highestValue: 10, expectedMinimum: 2, expectedMaximum: 10, expectedMajorTickSteps: 4 },
                { lowestValue: 6,  highestValue: 10, expectedMinimum: 4, expectedMaximum: 10, expectedMajorTickSteps: 3 },
                { lowestValue: 7,  highestValue: 10, expectedMinimum: 5, expectedMaximum: 10, expectedMajorTickSteps: 5 },
                { lowestValue: 8,  highestValue: 10, expectedMinimum: 6, expectedMaximum: 10, expectedMajorTickSteps: 4 },
                { lowestValue: 9,  highestValue: 10, expectedMinimum: 7, expectedMaximum: 10, expectedMajorTickSteps: 3 },
                //minRandge 25%
                { lowestValue: 10, highestValue: 10, expectedMinimum: 7, expectedMaximum: 10, expectedMajorTickSteps: 3 },

                //paddingBottom 20%
                { lowestValue: 650, highestValue: 980, expectedMinimum: 400, expectedMaximum: 1000, expectedMajorTickSteps: 3 },//454
                { lowestValue: 699, highestValue: 980, expectedMinimum: 500, expectedMaximum: 1000, expectedMajorTickSteps: 5 },//503
                { lowestValue: 710, highestValue: 980, expectedMinimum: 500, expectedMaximum: 1000, expectedMajorTickSteps: 5 },//514
                { lowestValue: 725, highestValue: 980, expectedMinimum: 500, expectedMaximum: 1000, expectedMajorTickSteps: 5 },//529
                { lowestValue: 730, highestValue: 980, expectedMinimum: 500, expectedMaximum: 1000, expectedMajorTickSteps: 5 },//534
                { lowestValue: 735, highestValue: 980, expectedMinimum: 500, expectedMaximum: 1000, expectedMajorTickSteps: 5 },//539

                //The following tests the transition from paddingBottom to minRange.
                //paddingBottom 20% (-196)
                { lowestValue: 740, highestValue: 980, expectedMinimum: 500, expectedMaximum: 1000, expectedMajorTickSteps: 5 },//544
                { lowestValue: 750, highestValue: 980, expectedMinimum: 500, expectedMaximum: 1000, expectedMajorTickSteps: 5 },//554
                { lowestValue: 770, highestValue: 980, expectedMinimum: 500, expectedMaximum: 1000, expectedMajorTickSteps: 5 },//574
                { lowestValue: 800, highestValue: 980, expectedMinimum: 600, expectedMaximum: 1000, expectedMajorTickSteps: 4 },//604
                { lowestValue: 900, highestValue: 980, expectedMinimum: 700, expectedMaximum: 1000, expectedMajorTickSteps: 3 },//704
                { lowestValue: 930, highestValue: 980, expectedMinimum: 700, expectedMaximum: 1000, expectedMajorTickSteps: 3 },//734
                { lowestValue: 931, highestValue: 980, expectedMinimum: 700, expectedMaximum: 1000, expectedMajorTickSteps: 3 },//735
                //minRandge 25% (-245)
                { lowestValue: 932, highestValue: 980, expectedMinimum: 700, expectedMaximum: 1000, expectedMajorTickSteps: 3 },//735
                { lowestValue: 940, highestValue: 980, expectedMinimum: 700, expectedMaximum: 1000, expectedMajorTickSteps: 3 },//735
                { lowestValue: 950, highestValue: 980, expectedMinimum: 700, expectedMaximum: 1000, expectedMajorTickSteps: 3 },//735
                { lowestValue: 960, highestValue: 980, expectedMinimum: 700, expectedMaximum: 1000, expectedMajorTickSteps: 3 },//735
                { lowestValue: 979, highestValue: 980, expectedMinimum: 700, expectedMaximum: 1000, expectedMajorTickSteps: 3 } //735
            ];

            var errors = testGetAdjustedLineChartYAxisConfig(testCases);

            if (errors.length > 0) {
                throw new Error('\n' + errors.join('\n'));
            }
        });


        it('Should calculate roughly double the number of ticks when extra ticks is true', function() {
            var testCases = [
                //Having a lowest and highest value of zero means no data and we can expect no ticks.
                { highestValue: 0,  expectedMinimum: 0, expectedMaximum: 0, expectedMajorTickSteps: 0, hasDoubleTicks: true },

                { highestValue: 1,  expectedMinimum: 0, expectedMaximum: 1,  expectedMajorTickSteps: 10, hasDoubleTicks: true },
                { highestValue: 2,  expectedMinimum: 0, expectedMaximum: 2,  expectedMajorTickSteps: 10, hasDoubleTicks: true },
                { highestValue: 3,  expectedMinimum: 0, expectedMaximum: 3,  expectedMajorTickSteps: 6,  hasDoubleTicks: true },
                { highestValue: 4,  expectedMinimum: 0, expectedMaximum: 4,  expectedMajorTickSteps: 8,  hasDoubleTicks: true },
                { highestValue: 5,  expectedMinimum: 0, expectedMaximum: 5,  expectedMajorTickSteps: 10, hasDoubleTicks: true },
                { highestValue: 6,  expectedMinimum: 0, expectedMaximum: 6,  expectedMajorTickSteps: 6,  hasDoubleTicks: true },
                { highestValue: 7,  expectedMinimum: 0, expectedMaximum: 7,  expectedMajorTickSteps: 7,  hasDoubleTicks: true },
                { highestValue: 8,  expectedMinimum: 0, expectedMaximum: 8,  expectedMajorTickSteps: 8,  hasDoubleTicks: true },
                { highestValue: 9,  expectedMinimum: 0, expectedMaximum: 9,  expectedMajorTickSteps: 9,  hasDoubleTicks: true },
                { highestValue: 10, expectedMinimum: 0, expectedMaximum: 10, expectedMajorTickSteps: 10, hasDoubleTicks: true },

                { highestValue: 11, expectedMinimum: 0, expectedMaximum: 12, expectedMajorTickSteps: 6, hasDoubleTicks: true },
                { highestValue: 16, expectedMinimum: 0, expectedMaximum: 16, expectedMajorTickSteps: 8, hasDoubleTicks: true },
                { highestValue: 23, expectedMinimum: 0, expectedMaximum: 25, expectedMajorTickSteps: 5, hasDoubleTicks: true },
                { highestValue: 28, expectedMinimum: 0, expectedMaximum: 30, expectedMajorTickSteps: 6, hasDoubleTicks: true },
                { highestValue: 39, expectedMinimum: 0, expectedMaximum: 40, expectedMajorTickSteps: 8, hasDoubleTicks: true },
                { highestValue: 42, expectedMinimum: 0, expectedMaximum: 45, expectedMajorTickSteps: 9, hasDoubleTicks: true },

                //paddingBottom 20%
                { lowestValue:  42, expectedMinimum: 20, expectedMaximum: 100, expectedMajorTickSteps: 8,  hasDoubleTicks: true },
                { lowestValue:  53, expectedMinimum: 30, expectedMaximum: 100, expectedMajorTickSteps: 7,  hasDoubleTicks: true },
                { lowestValue:  67, expectedMinimum: 40, expectedMaximum: 100, expectedMajorTickSteps: 6,  hasDoubleTicks: true },
                { lowestValue:  74, expectedMinimum: 50, expectedMaximum: 100, expectedMajorTickSteps: 10, hasDoubleTicks: true },
                { lowestValue:  81, expectedMinimum: 60, expectedMaximum: 100, expectedMajorTickSteps: 8,  hasDoubleTicks: true },
                { lowestValue:  90, expectedMinimum: 70, expectedMaximum: 100, expectedMajorTickSteps: 6,  hasDoubleTicks: true },
                //minRange 25%
                { lowestValue:  95, expectedMinimum: 75, expectedMaximum: 100, expectedMajorTickSteps: 5,  hasDoubleTicks: true },
                { lowestValue:  96, expectedMinimum: 75, expectedMaximum: 100, expectedMajorTickSteps: 5,  hasDoubleTicks: true },

                { lowestValue: undefined, highestValue: undefined, expectedMinimum: 0, expectedMaximum: 100, expectedMajorTickSteps: 5 },
                //The following tests the transition from paddingBottom to minRange.
                //paddingBottom 20% (-196)
                { lowestValue: 740, highestValue: 980, expectedMinimum: 500, expectedMaximum: 1000, expectedMajorTickSteps: 10, hasDoubleTicks: true },//544
                { lowestValue: 750, highestValue: 980, expectedMinimum: 550, expectedMaximum: 1000, expectedMajorTickSteps: 9,  hasDoubleTicks: true },//554
                { lowestValue: 770, highestValue: 980, expectedMinimum: 550, expectedMaximum: 1000, expectedMajorTickSteps: 9,  hasDoubleTicks: true },//574
                { lowestValue: 800, highestValue: 980, expectedMinimum: 600, expectedMaximum: 1000, expectedMajorTickSteps: 8,  hasDoubleTicks: true },//604
                { lowestValue: 900, highestValue: 980, expectedMinimum: 700, expectedMaximum: 1000, expectedMajorTickSteps: 6,  hasDoubleTicks: true },//704
                { lowestValue: 930, highestValue: 980, expectedMinimum: 700, expectedMaximum: 1000, expectedMajorTickSteps: 6,  hasDoubleTicks: true },//734
                { lowestValue: 931, highestValue: 980, expectedMinimum: 700, expectedMaximum: 1000, expectedMajorTickSteps: 6,  hasDoubleTicks: true },//735
                //minRandge 25% (-245)
                { lowestValue: 932, highestValue: 980, expectedMinimum: 700, expectedMaximum: 1000, expectedMajorTickSteps: 6,  hasDoubleTicks: true },//735
                { lowestValue: 940, highestValue: 980, expectedMinimum: 700, expectedMaximum: 1000, expectedMajorTickSteps: 6,  hasDoubleTicks: true },//735
                { lowestValue: 950, highestValue: 980, expectedMinimum: 700, expectedMaximum: 1000, expectedMajorTickSteps: 6,  hasDoubleTicks: true },//735
                { lowestValue: 960, highestValue: 980, expectedMinimum: 700, expectedMaximum: 1000, expectedMajorTickSteps: 6,  hasDoubleTicks: true },//735
                { lowestValue: 979, highestValue: 980, expectedMinimum: 700, expectedMaximum: 1000, expectedMajorTickSteps: 6,  hasDoubleTicks: true } //735
            ];

            var errors = testGetAdjustedLineChartYAxisConfig(testCases);

            if (errors.length > 0) {
                throw new Error('\n' + errors.join('\n'));
            }
        });
    });
});
