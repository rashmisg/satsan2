describe('The Progress Bar', function() {
    describe('The updatePeriodHierarchy function', function() {
        var yearHierarchy = Ext.create('Jda.SCExecutive.model.PeriodHierarchy', { type: Jda.SCExecutive.model.PeriodHierarchy.types.YEAR, value: '2014' });
        var quarterHierarchy = Ext.create('Jda.SCExecutive.model.PeriodHierarchy', { type: Jda.SCExecutive.model.PeriodHierarchy.types.QUARTER, parent: yearHierarchy, value: '2014-Q4' });
        var monthHierarchy = Ext.create('Jda.SCExecutive.model.PeriodHierarchy', { type: Jda.SCExecutive.model.PeriodHierarchy.types.MONTH, parent: quarterHierarchy, start: '2014-09-01' });
        var weekHierarchy = Ext.create('Jda.SCExecutive.model.PeriodHierarchy', { type: Jda.SCExecutive.model.PeriodHierarchy.types.WEEK, parent: monthHierarchy });

        it('Should display the name of the parent Month when provided a Week.', function() {
            var progressBar = Ext.create('Jda.SCExecutive.progressbar.ProgressBar');
            var spiedFormat = sinon.spy(Ext.String, 'format');

            progressBar.updatePeriodHierarchy(weekHierarchy);

            spiedFormat.calledWith(sinon.match.any, 'September').should.be.true;

            Ext.String.format.restore();
        });

        it('Should display the name of the Month when provided a Month.', function() {
            var progressBar = Ext.create('Jda.SCExecutive.progressbar.ProgressBar');
            var spiedFormat = sinon.spy(Ext.String, 'format');

            progressBar.updatePeriodHierarchy(monthHierarchy);

            spiedFormat.calledWith(sinon.match.any, 'September').should.be.true;

            Ext.String.format.restore();
        });

        it('Should display Quarter X when provided a Quarter.', function() {
            var progressBar = Ext.create('Jda.SCExecutive.progressbar.ProgressBar');
            var spiedFormat = sinon.spy(Ext.String, 'format');

            progressBar.updatePeriodHierarchy(quarterHierarchy);

            spiedFormat.calledWith(sinon.match.any, '4', '2014').should.be.true;

            Ext.String.format.restore();
        });

        it('Should display the Year when provided a Year.', function() {
            var progressBar = Ext.create('Jda.SCExecutive.progressbar.ProgressBar');
            var spiedFormat = sinon.spy(Ext.String, 'format');

            progressBar.updatePeriodHierarchy(yearHierarchy);

            spiedFormat.calledWith(sinon.match.any, '2014').should.be.true;

            Ext.String.format.restore();

        });
    });
});
