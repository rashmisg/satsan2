describe('The Color constant singleton', function() {
    it('Should return the appropriate color for a colorForLocationHierarchyAtIndex from its color palete', function() {
        var colorPalete = Jda.SCExecutive.constant.Colors.colorPalete;
        var expected1 = colorPalete[1];
        var expected4 = colorPalete[4];

        var observed1 = Jda.SCExecutive.constant.Colors.colorForLocationHierarchyAtIndex(1);
        var observed4 = Jda.SCExecutive.constant.Colors.colorForLocationHierarchyAtIndex(4);

        observed1.should.equal(expected1);
        observed4.should.equal(expected4);
    });

    it('Should handle index out of bounds for colorForLocationHierarchyAtIndex', function() {
        var colorPalete = Jda.SCExecutive.constant.Colors.colorPalete;
        var expected1 = colorPalete[1];
        var expected4 = colorPalete[4];

        var observedOver1 = Jda.SCExecutive.constant.Colors.colorForLocationHierarchyAtIndex(colorPalete.length + 1);
        var observedOver4 = Jda.SCExecutive.constant.Colors.colorForLocationHierarchyAtIndex(colorPalete.length + 4);
        var observedUnder1 = Jda.SCExecutive.constant.Colors.colorForLocationHierarchyAtIndex(-colorPalete.length + 1);
        var observedUnder4 = Jda.SCExecutive.constant.Colors.colorForLocationHierarchyAtIndex(-colorPalete.length + 4);

        observedOver1.should.equal(expected1);
        observedOver4.should.equal(expected4);
        observedUnder1.should.equal(expected1);
        observedUnder4.should.equal(expected4);
    });
});
