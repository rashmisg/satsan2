describe('The Location Hierarchy', function() {
    function _createLocationHierarchy(level, code, name, parent) {
        var newLoc = Ext.create('Jda.SCExecutive.model.LocationHierarchy', {
            level: level,
            name: name,
            code: code,
            parent: parent,
            isRoot: parent === undefined
        });

        if (parent) {
            parent.children().add(newLoc);
        }

        return newLoc;
    }

    describe('The getColor function', function() {
        it('Should use the next color index for each child and should wrap when it runs out', function() {
            var root = _createLocationHierarchy('root', 'all');
            var child1 = _createLocationHierarchy('country', 'c-1', 'country-a', root);
            var child2 = _createLocationHierarchy('country', 'c-2', 'country-b', root);
            var child3 = _createLocationHierarchy('country', 'c-3', 'country-c', root);
            var child4 = _createLocationHierarchy('country', 'c-4', 'country-d', root);
            var child5 = _createLocationHierarchy('country', 'c-5', 'country-e', root);
            var child6 = _createLocationHierarchy('country', 'c-6', 'country-f', root);
            var child7 = _createLocationHierarchy('country', 'c-7', 'country-g', root);
            var child8 = _createLocationHierarchy('country', 'c-8', 'country-h', root);
            var child9 = _createLocationHierarchy('country', 'c-9', 'country-i', root);
            var child10 = _createLocationHierarchy('country', 'c-10', 'country-j', root);
            var child11 = _createLocationHierarchy('country', 'c-11', 'country-k', root);
            var child12 = _createLocationHierarchy('country', 'c-12', 'country-l', root);
            var child13 = _createLocationHierarchy('country', 'c-13', 'country-m', root);

            child1.getColor().should.equal(Jda.SCExecutive.constant.Colors.colorPalete[0]);
            child2.getColor().should.equal(Jda.SCExecutive.constant.Colors.colorPalete[1]);
            child3.getColor().should.equal(Jda.SCExecutive.constant.Colors.colorPalete[2]);
            child4.getColor().should.equal(Jda.SCExecutive.constant.Colors.colorPalete[3]);
            child5.getColor().should.equal(Jda.SCExecutive.constant.Colors.colorPalete[4]);
            child6.getColor().should.equal(Jda.SCExecutive.constant.Colors.colorPalete[5]);
            child7.getColor().should.equal(Jda.SCExecutive.constant.Colors.colorPalete[6]);
            child8.getColor().should.equal(Jda.SCExecutive.constant.Colors.colorPalete[7]);
            child9.getColor().should.equal(Jda.SCExecutive.constant.Colors.colorPalete[8]);
            child10.getColor().should.equal(Jda.SCExecutive.constant.Colors.colorPalete[9]);
            child11.getColor().should.equal(Jda.SCExecutive.constant.Colors.colorPalete[10]);
            child12.getColor().should.equal(Jda.SCExecutive.constant.Colors.colorPalete[11]);
            child13.getColor().should.equal(Jda.SCExecutive.constant.Colors.colorPalete[0]);
        });
    });

    describe('The getViewingString function', function() {
        var root = _createLocationHierarchy('root', 'all');
        var country = _createLocationHierarchy('country', 'USA', 'United States', root);
        var region = _createLocationHierarchy('region', 'North', 'North', country);

        it('Should return "Viewing All" message for root', function() {
            var viewingString = root.getViewingString();

            viewingString.should.equal(Jda.getMessage('jda.scexecutive.locationhierarchy.ViewingAllRegions'));
        });

        it('Should return "Viewing xxx" message for region with root parent', function() {
            var spiedFormat = sinon.spy(Ext.String, 'format');

            country.getViewingString();

            spiedFormat.calledWith(sinon.match.any, country.get('name')).should.be.true;

            Ext.String.format.restore();
        });

        it('Should return "Viewing xxx - yyy" message for region with non-root parent', function() {
            var spiedFormat = sinon.spy(Ext.String, 'format');

            region.getViewingString();

            spiedFormat.calledWith(sinon.match.any, country.get('name'), region.get('name')).should.be.true;

            Ext.String.format.restore();
        });
    });

    describe('The getHierarchyPath function', function() {
        it('Should create an XPath-style String representing the location hierarchy', function() {
            var root = _createLocationHierarchy('root', 'all');
            var country = _createLocationHierarchy('country', 'USA', 'United States', root);
            var region = _createLocationHierarchy('region', 'Midwest', 'Midwest', country);
            var state = _createLocationHierarchy('state', 'WI', 'Wisconsin', region);

            country.getHierarchyPath().should.equal('USA');
            region.getHierarchyPath().should.equal('USA/Midwest');
            state.getHierarchyPath().should.equal('USA/Midwest/WI');
        });
    });
});
