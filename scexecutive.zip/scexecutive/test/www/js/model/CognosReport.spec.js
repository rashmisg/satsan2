describe('The CognosReport class', function() {
    describe('The extractMetaDataValue function', function() {
        it('Should return the value of the inner row when the provided keys are present', function() {
            var expectedValue = 1,
                jsonData = {
                    FooTableID: [{
                        BarRowID: expectedValue
                    }]
                };

            var cognosReport = Ext.create('Jda.SCExecutive.model.CognosReport', { jsonData: jsonData });

            var observedValue = cognosReport.extractMetaDataValue('FooTableID', 'BarRowID');

            observedValue.should.equal(expectedValue);
        });

        it('Should return undefined when the provided table is not present', function() {
            var jsonData = { };

            var cognosReport = Ext.create('Jda.SCExecutive.model.CognosReport', { jsonData: jsonData });

            var observedValue = cognosReport.extractMetaDataValue('FooTableID', 'BarRowID');

            Should(observedValue).equal(undefined);
        });

        it('Should return undefined when the provided row id is not present', function() {
            var jsonData = {
                    FooTableID: [ ]
                };

            var cognosReport = Ext.create('Jda.SCExecutive.model.CognosReport', { jsonData: jsonData });

            var observedValue = cognosReport.extractMetaDataValue('FooTableID', 'BarRowID');

            Should(observedValue).equal(undefined);
        });

        it('Should match when the observed key is the provided key suffixed with the provided period hierarchy type', function() {
            var expectedValue = 1,
                periodHierarchy = Ext.create('Jda.SCExecutive.model.PeriodHierarchy', { type: 'Year' }),
                jsonData = {
                    FooTableID_Year: [{
                        BarRowID: expectedValue
                    }]
                };

            var cognosReport = Ext.create('Jda.SCExecutive.model.CognosReport', { jsonData: jsonData });

            var observedValue = cognosReport.extractMetaDataValue('FooTableID', 'BarRowID', periodHierarchy);

            observedValue.should.equal(expectedValue);
        });

        it('Should match when the observed key is the provided key suffixed with the provided location hierarchy level', function() {
            var expectedValue = 1,
                locationHierarchy = Ext.create('Jda.SCExecutive.model.LocationHierarchy', { level: 'Country' }),
                jsonData = {
                    FooTableID_Country: [{
                        BarRowID: expectedValue
                    }]
                };

            var cognosReport = Ext.create('Jda.SCExecutive.model.CognosReport', { jsonData: jsonData });

            var observedValue = cognosReport.extractMetaDataValue('FooTableID', 'BarRowID', undefined, locationHierarchy);

            observedValue.should.equal(expectedValue);
        });

        it('Should match when the observed key is the provided key suffixed with "all" when the provided location hierarchy is root', function() {
            var expectedValue = 1,
                locationHierarchy = Ext.create('Jda.SCExecutive.model.LocationHierarchy', { isRoot: true }),
                jsonData = {
                    FooTableID_All: [{
                        BarRowID: expectedValue
                    }]
                };

            var cognosReport = Ext.create('Jda.SCExecutive.model.CognosReport', { jsonData: jsonData });

            var observedValue = cognosReport.extractMetaDataValue('FooTableID', 'BarRowID', undefined, locationHierarchy);

            observedValue.should.equal(expectedValue);
        });

        it('Should match when the observed key is the provided key suffixed with both period hierarchy type and location hierarchy level', function() {
            var expectedValue = 1,
                periodHierarchy = Ext.create('Jda.SCExecutive.model.PeriodHierarchy', { type: 'Year' }),
                locationHierarchy = Ext.create('Jda.SCExecutive.model.LocationHierarchy', { level: 'Country' }),
                jsonData = {
                    FooTableID_Year_Country: [{
                        BarRowID: expectedValue
                    }]
                };

            var cognosReport = Ext.create('Jda.SCExecutive.model.CognosReport', { jsonData: jsonData });

            var observedValue = cognosReport.extractMetaDataValue('FooTableID', 'BarRowID', periodHierarchy, locationHierarchy);

            observedValue.should.equal(expectedValue);
        });
    });

    describe('The extractDataRows function', function() {
        it('Should return the values of the inner rows when the provided keys are present', function() {
            var expectedValue = [ 1, 2, 3, 4 ],
                jsonData = {
                    FooTableID: expectedValue
                };

            var cognosReport = Ext.create('Jda.SCExecutive.model.CognosReport', { jsonData: jsonData });

            var observedValue = cognosReport.extractDataRows('FooTableID');

            observedValue.should.eql(expectedValue);
        });

        it('Should return undefined when the provided table is not present', function() {
            var jsonData = { };

            var cognosReport = Ext.create('Jda.SCExecutive.model.CognosReport', { jsonData: jsonData });

            var observedValue = cognosReport.extractDataRows('FooTableID');

            Should(observedValue).equal(undefined);
        });

        it('Should match when the observed key is the provided key suffixed with the provided period hierarchy type', function() {
            var expectedValue = [ 1, 2, 3, 4 ],
                periodHierarchy = Ext.create('Jda.SCExecutive.model.PeriodHierarchy', { type: 'Year' }),
                jsonData = {
                    FooTableID_Year: expectedValue
                };

            var cognosReport = Ext.create('Jda.SCExecutive.model.CognosReport', { jsonData: jsonData });

            var observedValue = cognosReport.extractDataRows('FooTableID', periodHierarchy);

            observedValue.should.eql(expectedValue);
        });

        it('Should match when the observed key is the provided key suffixed with the provided location hierarchy level', function() {
            var expectedValue = [ 1, 2, 3, 4 ],
                locationHierarchy = Ext.create('Jda.SCExecutive.model.LocationHierarchy', { level: 'Country' }),
                jsonData = {
                    FooTableID_Country: expectedValue
                };

            var cognosReport = Ext.create('Jda.SCExecutive.model.CognosReport', { jsonData: jsonData });

            var observedValue = cognosReport.extractDataRows('FooTableID', undefined, locationHierarchy);

            observedValue.should.eql(expectedValue);
        });

        it('Should match when the observed key is the provided key suffixed with "all" when the provided location hierarchy is root', function() {
            var expectedValue = [ 1, 2, 3, 4 ],
                locationHierarchy = Ext.create('Jda.SCExecutive.model.LocationHierarchy', { isRoot: true }),
                jsonData = {
                    FooTableID_All: expectedValue
                };

            var cognosReport = Ext.create('Jda.SCExecutive.model.CognosReport', { jsonData: jsonData });

            var observedValue = cognosReport.extractDataRows('FooTableID', undefined, locationHierarchy);

            observedValue.should.eql(expectedValue);
        });

        it('Should match when the observed key is the provided key suffixed with both period hierarchy type and location hierarchy level', function() {
            var expectedValue = [ 1, 2, 3, 4 ],
                periodHierarchy = Ext.create('Jda.SCExecutive.model.PeriodHierarchy', { type: 'Year' }),
                locationHierarchy = Ext.create('Jda.SCExecutive.model.LocationHierarchy', { level: 'Country' }),
                jsonData = {
                    FooTableID_Year_Country: expectedValue
                };

            var cognosReport = Ext.create('Jda.SCExecutive.model.CognosReport', { jsonData: jsonData });

            var observedValue = cognosReport.extractDataRows('FooTableID', periodHierarchy, locationHierarchy);

            observedValue.should.eql(expectedValue);
        });
    });

    describe('The load function', function() {
        var buildDataServiceUrlSpy; // needed because all the Jda globals on the test page aren't completely there

        before(function() {
            buildDataServiceUrlStub = sinon.stub(Jda, 'buildDataServiceUrl');
        });

        after(function() {
            buildDataServiceUrlStub.restore();
        });

        it('Should not reload a report with the same config.', function() {
            var cognosReport = Ext.create('Jda.SCExecutive.model.CognosReport');

            var ajaxRequestStub = sinon.stub(Ext.Ajax, 'request', function() {});

            cognosReport.load({ foo: 'bar' });
            cognosReport.load({ foo: 'bar' });

            ajaxRequestStub.callCount.should.equal(1);

            Ext.Ajax.request.restore();
        });

        it('Should reload a report with a different config.', function() {
            var cognosReport = Ext.create('Jda.SCExecutive.model.CognosReport');

            var ajaxRequestStub = sinon.stub(Ext.Ajax, 'request', function() {});

            cognosReport.load({ foo: 'bar' });
            cognosReport.load({ foo: 'baz' });

            ajaxRequestStub.callCount.should.equal(2);

            Ext.Ajax.request.restore();
        });
    });
});
