describe('The Period Hierarchy', function() {
    function _createPeriodHierarchy(type, value, count, start, end, parent) {
        var newPeriod = Ext.create('Jda.SCExecutive.model.PeriodHierarchy', {
            type: type,
            value: value,
            fiscalCount: count,
            parent: parent,
            isRoot: parent === undefined,
            start: start,
            end: end
        });

        if (parent) {
            parent.children().add(newPeriod);
        }

        return newPeriod;
    }

    var types = Jda.SCExecutive.model.PeriodHierarchy.types;
    var year = _createPeriodHierarchy(types.YEAR, '2013', undefined, '2013-01-01', '2013-12-31');
    var quarter = _createPeriodHierarchy(types.QUARTER, '2013-Q1', undefined, '2013-01-01', '2013-3-01', year);
    var month = _createPeriodHierarchy(types.MONTH, '2013-M1', 1, '2013-01-01', '2013-01-31', quarter);
    var week = _createPeriodHierarchy(types.WEEK, '2013-W1', 1, '2013-01-01', '2013-01-07', week);

    describe('The getDisplayString function', function() {
        var spiedFormat;

        beforeEach(function() {
            spiedFormat = sinon.spy(Ext.String, 'format');
        });

        afterEach(function() {
            Ext.String.format.restore();
        });

        it('Should return value for Year types', function() {
            var displayString = year.getDisplayString();

            displayString.should.equal(year.get('value'));
        });

        it('Should return Quarter x, y for quarters', function() {
            quarter.getDisplayString();

            spiedFormat.calledWith(sinon.match.any, '1', '2013').should.be.true;
        });

        it('Should return Long Start and End month', function() {
            month.getDisplayString();

            spiedFormat.calledWith(sinon.match.any, 'January 01', 'January 31, 2013').should.be.true;
        });

        it('Should return Short Start and End month', function() {
            month.getDisplayString(true);

            spiedFormat.calledWith(sinon.match.any, 'Jan 01', 'Jan 31, 2013').should.be.true;
        });

        it('Should return Long Start and End week', function() {
            week.getDisplayString();

            spiedFormat.calledWith(sinon.match.any, 'January 01', 'January 07, 2013', 1).should.be.true;
        });

        it('Should return Short Start and End week', function() {
            week.getDisplayString(true);

            spiedFormat.calledWith(sinon.match.any, 'Jan 01', 'Jan 07, 2013', 1).should.be.true;
        });
    });

    describe('The getPeriodFromDateString function', function() {
        it('Should look up appropriate child from a provided date string', function() {
            var lookedUpChild = year.getPeriodFromDateString('2013-Q1');

            lookedUpChild.should.equal(quarter);
        });
    });

    describe('The toString function', function() {
        it('Should return the value of the Period', function() {
            var yearToString = year.toString();

            yearToString.should.equal(year.get('value'));
        });
    });
});
