describe('The SC Executive Models', function() {
    var oldPageContextManager = Jda.mobility.plugins.PageContextManager;

    // Override this for demo mode.
    Jda.mobility.plugins.PageContextManager = {
        getLastPageContext: function() {
            return {
                isDemoMode: true
            };
        }
    };

    after(function() {
        Jda.mobility.plugins.PageContextManager = oldPageContextManager;
    });

    var PERIOD_HIERARCHY_REPORT_URL = '../www/resources/data/Period_Hierarchy/Period_Hierarchy.json';
    var LOCATION_HIERARCHY_REPORT_URL = '../www/resources/data/Location_Hierarchy/Location_Hierarchy.json';
    var _periodHierarchyReport = Ext.create('Jda.SCExecutive.model.PeriodHierarchyReport');
    var _locationHierarchyReport = Ext.create('Jda.SCExecutive.model.LocationHierarchyReport');

    Ext.define('Jda.SCExecutive.test.ModelDef', {
        mixins: [ 'Ext.mixin.Observable' ],

        config: {
            name: null,
            className: null,
            dataUrl: null,
            expectedFields: null,
            jsonData: null,
            model: null,
            isLoaded: false,
            threwWhileParsingWithBadLocation: false,
            threwWhileParsingWithBadPeriod: false
        },

        constructor: function(config) {
            this.initConfig(config);

            _periodHierarchyReport.on('load', this._onContextItemLoad, this);
            _locationHierarchyReport.on('load', this._onContextItemLoad, this);
        },

        updateJsonData: function(jsonData) {
            this._fireLoadIfAllItemsDone();
        },

        _onContextItemLoad: function() {
            this._fireLoadIfAllItemsDone();
        },

        _fireLoadIfAllItemsDone: function() {
            if (_periodHierarchyReport.getRootPeriodHierarchy() && _locationHierarchyReport.getRootLocationHierarchy() && this.getJsonData()) {
                this._parseGoodData();

                // Try parsing with the wrong period (one that doesn't map to the data set).
                // It should not throw, but the data may not make sense.
                try {
                    this._parseWithBadPeriod();
                }
                catch (e) {
                    this.setThrewWhileParsingWithBadPeriod(true);
                }

                // Try parsing with the wrong location (one that doesn't map to the data set).
                // It should not throw, but the data may not make sense.
                try {
                    this._parseWithBadLocation();
                }
                catch (e) {
                    this.setThrewWhileParsingWithBadLocation(true);
                }

                this.setIsLoaded(true);

                this.fireEvent('load');
            }
        },

        _parseGoodData: function() {
            var model = Ext.create(this.getClassName());
            model.setJsonData(this.getJsonData());

            // TODO identify a good pattern for specifying desired hierarchies
            var rootLocationHierarchy = _locationHierarchyReport.getRootLocationHierarchy();
            var usaHierarchy = rootLocationHierarchy.children().findRecord('code', 'USA');
            var lastWeek = _periodHierarchyReport.getPeriodGroups()[0][0];
            model.processResponse({ periodHierarchy: lastWeek, locationHierarchy: usaHierarchy });

            this.setModel(model);
        },

        _parseWithBadPeriod: function() {
            var model = Ext.create(this.getClassName());
            model.setJsonData(this.getJsonData());

            var rootLocationHierarchy = _locationHierarchyReport.getRootLocationHierarchy();
            var usaHierarchy = rootLocationHierarchy.children().findRecord('code', 'USA');
            var twoWeeksAgo = _periodHierarchyReport.getPeriodGroups()[0][1];
            model.processResponse({ periodHierarchy: twoWeeksAgo, locationHierarchy: usaHierarchy });
        },

        _parseWithBadLocation: function() {
            var model = Ext.create(this.getClassName());
            model.setJsonData(this.getJsonData());

            var rootLocationHierarchy = _locationHierarchyReport.getRootLocationHierarchy();
            var mxHierarchy = rootLocationHierarchy.children().findRecord('code', 'MX');
            var lastWeek = _periodHierarchyReport.getPeriodGroups()[0][0];
            model.processResponse({ periodHierarchy: lastWeek, locationHierarchy: mxHierarchy });
        }
    });

    // TODO load these externally?
    var modelDefs = [
        Ext.create('Jda.SCExecutive.test.ModelDef', {
            className: 'Jda.SCExecutive.model.AverageDaysOfSupply',
            dataUrl: '../www/resources/data/IN_Days_of_Supply/IN_Days_of_Supply-Country-USA-Year-2014-Quarter-2014-Q1-Month-2014-M01-Week-2014-W01.json',
            expectedFields: [
                { name: 'store', type: 'Ext.data.Store' },
                { name: 'periodHierarchy', type: 'Jda.SCExecutive.model.PeriodHierarchy' },
                { name: 'priorSupplyChainAverage', value: 39.7259417040359, type: 'number' },
                { name: 'supplyChainAverage', value: 40.4485944700461, type: 'number' },
                { name: 'lowestSupplyValue', value: 37.1201162790698, type: 'number' },
                { name: 'highestSupplyValue', value: 43.818954248366, type: 'number' }
            ]
        }),
        Ext.create('Jda.SCExecutive.test.ModelDef', {
            className: 'Jda.SCExecutive.model.CustomerServicePerformance',
            dataUrl: '../www/resources/data/CS_Customer_Service_Performance/CS_Customer_Service_Performance-Country-USA-Year-2014-Quarter-2014-Q1-Month-2014-M01-Week-2014-W01.json',
            expectedFields: [
                { name: 'store', type: 'Ext.data.Store' },
                { name: 'periodHierarchy', type: 'Jda.SCExecutive.model.PeriodHierarchy' },
                { name: 'locationHierarchies', type: 'array' },
                { name: 'lowestValue', value: 72.5, type: 'number' },
                { name: 'highestValue', value: 94.8717948717949, type: 'number' },
                { name: 'customerServiceLevelTargetPercent', value: 88, type: 'number' },
                { name: 'priorAverageCustomerServiceLevelPercent', value: 87.8378378378378, type: 'number' },
                { name: 'averageCustomerServiceLevelPercent', value: 88.6027044430135, type: 'number' },
                { name: 'ordersFilledValue', value: 2173473, type: 'number' },
                { name: 'priorOrdersFilledValue', value: 95565, type: 'number' },
                { name: 'customersCount', value: 18, type: 'number' },
                { name: 'loadsCount', value: 1553, type: 'number' }
            ]
        }),
        Ext.create('Jda.SCExecutive.test.ModelDef', {
            className: 'Jda.SCExecutive.model.ForecastAccuracy',
            dataUrl: '../www/resources/data/OV_Forecast_Accuracy/OV_Forecast_Accuracy-Country-USA-Year-2014-Quarter-2014-Q1-Month-2014-M01-Week-2014-W01.json',
            expectedFields: [
                { name: 'store', type: 'Ext.data.Store' },
                { name: 'periodHierarchy', type: 'Jda.SCExecutive.model.PeriodHierarchy' },
                { name: 'forecastAccuracyPercent', value: 79.87286989450911, type: 'number' },
                { name: 'forecastAccuracyPercentTarget', value: 6, type: 'number' },
                { name: 'totalSales', value: 147880, type: 'number' },
                { name: 'priorTotalSales', value: 147819, type: 'number' },
                { name: 'forecastedSales', value: 177645.76, type: 'number' },
                { name: 'priorForecastedSales', value: 177691.03, type: 'number' },
                { name: 'lag', value: 4, type: 'number' }
            ]
        }),
        Ext.create('Jda.SCExecutive.test.ModelDef', {
            className: 'Jda.SCExecutive.model.InventoryValue',
            dataUrl: '../www/resources/data/IN_Inventory_Value/IN_Inventory_Value-Country-USA-Year-2014-Quarter-2014-Q1-Month-2014-M01-Week-2014-W01.json',
            expectedFields: [
                { name: 'store', type: 'Ext.data.Store' },
                { name: 'locationHierarchies', type: 'array' },
                { name: 'periodHierarchy', type: 'Jda.SCExecutive.model.PeriodHierarchy' },
                { name: 'priorAverageInventoryValue', value: 2575606.48840336, type: 'number' },
                { name: 'averageInventoryValue', value: 2704223.07418968, type: 'number' },
                { name: 'priorAverageUnitValue', value: 508.789915966387, type: 'number' },
                { name: 'averageUnitValue', value: 539.159663865546, type: 'number' },
                { name: 'inventoryValueMaximum', value: 952703.274, type: 'number' },
                { name: 'inventoryValueTotalMaximum', value: 2872238.9205, type: 'number' }
            ]
        }),
        Ext.create('Jda.SCExecutive.test.ModelDef', {
            className: 'Jda.SCExecutive.model.LaborHours',
            dataUrl: '../www/resources/data/LA_Labor_Hours/LA_Labor_Hours-Country-USA-Year-2014-Quarter-2014-Q1-Month-2014-M01-Week-2014-W01.json',
            expectedFields: [
                { name: 'periodHierarchy', type: 'Jda.SCExecutive.model.PeriodHierarchy' },
                { name: 'store', type: 'Ext.data.Store' },
                { name: 'priorTotalRegularHours', value: 484, type: 'number' },
                { name: 'totalRegularHours', value: 446, type: 'number' },
                { name: 'priorTotalOvertimeHours', value: 73, type: 'number' },
                { name: 'totalOvertimeHours', value: 279, type: 'number' },
                { name: 'totalCombinedHours', value: 725, type: 'number' },
                { name: 'lowestValue', value: 6, type: 'number' },
                { name: 'highestValue', value: 159, type: 'number' }
            ]
        }),
        Ext.create('Jda.SCExecutive.test.ModelDef', {
            className: 'Jda.SCExecutive.model.LaborPerformance',
            dataUrl: '../www/resources/data/LA_Labor_Performance/LA_Labor_Performance-Country-USA-Year-2014-Quarter-2014-Q1-Month-2014-M01-Week-2014-W01.json',
            expectedFields: [
                { name: 'periodHierarchy', type: 'Jda.SCExecutive.model.PeriodHierarchy' },
                { name: 'colors', type: 'array' },
                { name: 'directPerformanceDetailsStore', type: 'Ext.data.Store' },
                { name: 'totalPerformanceDetailsStore', type: 'Ext.data.Store' },
                { name: 'totalHours', type: 'number', value: 546.777777777778 },
                { name: 'totalDirectHours', type: 'number', value: 490.77777777777743 },
                { name: 'totalIndirectHours', type: 'number', value: 56 },
                { name: 'priorTotalPerformance', type: 'number', value: 87.9089615931721 },
                { name: 'totalPerformance', type: 'number', value: 87.9089615931721 },
                { name: 'priorTotalEfficiency', type: 'number', value: 78.9054833076694 },
                { name: 'totalEfficiency', type: 'number', value: 78.9054833076694 }
            ]
        }),
        Ext.create('Jda.SCExecutive.test.ModelDef', {
            className: 'Jda.SCExecutive.model.LaborSpend',
            dataUrl: '../www/resources/data/LA_Labor_Spend/LA_Labor_Spend-Country-USA-Year-2014-Quarter-2014-Q1-Month-2014-M01-Week-2014-W01.json',
            expectedFields: [
                { name: 'periodHierarchy', type: 'Jda.SCExecutive.model.PeriodHierarchy' },
                { name: 'laborByPeriodStore', type: 'Ext.data.Store' },
                { name: 'locationHierarchies', type: 'array' },
                { name: 'laborSpend', value: 6606, type: 'number' },
                { name: 'laborBudgetSpend', value: 6606, type: 'number' },
                { name: 'laborBudget', value: 22401, type: 'number' },
                { name: 'maximumLocationValue', value: 364, type: 'number' },
                { name: 'maximumTotalValue', value: 1081, type: 'number' }
            ]
        }),
        Ext.create('Jda.SCExecutive.test.ModelDef', {
            className: 'Jda.SCExecutive.model.OnTimeDelivery',
            dataUrl: '../www/resources/data/TR_Transportation_Delivery_Performance/TR_Transportation_Delivery_Performance-Country-USA-Year-2014-Quarter-2014-Q1-Month-2014-M01-Week-2014-W01.json',
            expectedFields: [
                { name: 'periodHierarchy', type: 'Jda.SCExecutive.model.PeriodHierarchy' },
                { name: 'inboundOnTimePercent', value: 92.436974789916, type: 'number' },
                { name: 'inboundOnTimeTarget', value: 91, type: 'number' },
                { name: 'inboundLocationHierarchies', type: 'array' },
                { name: 'inboundStore', type: 'Ext.data.Store' },
                { name: 'outboundOnTimePercent', value: 89.9159663865546, type: 'number' },
                { name: 'outboundOnTimeTarget', value: 81, type: 'number' },
                { name: 'outboundLocationHierarchies', type: 'array' },
                { name: 'outboundStore', type: 'Ext.data.Store' },
                { name: 'totalOnTimePercent', value: 91.1764705882353, type: 'number' },
                { name: 'totalOnTimeTarget', value: 72, type: 'number' },
                { name: 'totalLocationHierarchies', type: 'array' },
                { name: 'totalStore', type: 'Ext.data.Store' }
            ]
        }),
        Ext.create('Jda.SCExecutive.test.ModelDef', {
            className: 'Jda.SCExecutive.model.OrderFill',
            dataUrl: '../www/resources/data/IN_Order_Fill_Rate/IN_Order_Fill_Rate-Country-USA-Year-2014-Quarter-2014-Q1-Month-2014-M01-Week-2014-W01.json',
            expectedFields: [
                { name: 'periodHierarchy', type: 'Jda.SCExecutive.model.PeriodHierarchy' },
                { name: 'inboundPartyCount', value: 11, type: 'number' },
                { name: 'inboundOrderFillValue', value: 1323721, type: 'number' },
                { name: 'inboundOrderFillCount', value: 946, type: 'number' },
                { name: 'inboundStore', type: 'Ext.data.Store' },
                { name: 'inboundMaximumValue', value: 194548, type: 'number' },
                { name: 'inboundMaximumCount', value: 137, type: 'number' },
                { name: 'outboundPartyCount', value: 18, type: 'number' },
                { name: 'outboundOrderFillValue', value: 2173473, type: 'number' },
                { name: 'outboundOrderFillCount', value: 1553, type: 'number' },
                { name: 'outboundStore', type: 'Ext.data.Store' },
                { name: 'outboundMaximumValue', value: 318606, type: 'number' },
                { name: 'outboundMaximumCount', value: 223, type: 'number' }
            ]
        }),
        Ext.create('Jda.SCExecutive.test.ModelDef', {
            className: 'Jda.SCExecutive.model.OrderFillRate',
            dataUrl: '../www/resources/data/CS_Order_Fill_Rate/CS_Order_Fill_Rate-Country-USA-Year-2014-Quarter-2014-Q1-Month-2014-M01-Week-2014-W01.json',
            expectedFields: [
                { name: 'store', type: 'Ext.data.Store' },
                { name: 'locationHierarchies', type: 'array' },
                { name: 'periodHierarchy', type: 'Jda.SCExecutive.model.PeriodHierarchy' },
                { name: 'lowestValue', value: 95, type: 'number' },
                { name: 'highestValue', value: 100, type: 'number' },
                { name: 'averageOutboundOrderFillRatePercent', value: 99.7198879551821, type: 'number' },
                { name: 'orderFillRateTargetPercent', value: 95, type: 'number' },
                { name: 'totalOrdersCount', value: 2499, type: 'number' },
                { name: 'ordersFilledCount', value: 2492, type: 'number' }
            ]
        }),
        Ext.create('Jda.SCExecutive.test.ModelDef', {
            className: 'Jda.SCExecutive.model.PartyLoads',
            dataUrl: '../www/resources/data/TR_Transportation_Activity_Totals/TR_Transportation_Activity_Totals-Country-USA-Year-2014-Quarter-2014-Q1-Month-2014-M01-Week-2014-W01.json',
            expectedFields: [
                { name: 'inboundLoads', value: 403, type: 'number' },
                { name: 'inboundAverageCost', value: 696.616279069767, type: 'number' },
                { name: 'inboundAverageValue', value: 1399.2822410148, type: 'number' },
                { name: 'inboundParties', value: 12, type: 'number' },
                { name: 'inboundCarriers', value: 1, type: 'number' },
                { name: 'inboundSuppliers', value: 11, type: 'number' },
                { name: 'outboundLoads', value: 668, type: 'number' },
                { name: 'outboundAverageCost', value: 703.291693496458, type: 'number' },
                { name: 'outboundAverageValue', value: 1399.53187379266, type: 'number' },
                { name: 'outboundParties', value: 19, type: 'number' },
                { name: 'outboundCarriers', value: 1, type: 'number' },
                { name: 'outboundCustomers', value: 18, type: 'number' },
                { name: 'totalLoads', value: 1071, type: 'number' },
                { name: 'totalAverageCost', value: 1399.907972566225, type: 'number' },
                { name: 'totalAverageValue', value: 2798.81411480746, type: 'number' },
                { name: 'totalParties', value: 31, type: 'number' },
                { name: 'totalCarriers', value: 2, type: 'number' },
                { name: 'totalCustomers', value: 18, type: 'number' },
                { name: 'totalSuppliers', value: 11, type: 'number' }
            ]
        }),
        Ext.create('Jda.SCExecutive.test.ModelDef', {
            className: 'Jda.SCExecutive.model.TopTenCustomers',
            dataUrl: '../www/resources/data/CS_Top_10_Customers/CS_Top_10_Customers-Country-USA-Year-2014-Quarter-2014-Q1-Month-2014-M01-Week-2014-W01.json',
            expectedFields: [
                { name: 'store', type: 'Ext.data.Store' }
            ]
        }),
        Ext.create('Jda.SCExecutive.test.ModelDef', {
            className: 'Jda.SCExecutive.model.TransportationSpend',
            dataUrl: '../www/resources/data/TR_Transportation_Cost_Summary/TR_Transportation_Cost_Summary-Country-USA-Year-2014-Quarter-2014-Q1-Month-2014-M01-Week-2014-W01.json',
            expectedFields: [
                { name: 'periodHierarchy', type: 'Jda.SCExecutive.model.PeriodHierarchy' },
                { name: 'inboundSpend', value: 339727, type: 'number' },
                { name: 'priorInboundSpend', value: 36954, type: 'number' },
                { name: 'inboundBudgetSpend', value: 339727, type: 'number' },
                { name: 'inboundBudget', value: 866666.666666667, type: 'number' },
                { name: 'inboundStore', type: 'Ext.data.Store' },
                { name: 'inboundMaximumValue', value: 16035, type: 'number' },
                { name: 'inboundLocationHierarchies', type: 'array' },
                { name: 'outboundSpend', value: 557207, type: 'number' },
                { name: 'priorOutboundSpend', value: 58031, type: 'number' },
                { name: 'outboundBudgetSpend', value: 557207, type: 'number' },
                { name: 'outboundBudget', value: 966666.666666667, type: 'number' },
                { name: 'outboundStore', type: 'Ext.data.Store' },
                { name: 'outboundMaximumValue', value: 25558, type: 'number' },
                { name: 'outboundLocationHierarchies', type: 'array' },
                { name: 'totalSpend', value: 896934, type: 'number' },
                { name: 'totalBudgetSpend', value: 896934, type: 'number' },
                { name: 'totalBudget', value: 1833333.333333334, type: 'number' },
                { name: 'totalStore', type: 'Ext.data.Store' },
                { name: 'totalMaximumValue', value: 130084, type: 'number' },
                { name: 'totalLocationHierarchies', type: 'array' }
            ]
        }),
        Ext.create('Jda.SCExecutive.test.ModelDef', {
            className: 'Jda.SCExecutive.model.UnshippedOrders',
            dataUrl: '../www/resources/data/CS_Unshipped_Orders/CS_Unshipped_Orders-Country-USA.json',
            expectedFields: [
                { name: 'store', type: 'Ext.data.Store' },
                { name: 'totalRevenue', value: 459385, type: 'number' },
                { name: 'unshippedOrdersCount', value: 341, type: 'number' },
                { name: 'maximumValue', value: 253067, type: 'number' }
            ]
        }),
        Ext.create('Jda.SCExecutive.test.ModelDef', {
            className: 'Jda.SCExecutive.model.WarehouseUtilization',
            dataUrl: '../www/resources/data/IN_Warehouse_Utilization/IN_Warehouse_Utilization-Country-USA-Year-2014-Quarter-2014-Q1-Month-2014-M01-Week-2014-W01.json',
            expectedFields: [
                { name: 'store', type: 'Ext.data.Store' },
                { name: 'utilizationPercent', value: 80.3921568627451, type: 'number' }
            ]
        })
    ];

    function _createGetter(field) {
        var firstLetter = field.charAt(0);
        var rest = field.substring(1);

        return 'get' + firstLetter.toUpperCase() + rest;
    }

    function _getValueForModelDefField(modelDef, fieldName, valueFn) {
        var model = modelDef.getModel();
        var getter = _createGetter(fieldName);
        var value = model[getter]();

        valueFn(value);
    }

    function _getValueForModelDefFieldWhenLoaded(modelDef, fieldName, valueFn) {
        // If we don't have data yet, we have to wait for the model load to parse and return the value
        if (!modelDef.getIsLoaded()) {
            modelDef.on('load', function() {
                _getValueForModelDefField(modelDef, fieldName, valueFn);
            });
        }
        // Otherwise, we can parse and return the value right away.
        else {
            _getValueForModelDefField(modelDef, fieldName, valueFn);
        }
    }

    function _validateFieldNameOnModelDefIsDefined(fieldName, modelDef, done) {
        _getValueForModelDefFieldWhenLoaded(modelDef, fieldName, function(value) {
            Ext.isDefined(value).should.be.true;

            done();
        });
    }

    function _validateValueMatchesExpected(fieldName, modelDef, expectedValue, done) {
        _getValueForModelDefFieldWhenLoaded(modelDef, fieldName, function(value) {
            value.should.equal(expectedValue);

            done();
        });
    }

    function _validateValueIsOfExpectedType(fieldName, modelDef, type, done) {
        _getValueForModelDefFieldWhenLoaded(modelDef, fieldName, function(value) {
            if (type === 'number') {
                Ext.isNumber(value).should.be.true;
            }
            else if (type === 'string') {
                Ext.isString(value).should.be.true;
            }
            else if (type === 'array') {
                Ext.isArray(value).should.be.true;
            }
            else {
                var clazz = Ext.ClassManager.get(type);

                if (!clazz) {
                    throw new Error('Model tester does not recognize type: ' + type);
                }

                (value instanceof clazz).should.be.true;
            }

            done();
        });
    }

    function _validateFieldOnModelDef(field, modelDef) {
        var isFieldJustString = Ext.isString(field);
        var fieldName = isFieldJustString ? field : field.name;

        describe('The ' + fieldName + ' field', function() {

            // First, validate it's defined
            it('Should have a value', function(done) {
                _validateFieldNameOnModelDefIsDefined(fieldName, modelDef, done);
            });

            // If this field is only a string, nothing else to validate
            if (isFieldJustString) {
                return;
            }

            // Otherwise, start looking for specifics, like value and type
            if (field.value) {
                it('Should have a value equal to ' + field.value, function(done) {
                    _validateValueMatchesExpected(fieldName, modelDef, field.value, done);
                });
            }

            if (field.type) {
                it('Should be of type ' + field.type, function(done) {
                    _validateValueIsOfExpectedType(fieldName, modelDef, field.type, done);
                });
            }

            // TODO expect store length
        });
    }

    function _testModelDef(modelDef) {
        describe(modelDef.getClassName(), function() {
            var expectedFields = modelDef.getExpectedFields();
            for (var fieldIndex = 0; fieldIndex < expectedFields.length; fieldIndex++) {
                var expectedField = expectedFields[fieldIndex];

                _validateFieldOnModelDef(expectedField, modelDef);
            }

            it('Should not throw when parsing with invalid location hierarchies', function(done) {
                if (!modelDef.getIsLoaded()) {
                    modelDef.on('load', function() {
                        modelDef.getThrewWhileParsingWithBadLocation().should.be.false;
                        done();
                    });
                }
                // Otherwise, we can parse and return the value right away.
                else {
                    modelDef.getThrewWhileParsingWithBadLocation().should.be.false;
                    done();
                }
            });

            it('Should not throw when parsing with invalid period hierarchies', function(done) {
                if (!modelDef.getIsLoaded()) {
                    modelDef.on('load', function() {
                        modelDef.getThrewWhileParsingWithBadPeriod().should.be.false;
                        done();
                    });
                }
                // Otherwise, we can parse and return the value right away.
                else {
                    modelDef.getThrewWhileParsingWithBadPeriod().should.be.false;
                    done();
                }
            });
        });
    }

    function _testModels() {
        for (var modelDefIndex = 0; modelDefIndex < modelDefs.length; modelDefIndex++) {
            var modelDef = modelDefs[modelDefIndex];

            _testModelDef(modelDef);
        }
    }

    function _handleContextItemDataLoad(options, success, response) {
        var report = options.report;

        if (!success) {
            console.warn('Failed to load data for hierarchy report.', response);
            return;
        }

        try {
            var jsonData = JSON.parse(response.responseText).data[0];

            report.setJsonData(jsonData);
            report.processResponse();
            report.fireEvent('load');
        }
        catch (e) {
            console.error('Error parsing data for hierarchy report.', e);
        }
    }

    function _loadHierarchyReports() {
        Ext.Ajax.request({
            url: LOCATION_HIERARCHY_REPORT_URL,
            report: _locationHierarchyReport,
            callback: _handleContextItemDataLoad
        });

        Ext.Ajax.request({
            url: PERIOD_HIERARCHY_REPORT_URL,
            report: _periodHierarchyReport,
            callback: _handleContextItemDataLoad
        });
    }

    function _handleDataLoadForModel(options, success, response) {
        var modelDef = options.modelDef;

        if (!success) {
            console.warn('Failed to load data for model "' + modelDef.getClassName() + '," skipping.');
            return;
        }

        try {
            var jsonData = JSON.parse(response.responseText).data[0];

            modelDef.setJsonData(jsonData);
        }
        catch (e) {
            console.error('Error parsing data for model "' + modelDef.getClassName() + '," skipping.');
        }
    }

    function _loadModelDefData() {
        for (var modelDefIndex = 0; modelDefIndex < modelDefs.length; modelDefIndex++) {
            var modelDef = modelDefs[modelDefIndex];

            Ext.Ajax.request({
                url: modelDef.getDataUrl(),
                modelDef: modelDef,
                callback: _handleDataLoadForModel
            });
        }
    }

    _loadHierarchyReports();
    _loadModelDefData();
    _testModels();
});
