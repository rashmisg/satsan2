describe('The SCExecutive Controller', function() {
    describe('The bindViewToModel method', function() {
        it('Should call loadFromModel on the view when the model fires "load"', function() {
            var view = { loadFromModel: Ext.emptyFn };
            var viewStub = sinon.mock(view);

            viewStub.expects('loadFromModel');

            var model = Ext.create('Jda.SCExecutive.model.CognosReport');

            Jda.SCExecutive.controller.SCExecutiveController.prototype.bindViewToModel(view, model);

            model.fireEvent('load');

            viewStub.verify();
        });
    });
});
