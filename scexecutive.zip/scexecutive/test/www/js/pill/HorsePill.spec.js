describe('The Horse Pill', function() {
    var yearPeriod = Ext.create('Jda.SCExecutive.model.PeriodHierarchy', { type: Jda.SCExecutive.model.PeriodHierarchy.types.YEAR });
    var quarterPeriod = Ext.create('Jda.SCExecutive.model.PeriodHierarchy', { type: Jda.SCExecutive.model.PeriodHierarchy.types.QUARTER });
    var monthPeriod = Ext.create('Jda.SCExecutive.model.PeriodHierarchy', { type: Jda.SCExecutive.model.PeriodHierarchy.types.MONTH });
    var weekPeriod = Ext.create('Jda.SCExecutive.model.PeriodHierarchy', { type: Jda.SCExecutive.model.PeriodHierarchy.types.WEEK });
    
    it('Should set the text to a formatted currency, and set the detail text to the string for the period when updateAverageTextForPeriod function is called', function() {
        var horsePill = Ext.create('Jda.SCExecutive.pill.HorsePill');

        horsePill.displaySpendingTextForPeriod(21400, weekPeriod);

        horsePill.getText().should.equal('$21.4K');
        horsePill.getDetailText().should.equal(Jda.getMessage('jda.scexecutive.horsepill.SpentForWeek'));

        horsePill.displaySpendingTextForPeriod(214000, monthPeriod);

        horsePill.getText().should.equal('$214K');
        horsePill.getDetailText().should.equal(Jda.getMessage('jda.scexecutive.horsepill.SpentForMonth'));

        horsePill.displaySpendingTextForPeriod(2140000, quarterPeriod);

        horsePill.getText().should.equal('$2.14M');
        horsePill.getDetailText().should.equal(Jda.getMessage('jda.scexecutive.horsepill.SpentForQuarter'));

        horsePill.displaySpendingTextForPeriod(21400000, yearPeriod);

        horsePill.getText().should.equal('$21.4M');
        horsePill.getDetailText().should.equal(Jda.getMessage('jda.scexecutive.horsepill.SpentForYear'));
    });

    it('Should set the text to a formatted currency, and set the detail text to the string for the period when updateAverageTextForPeriod function is called', function() {
        var horsePill = Ext.create('Jda.SCExecutive.pill.HorsePill');

        horsePill.displayAverageTextForPeriod(2.14, weekPeriod);

        horsePill.getText().should.equal('2%');
        horsePill.getDetailText().should.equal(Jda.getMessage('jda.scexecutive.horsepill.AverageForWeek'));

        horsePill.displayAverageTextForPeriod(21.4, monthPeriod);

        horsePill.getText().should.equal('21%');
        horsePill.getDetailText().should.equal(Jda.getMessage('jda.scexecutive.horsepill.AverageForMonth'));

        horsePill.displayAverageTextForPeriod(24.444, quarterPeriod);

        horsePill.getText().should.equal('24%');
        horsePill.getDetailText().should.equal(Jda.getMessage('jda.scexecutive.horsepill.AverageForQuarter'));

        horsePill.displayAverageTextForPeriod(39.99999, yearPeriod);

        horsePill.getText().should.equal('39%');
        horsePill.getDetailText().should.equal(Jda.getMessage('jda.scexecutive.horsepill.AverageForYear'));
    });

    it('Should set cls to .horse.pill.unknown when "good" has not been set', function() {
        var horsePill = Ext.create('Jda.SCExecutive.pill.HorsePill');

        horsePill.getCls().should.eql([ 'horse', 'pill', 'unknown' ]);
    });

    it('Should set cls to .horse.pill.good when "good" is set to true', function() {
        var horsePill = Ext.create('Jda.SCExecutive.pill.HorsePill');

        horsePill.setGood(true);

        horsePill.getCls().should.eql([ 'horse', 'pill', 'good' ]);
    });

    it('Should set cls to .horse.pill.bad when "good" is set to false', function() {
        var horsePill = Ext.create('Jda.SCExecutive.pill.HorsePill');

        horsePill.setGood(false);

        horsePill.getCls().should.eql([ 'horse', 'pill', 'bad' ]);
    });

    it('Should set cls to .horse.pill.unknown when "good" is set to a non-boolean value', function() {
        var horsePill = Ext.create('Jda.SCExecutive.pill.HorsePill');

        horsePill.setGood(315);

        horsePill.getCls().should.eql([ 'horse', 'pill', 'unknown' ]);
    });
});
