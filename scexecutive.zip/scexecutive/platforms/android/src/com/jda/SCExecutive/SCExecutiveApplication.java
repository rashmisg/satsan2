package com.jda.SCExecutive;

import com.jda.mobility.HybridApplication;
import com.jda.mobility.MobileToolsApplication;

public class SCExecutiveApplication extends HybridApplication {
    @Override
    public void onCreate() {
        super.onCreate();

        MobileToolsApplication.launch(this, getString(R.string.app_name));
        MobileToolsApplication.setUseLocalTabsJson(true);
        MobileToolsApplication.setUseEmbeddedAppCode(true);
    }
}
