cordova.define('cordova/plugin_list', function(require, exports, module) {
module.exports = [
    {
        "file": "plugins/com.jda.mobility.NavigationBarComponentManager/src/www/NavigationBarComponentManager.js",
        "id": "com.jda.mobility.NavigationBarComponentManager.NavigationBarComponentManager",
        "clobbers": [
            "Jda.mobility.plugins.NavigationBarComponentManager"
        ]
    },
    {
        "file": "plugins/com.jda.mobility.NotificationManager/src/www/NotificationManager.js",
        "id": "com.jda.mobility.NotificationManager.NotificationManager",
        "clobbers": [
            "Jda.mobility.plugins.NotificationManager"
        ]
    },
    {
        "file": "plugins/com.jda.mobility.PageContextManager/src/www/PageContextManager.js",
        "id": "com.jda.mobility.PageContextManager.PageContextManager",
        "clobbers": [
            "Jda.mobility.plugins.PageContextManager"
        ]
    },
    {
        "file": "plugins/com.jda.mobility.DataCacheManager/src/www/DataCacheManager.js",
        "id": "com.jda.mobility.DataCacheManager.DataCacheManager",
        "clobbers": [
            "Jda.mobility.plugins.DataCacheManager"
        ]
    },
    {
        "file": "plugins/com.jda.mobility.Logger/src/www/Logger.js",
        "id": "com.jda.mobility.Logger.Logger",
        "clobbers": [
            "Jda.mobility.plugins.Logger"
        ]
    },
    {
        "file": "plugins/com.jda.mobility.DatePicker/src/www/android/DatePicker.js",
        "id": "com.jda.mobility.DatePicker.DatePicker",
        "clobbers": [
            "Jda.mobility.plugins.DatePicker"
        ]
    },
    {
        "file": "plugins/com.jda.mobility.DialogManager/src/www/android/DialogManager.js",
        "id": "com.jda.mobility.DialogManager.DialogManager",
        "clobbers": [
            "Jda.mobility.plugins.DialogManager"
        ]
    },
    {
        "file": "plugins/com.jda.mobility.NavigationStackManager/src/www/NavigationStackManager.js",
        "id": "com.jda.mobility.NavigationStackManager.NavigationStackManager",
        "clobbers": [
            "Jda.mobility.plugins.NavigationStackManager"
        ]
    },
    {
        "file": "plugins/com.jda.mobility.Mailer/src/www/Mailer.js",
        "id": "com.jda.mobility.Mailer.Mailer",
        "clobbers": [
            "Jda.mobility.plugins.Mailer"
        ]
    },
    {
        "file": "plugins/com.jda.mobility.ScreenSharer/src/www/ScreenSharer.js",
        "id": "com.jda.mobility.ScreenSharer.ScreenSharer",
        "clobbers": [
            "Jda.mobility.plugins.ScreenSharer"
        ]
    },
    {
        "file": "plugins/com.jda.mobility.LoadingMaskManager/src/www/LoadingMaskManager.js",
        "id": "com.jda.mobility.LoadingMaskManager.LoadingMaskManager",
        "clobbers": [
            "Jda.mobility.plugins.LoadingMaskManager"
        ]
    },
    {
        "file": "plugins/com.jda.mobility.TelSms/src/www/TelSms.js",
        "id": "com.jda.mobility.TelSms.TelSms",
        "clobbers": [
            "Jda.mobility.plugins.TelSms"
        ]
    },
    {
        "file": "plugins/cordova-plugin-datepicker/www/android/DatePicker.js",
        "id": "cordova-plugin-datepicker.DatePicker",
        "clobbers": [
            "datePicker"
        ]
    }
];
module.exports.metadata = 
// TOP OF METADATA
{
    "cordova-plugin-whitelist": "1.3.2",
    "com.jda.mobility.NavigationBarComponentManager": "0.0.1",
    "com.jda.mobility.NotificationManager": "0.0.1",
    "com.jda.mobility.PageContextManager": "0.0.1",
    "com.jda.mobility.DataCacheManager": "0.0.1",
    "com.jda.mobility.Logger": "1.0.0",
    "com.jda.mobility.DatePicker": "0.1",
    "com.jda.mobility.DialogManager": "0.1",
    "com.jda.mobility.NavigationStackManager": "0.0.1",
    "com.jda.mobility.Mailer": "0.1",
    "com.jda.mobility.ScreenSharer": "0.1",
    "com.jda.mobility.LoadingMaskManager": "0.0.1",
    "com.jda.mobility.TelSms": "0.0.1",
    "cordova-plugin-datepicker": "0.9.1"
}
// BOTTOM OF METADATA
});