cordova.define("com.jda.mobility.DatePicker.DatePicker", function(require, exports, module) { exports.show = function(options, callback) {
    window.datePicker.show(options, callback);
};

});
