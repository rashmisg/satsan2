//
//  SCExecutiveSettingsController.m
//  SCExecutive
//
//  Created by Rice, Kevin on 10/24/14.
//  Copyright (c) 2014 JDA Software, Inc. All rights reserved.
//

#import "JMSettingsController.h"

extern NSString * const CORPORATE_CURRENCY_REGION_SYMBOL;

@interface SCExecutiveSettingsController : JMSettingsController

/**
 * Gets the current country symbol set in NSUserDefaults or looks it up
 * based on the current locale of the device.
 */
+ (NSString *)getCurrentCountrySymbol;

@end