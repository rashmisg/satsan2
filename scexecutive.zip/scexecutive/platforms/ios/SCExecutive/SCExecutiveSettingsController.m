//
//  SCExecutiveSettingsController.m
//  SCExecutive
//
//  Created by Rice, Kevin on 10/24/14.
//  Copyright (c) 2014 JDA Software, Inc. All rights reserved.
//

#import "SCExecutiveSettingsController.h"
#import "JMListSelectorPopoverController.h"
#import "JMButton.h"
#import "JMStyle.h"
#import "JMPageContextManager.h"
#import "JMMobileToolsApplication.h"
#import "JMUserAccount.h"
#import "AppDelegate.h"
#import "JMTabBarController.h"
#import "JMLoadingView.h"

@interface SCExecutiveSettingsController () <UIDocumentInteractionControllerDelegate, ListSelectorPopoverControllerDelegate>

@property (strong, nonatomic) JMListSelectorPopoverController *listSelector;
@property (strong, nonatomic) JMButton *regionSelectorButton;
@property (strong, nonatomic) JMButton *locationHierarchyEditorButton;
@property (strong, nonatomic) NSMutableDictionary *countryDict;
@property (strong, nonatomic) NSArray *countryArray;

@end

NSString * const CORPORATE_CURRENCY_REGION_CHANGE_NOTIFICATION = @"CORPORATE_CURRENCY_REGION_CHANGE_NOTIFICATION";
NSString * const CORPORATE_CURRENCY_REGION_NAME = @"CORPORATE_CURRENCY_REGION_NAME";
NSString * const CORPORATE_CURRENCY_REGION_SYMBOL = @"CORPORATE_CURRENCY_REGION_SYMBOL";

@implementation SCExecutiveSettingsController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    UIView *parentContainerView;
    UIButton *anchorView;
    
    for (id subview in self.view.subviews) {
        // There are two subviews. We don't want the label, we want the container.
        // We can't lookup by "isKindOfClass:[UIView" because UILabel is a UIView.
        if (![subview isKindOfClass:[UILabel class]]) {
            parentContainerView = subview;
            break;
        }
    }
    
    for (id containerViewSubview in parentContainerView.subviews) {
        // We want the last button in this view to be able to anchor other
        // views relative to it.
        if ([containerViewSubview isKindOfClass:[UIButton class]]) {
            anchorView = containerViewSubview;
        }
    }
    
    UILabel *corporateCurrencyRegionLabel = [[UILabel alloc] initWithFrame:CGRectZero];
    [corporateCurrencyRegionLabel setTranslatesAutoresizingMaskIntoConstraints:NO];
    [corporateCurrencyRegionLabel setTextAlignment:NSTextAlignmentLeft];
    [corporateCurrencyRegionLabel setTextColor:[JMStyle darkGreyColor]];
    [corporateCurrencyRegionLabel setFont:[JMStyle fontWithWeight:@"normal" andSize:14.0]];
    [corporateCurrencyRegionLabel setText:@"Corporate Currency Region"];

    [self setupCountryList];
    
    self.regionSelectorButton = [[JMButton alloc] initWithFrame:CGRectZero];
    [self.regionSelectorButton setTitle:[self getCurrentCountryName] forState:UIControlStateNormal];
    [self.regionSelectorButton setTranslatesAutoresizingMaskIntoConstraints:NO];
    [self.regionSelectorButton addTarget:self action:@selector(regionSelectorButtonTapped:) forControlEvents:UIControlEventTouchUpInside];
    
    [parentContainerView addSubview:corporateCurrencyRegionLabel];
    [parentContainerView addSubview:self.regionSelectorButton];
    
    [parentContainerView addConstraint:[NSLayoutConstraint constraintWithItem:corporateCurrencyRegionLabel attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:anchorView attribute:NSLayoutAttributeBottom multiplier:1 constant:20]];
    [parentContainerView addConstraint:[NSLayoutConstraint constraintWithItem:corporateCurrencyRegionLabel attribute:NSLayoutAttributeLeft relatedBy:NSLayoutRelationEqual toItem:anchorView attribute:NSLayoutAttributeLeft multiplier:1 constant:0]];
    [parentContainerView addConstraint:[NSLayoutConstraint constraintWithItem:corporateCurrencyRegionLabel attribute:NSLayoutAttributeRight relatedBy:NSLayoutRelationEqual toItem:anchorView attribute:NSLayoutAttributeRight multiplier:1 constant:0]];
    
    [parentContainerView addConstraint:[NSLayoutConstraint constraintWithItem:self.regionSelectorButton attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:corporateCurrencyRegionLabel attribute:NSLayoutAttributeBottom multiplier:1 constant:4]];
    [parentContainerView addConstraint:[NSLayoutConstraint constraintWithItem:self.regionSelectorButton attribute:NSLayoutAttributeLeft relatedBy:NSLayoutRelationEqual toItem:corporateCurrencyRegionLabel attribute:NSLayoutAttributeLeft multiplier:1 constant:0]];
    [parentContainerView addConstraint:[NSLayoutConstraint constraintWithItem:self.regionSelectorButton attribute:NSLayoutAttributeRight relatedBy:NSLayoutRelationEqual toItem:corporateCurrencyRegionLabel attribute:NSLayoutAttributeRight multiplier:1 constant:0]];
    
    
    // If in demo mode, add the location hierarchy editor button
    CPSCustomerRecord *customerRecord = [[JMUserAccount account] customerRecord];
    
    if (customerRecord.isDemo) {
        self.locationHierarchyEditorButton = [[JMButton alloc] initWithFrame:CGRectZero];
        [self.locationHierarchyEditorButton setTitle:@"Edit Location Hierarchy" forState:UIControlStateNormal];
        [self.locationHierarchyEditorButton setTranslatesAutoresizingMaskIntoConstraints:NO];
        [self.locationHierarchyEditorButton addTarget:self action:@selector(locationHierarchyEditorButtonTapped:) forControlEvents:UIControlEventTouchUpInside];
        
        [parentContainerView addSubview:self.locationHierarchyEditorButton];
        
        [parentContainerView addConstraint:[NSLayoutConstraint constraintWithItem:self.locationHierarchyEditorButton attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:self.regionSelectorButton attribute:NSLayoutAttributeBottom multiplier:1 constant:20]];
        [parentContainerView addConstraint:[NSLayoutConstraint constraintWithItem:self.locationHierarchyEditorButton attribute:NSLayoutAttributeLeft relatedBy:NSLayoutRelationEqual toItem:anchorView attribute:NSLayoutAttributeLeft multiplier:1 constant:0]];
        [parentContainerView addConstraint:[NSLayoutConstraint constraintWithItem:self.locationHierarchyEditorButton attribute:NSLayoutAttributeRight relatedBy:NSLayoutRelationEqual toItem:anchorView attribute:NSLayoutAttributeRight multiplier:1 constant:0]];
    }
}

- (void)setupCountryList {
    NSArray *supportedCountryCodes = @[ @"CA", @"CN", @"DE", @"ES", @"FR", @"GB", @"IN", @"JP", @"MX", @"US" ];

    NSLocale *locale = [NSLocale systemLocale];
    NSString *language = [locale objectForKey:NSLocaleLanguageCode];
    
    self.countryDict = [[NSMutableDictionary alloc] init];

    NSNumberFormatter *formatter = [[NSNumberFormatter alloc] init];
    [formatter setNumberStyle:NSNumberFormatterCurrencyStyle];

    for (NSString *countryCode in supportedCountryCodes) {
        NSString *countryDisplayName = [locale displayNameForKey:NSLocaleCountryCode value:countryCode];
        
        NSString *localeIdentifier = [NSString stringWithFormat:@"%@_%@", language, countryCode];
        NSLocale *currencyLocale = [[NSLocale alloc] initWithLocaleIdentifier:localeIdentifier];
        [formatter setLocale:currencyLocale];

        [self.countryDict setValue:[formatter currencySymbol] forKey:countryDisplayName];
    }

    self.countryArray = [[self.countryDict allKeys] sortedArrayUsingSelector:@selector(localizedCompare:)];
}

+ (NSString *)getCurrentCountrySymbol {
    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
    NSString *currencySymbol = [userDefaults stringForKey:CORPORATE_CURRENCY_REGION_SYMBOL];
    
    if (!currencySymbol) {
        NSNumberFormatter *formatter = [[NSNumberFormatter alloc] init];
        [formatter setNumberStyle:NSNumberFormatterCurrencyStyle];
        [formatter setLocale:[NSLocale currentLocale]];
        currencySymbol = [formatter currencySymbol];
        [userDefaults setObject:currencySymbol forKey:CORPORATE_CURRENCY_REGION_SYMBOL];
        [userDefaults synchronize];
    }
    return currencySymbol;
}

- (NSString *)getCurrentCountryName {
    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
    NSString *countryDisplayName = [userDefaults objectForKey:CORPORATE_CURRENCY_REGION_NAME];
    
    if (!countryDisplayName) {
        NSLocale *locale = [NSLocale currentLocale];
        NSString *countryCode = [locale objectForKey:NSLocaleCountryCode];
        countryDisplayName = [[NSLocale systemLocale] displayNameForKey:NSLocaleCountryCode value:countryCode];
        [userDefaults setObject:countryDisplayName forKey:CORPORATE_CURRENCY_REGION_NAME];
        [userDefaults synchronize];
    }

    return countryDisplayName;
}

- (void)locationHierarchyEditorButtonTapped:(UIButton *)button {
    CDVViewController *sharedCordova = [JMSenchaWebViewController sharedCordova];
    
    NSString *script = @"Jda.SCExecutive.editor.LocationHierarchyEditor.showEditorView();";
    
    [sharedCordova.webView stringByEvaluatingJavaScriptFromString:script];
    
    AppDelegate *appDelegate = (AppDelegate *)[UIApplication sharedApplication].delegate;
    
    JMTabBarController *tabBarController = (JMTabBarController *)appDelegate.window.rootViewController;
    
    [tabBarController setSelectedIndex:0];
}

#pragma mark - DropDown Handler
- (void)regionSelectorButtonTapped:(UIButton *)regionSelectorButton {
    [self showListSelectorForDropDownArray:self.countryArray];
}

- (void)showListSelectorForDropDownArray:(NSArray *)dropDownArray {
    self.listSelector = [JMListSelectorPopoverController listSelectorPopoverControllerWithItems:dropDownArray headerTitle:nil];
    self.listSelector.listSelectorDelegate = self;
    self.listSelector.delegate = self;
    
    // Select the value
    NSUInteger index = [dropDownArray indexOfObject:[self.regionSelectorButton titleForState:UIControlStateNormal]];
    [self.listSelector setSelection:[NSIndexPath indexPathForRow:index inSection:0]];
    
    CGRect frame = self.regionSelectorButton.frame;
    CGRect anchorFrame = CGRectMake(frame.size.width / 2, frame.size.height, 1, 1);
    
    [self.listSelector presentPopoverFromRect:anchorFrame inView:self.regionSelectorButton permittedArrowDirections:UIPopoverArrowDirectionUp animated:YES];
}

#pragma mark - ListSelector Handler
- (void)listSelector:(JMListSelectorPopoverController *)listSelector didUpdateSelection:(NSIndexPath *)selection {
    NSString *countryDisplayName = self.countryArray[selection.row];
    [self.regionSelectorButton setTitle:countryDisplayName forState:UIControlStateNormal];
    [self.listSelector dismissPopoverAnimated:YES];
    self.listSelector = nil;

    NSString *currencySymbol = [self.countryDict valueForKey:countryDisplayName];
    [JMPageContextManager setContextItem:currencySymbol forKey:CORPORATE_CURRENCY_REGION_SYMBOL];
    NSDictionary *corporateCurrencyRegionDict = @{ CORPORATE_CURRENCY_REGION_SYMBOL: currencySymbol };
    [[NSNotificationCenter defaultCenter] postNotificationName:CORPORATE_CURRENCY_REGION_CHANGE_NOTIFICATION object:nil userInfo:corporateCurrencyRegionDict];
    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
    [userDefaults setObject:currencySymbol forKey:CORPORATE_CURRENCY_REGION_SYMBOL];
    [userDefaults setObject:countryDisplayName forKey:CORPORATE_CURRENCY_REGION_NAME];
    [userDefaults synchronize];
    
    [[JMLoadingView applicationLoadingView] displayLoadingIndicator];
    [JMMobileToolsApplication reloadWebView];
}

- (void)popoverControllerDidDismissPopover:(UIPopoverController *)popoverController {
    self.listSelector = nil;
}

@end
