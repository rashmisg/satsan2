//
//  AppDelegate.m
//  SCExecutive
//
//  Created by MobileTools on 4/29/14.
//  Copyright (c) 2014 JDA Software, Inc. All rights reserved.
//

#import "AppDelegate.h"
#import "JMMobileToolsApplication.h"
#import "JMNavigationBarComponentManager.h"
#import "JMRouter.h"
#import "SCExecutiveSettingsController.h"
#import "JMPageContextManager.h"

@implementation AppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    [JMMobileToolsApplication launchWithAppDelegate:self appTitle:@"SC Executive"];
    [JMMobileToolsApplication setUseLocalTabsJson:YES];
    [JMMobileToolsApplication setUseEmbeddedAppCode:YES];
    [JMMobileToolsApplication setViewDeviceLogEnabled:YES];
    
    [[JMRouter sharedInstance] registerRouteWithClass:[SCExecutiveSettingsController class] regexPattern:@"://settings"];
    
    NSString *currencySymbol = [SCExecutiveSettingsController getCurrentCountrySymbol];
    [JMPageContextManager setContextItem:currencySymbol forKey:CORPORATE_CURRENCY_REGION_SYMBOL];
    
    return YES;
}

@end
