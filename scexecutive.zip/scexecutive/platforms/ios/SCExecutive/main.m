//
//  main.m
//  SCExecutive
//
//  Created by MobileTools on 4/29/14.
//  Copyright (c) 2014 JDA Software, Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
