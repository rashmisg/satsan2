//
//  AppDelegate.h
//  SCExecutive
//
//  Created by MobileTools on 4/29/14.
//  Copyright (c) 2014 JDA Software, Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
