Ext.define('Jda.SCExecutive.plugin.Maximize', {
    extend: 'Ext.Component',
    alias: 'plugin.maximize',

    config: {
        hostView: null,
        modalContainer: null
    },

    init: function(hostView) {
        this.setHostView(hostView);

        hostView.addCls('maximize-button-container');

        var maximizeIndicator = this._createCornerIndicatorView();
        maximizeIndicator.element.on('tap', this._maximize, this);

        hostView.add(maximizeIndicator);
    },

    _createCornerIndicatorView: function() {
        return Ext.create('Ext.Component', {
            cls: 'maximize-button'
        });
    },

    _maximize: function() {
        var hostView = this.getHostView();

        if (!Ext.isFunction(hostView.getMaximizedView)) {
            console.warn(hostView.$className + ' does not implement getMaximizedView');
            return;
        }

        var hostViewCoordinates = hostView.element.getXY();
        var hostViewWidth = hostView.element.getWidth();
        var hostViewHeight = hostView.element.getHeight();
        var viewportWidth = Ext.Viewport.getWidth();
        var viewportHeight = Ext.Viewport.getHeight();
        var spaceBetweenWidgets = 10;
        var positionConfig = {};

        var shouldExpandTowardsTheRight = hostViewCoordinates[0] < viewportWidth / 2;
        if (shouldExpandTowardsTheRight) {
            positionConfig.left = hostViewCoordinates[0];
        }
        else {
            positionConfig.right = viewportWidth - (hostViewCoordinates[0] + hostViewWidth);
        }

        var shouldExpandTowardsTheBottom = hostViewCoordinates[1] < viewportHeight / 2;
        if (shouldExpandTowardsTheBottom) {
            positionConfig.top = hostViewCoordinates[1];
        }
        else {
            positionConfig.bottom = viewportHeight - (hostViewCoordinates[1] + hostViewHeight);
        }

        var isTallWidget = hostViewHeight > (viewportHeight / 2);
        var maximizedWidth = viewportWidth - (spaceBetweenWidgets * 2);
        var maximizedHeight = isTallWidget ? hostViewHeight : (hostViewHeight * 2) + spaceBetweenWidgets;

        var modalContainerConfig = {
            modal: true,
            width: hostViewWidth,
            height: hostViewHeight,
            layout: 'fit'
        };

        Ext.apply(modalContainerConfig, positionConfig);

        var modalContainer = Ext.create('Ext.Container', modalContainerConfig);
        var minimizeIndicator = this._createCornerIndicatorView();
        var maximizedView = hostView.getMaximizedView();

        this.setModalContainer(modalContainer);
        maximizedView.add(minimizeIndicator);
        modalContainer.add(maximizedView);

        minimizeIndicator.element.on('tap', this._minimize, this);
        modalContainer.getModal().on('tap', this._minimize, this);

        Ext.Viewport.add(modalContainer);

        var anim = Ext.create(Ext.fx.animation.Abstract, {
            element: modalContainer.element,
            to: {
                width: maximizedWidth,
                height: maximizedHeight
            },
            preserveEndState: true
        });

        Ext.Animator.run(anim);

        this._addAppLevelListenersToImmediatelyMinimize();
    },

    _minimize: function() {
        var hostViewElement = this.getHostView().element;
        var modalContainer = this.getModalContainer();
        var mask = modalContainer.getModal();

        // Animate width and height back to original widget size. Note, we don't need to adjust top, left, bottom, or right
        // because our modal container is pinned to the original widget's location, and adjusting size is relative to those pins.
        var anim = Ext.create(Ext.fx.animation.Abstract, {
            element: modalContainer.element,
            to: {
                width: hostViewElement.getWidth(),
                height: hostViewElement.getHeight()
            }
        });

        mask.setHideAnimation('fadeOut');
        mask.hide();

        // After the animation ends, destroy the container
        anim.on('animationend', this._destroyModal, this, { single: true });

        Ext.Animator.run(anim);
    },

    _destroyModal: function() {
        this._removeAppLevelListenersToImmediatelyMinimize();

        this.getModalContainer().destroy();

        this.setModalContainer(null);
    },

    _addAppLevelListenersToImmediatelyMinimize: function() {
        Ext.Viewport.on('activeitemchange', this._destroyModal, this);
        Jda.SCExecutive.util.AppContext.on('contextchanged', this._destroyModal, this);
    },

    _removeAppLevelListenersToImmediatelyMinimize: function() {
        Ext.Viewport.un('activeitemchange', this._destroyModal, this);
        Jda.SCExecutive.util.AppContext.un('contextchanged', this._destroyModal, this);
    }
});
