Ext.define('Jda.SCExecutive.controller.Inventory', {
    extend: 'Jda.SCExecutive.controller.SCExecutiveController',

    config: {
        routes: {
            'Inventory': 'routeInventory'
        },
        refs: {
            inventoryValueView: 'inventoryinventoryvalueview',
            averageDaysOfSupplyView: 'inventoryaveragedaysofsupplyview',
            averageWarehouseUtilizationView: 'inventorywarehouseutilizationview',
            orderFillInboundView: '#orderFillInboundView',
            orderFillOutboundView: '#orderFillOutboundView'
        },
        navBarTitle: Jda.getMessage('jda.scexecutive.inventory.NavBarTitle'),
        view: {
            xtype: 'inventory'
        },

        inventoryValueModel: null,
        warehouseUtilizationModel: null,
        averageDaysOfSupplyModel: null,
        orderFillModel: null
    },

    init: function() {
        this.callParent();

        this.setWarehouseUtilizationModel(Ext.create('Jda.SCExecutive.model.WarehouseUtilization'));
        this.setOrderFillModel(Ext.create('Jda.SCExecutive.model.OrderFill'));

        this.bindViewToModel(this.getAverageWarehouseUtilizationView(), this.getWarehouseUtilizationModel());
        this.bindViewToModel(this.getOrderFillInboundView(), this.getOrderFillModel());
        this.bindViewToModel(this.getOrderFillOutboundView(), this.getOrderFillModel());
    },

    updateInventoryValueModel: function(model) {
        this.bindViewToModel(this.getInventoryValueView(), model);
    },

    updateAverageDaysOfSupplyModel: function(model) {
        this.bindViewToModel(this.getAverageDaysOfSupplyView(), model);
    },

    routeInventory: function() {
        this.setViewportActiveItem();
    },

    getReportDependencies: function() {
        return [
            this.getOrderFillModel(),
            this.getInventoryValueModel(),
            this.getAverageDaysOfSupplyModel(),
            this.getWarehouseUtilizationModel()
        ];
    },

    loadModels: function(config) {
        this._orderFillModel.load(config);
        this.getInventoryValueModel().load(config);
        this.getAverageDaysOfSupplyModel().load(config);
        this._warehouseUtilizationModel.load(config);
    }
});
