Ext.define('Jda.SCExecutive.controller.Labor', {
    extend: 'Jda.SCExecutive.controller.SCExecutiveController',

    config: {
        routes: {
            'Labor': 'routeLabor'
        },
        refs: {
            laborSpendView: 'laborspendview',
            laborHoursView: 'laborhoursview',
            laborPerformanceView: 'laborperformanceview'
        },
        navBarTitle: Jda.getMessage('jda.scexecutive.labor.NavBarTitle'),
        view: {
            xtype: 'labor'
        },

        laborSpendModel: null,
        laborHoursModel: null,
        laborPerformanceModel: null
    },

    init: function() {
        this.callParent();

        this.setLaborPerformanceModel(Ext.create('Jda.SCExecutive.model.LaborPerformance'));

        this.bindViewToModel(this.getLaborPerformanceView(), this.getLaborPerformanceModel());
    },

    updateLaborSpendModel: function(model) {
        this.bindViewToModel(this.getLaborSpendView(), model);
    },

    updateLaborHoursModel: function(model) {
        this.bindViewToModel(this.getLaborHoursView(), model);
    },

    routeLabor: function() {
        this.setViewportActiveItem();
    },

    getReportDependencies: function() {
        return [
            this.getLaborSpendModel(),
            this.getLaborPerformanceModel(),
            this.getLaborHoursModel()
        ];
    },

    loadModels: function(config) {
        this.getLaborSpendModel().load(config);
        this.getLaborPerformanceModel().load(config);
        this.getLaborHoursModel().load(config);
    }
});
