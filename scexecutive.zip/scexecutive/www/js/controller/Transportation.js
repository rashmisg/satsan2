Ext.define('Jda.SCExecutive.controller.Transportation', {
    extend: 'Jda.SCExecutive.controller.SCExecutiveController',

    config: {
        routes: {
            'Transportation': 'routeTransportation'
        },
        refs: {
            transportationSpendView: 'transportationspendpanel',
            onTimeDeliveryView: 'transontimedeliverypanel',
            partyLoadsView: 'partyloadspanel',
            transportationFilter: '#transportationfilter'
        },
        navBarTitle: Jda.getMessage('jda.scexecutive.transportation.NavBarTitle'),
        view: {
            xtype: 'transportation'
        },

        transportationSpendModel: null,
        onTimeDeliveryModel: null,
        partyLoadsModel: null
    },

    init: function() {
        this.callParent();

        var transportationFilter = this.getTransportationFilter();
        transportationFilter.on('selectionChanged', this._onTransportationFilterSelectionChanged, this);

        this.setPartyLoadsModel(Ext.create('Jda.SCExecutive.model.PartyLoads'));
        
        this._bindViewToModel(this.getPartyLoadsView(), this.getPartyLoadsModel());
    },

    updateTransportationSpendModel: function(model) {
        this._bindViewToModel(this.getTransportationSpendView(), model);
    },

    updateOnTimeDeliveryModel: function(model) {
        this._bindViewToModel(this.getOnTimeDeliveryView(), model);
    },

    routeTransportation: function() {
        this.setViewportActiveItem();
    },

    getReportDependencies: function() {
        return [
            this.getTransportationSpendModel(),
            this.getOnTimeDeliveryModel(),
            this.getPartyLoadsModel()
        ];
    },

    loadModels: function(config) {
        this.getTransportationSpendModel().load(config);
        this.getOnTimeDeliveryModel().load(config);
        this._partyLoadsModel.load(config);
    },

    _onTransportationFilterSelectionChanged: function(text, index) {
        this.getTransportationSpendView().loadFromModel(this._transportationSpendModel, index);
        this.getOnTimeDeliveryView().loadFromModel(this._onTimeDeliveryModel, index);
        this.getPartyLoadsView().loadFromModel(this._partyLoadsModel, index);
    },

    _bindViewToModel: function(view, model) {
        model.on('load', function() {
            var selectedTabIndex = this.getTransportationFilter().getSelectedItem().index;

            view.loadFromModel(model, selectedTabIndex);
        }, this);
    }
});
