Ext.define('Jda.SCExecutive.controller.SCExecutiveController', {
    extend: 'Jda.mobility.controller.NavigationController',

    config: {
        lastLoadedPeriodHierarchy: null,
        lastLoadedLocationHierarchy: null
    },

    statics: {
        periodHierarchySelection: { group: 0, index: 0 },
        timePeriodSelectorOptions: [ ],

        initializeTimePeriodSelectorOptions: function(periodHierarchyReport) {
            var periodGroups = periodHierarchyReport.getPeriodGroups();
            var types = Jda.SCExecutive.model.PeriodHierarchy.typesList;
            var groups = [];
            Ext.each(types, function(type) {
                var group = {
                    title: Jda.getMessage('jda.scexecutive.periodhierarchy.' + type),
                    values: []
                };

                Ext.each(periodGroups[type], function(periodGroup) {
                    group.values.push(periodGroup.getDisplayString(true));
                });

                groups.push(group);
            });

            Jda.SCExecutive.controller.SCExecutiveController.timePeriodSelectorOptions = groups;
        }
    },

    init: function() {
        this.callParent();

        Jda.SCExecutive.util.AppContext.on('contextchanged', this._onAppContextChanged, this);
    },

    getReportDependencies: function() {
        throw new Error(this.$className + ' must implement getReportDependencies.');
    },

    loadModels: function(config) {
        throw new Error(this.$className + ' must implement loadModels.');
    },

    bindViewToModel: function(view, model) {
        model.on('load', function() {
            view.loadFromModel(model);
        });
    },

    setViewportActiveItem: function() {
        this.callParent(arguments);

        var currentLocationHierarchy = Jda.SCExecutive.util.AppContext.getCurrentLocationHierarchy();
        var currentPeriodHierarchy = Jda.SCExecutive.util.AppContext.getCurrentPeriodHierarchy();

        // Nothing to do if we haven't loaded the context yet.
        if (!currentLocationHierarchy || !currentPeriodHierarchy) {
            return;
        }

        // If there is a current context, and this controller hasn't yet loaded it, do so.
        var hasntLoadedCurrentLocationHierarchy = currentLocationHierarchy !== this.getLastLoadedLocationHierarchy();
        var hasntLoadedCurrentPeriodHierarchy = currentPeriodHierarchy !== this.getLastLoadedPeriodHierarchy();
        if (hasntLoadedCurrentLocationHierarchy || hasntLoadedCurrentPeriodHierarchy) {
            this._updateModelsWithCurrentContext({ locationHierarchy: currentLocationHierarchy, periodHierarchy: currentPeriodHierarchy });
        }
    },

    _createNavBarConfig: function() {
        this.setNavBarConfig({
            title: this.getNavBarTitle(),
            buttons: [{
                callback: this._onSharePressed,
                config: {
                    type: Jda.mobility.plugins.NavigationBarComponentManager.types.dropDown,
                    dropDownHeader: Jda.getMessage('jda.scexecutive.share.Title'),
                    dropDownStrings: [ Jda.getMessage('jda.scexecutive.share.Email'), Jda.getMessage('jda.scexecutive.share.Annotate') ],
                    iconPath: 'share.png',
                    location: Jda.mobility.plugins.NavigationBarComponentManager.locations.right
                }
            }, {
                callback: this._onGroupSelectorPressed,
                config: {
                    type: Jda.mobility.plugins.NavigationBarComponentManager.types.groupedPicker,
                    location: Jda.mobility.plugins.NavigationBarComponentManager.locations.right,
                    iconPath: 'calendar.png',
                    title: Jda.getMessage('jda.scexecutive.periodhierarchy.TimePeriod'),
                    selection: Jda.SCExecutive.controller.SCExecutiveController.periodHierarchySelection,
                    groups: Jda.SCExecutive.controller.SCExecutiveController.timePeriodSelectorOptions
                }
            }]
        });
    },

    _onAppContextChanged: function(config) {
        // If this tab is active, load its models
        var navView = this.getNavView();
        if (navView === Ext.Viewport.getActiveItem()) {
            this._updateModelsWithCurrentContext(config);
        }

        this._updateNavBar();
    },

    _updateModelsWithCurrentContext: function(config) {
        this.getApplication().showLoadingMaskIfNecessary();

        var reports = this.getReportDependencies();
        var counter = reports.length;

        var countDown = function() {
            if (--counter === 0) {
                this.getApplication().hideLoadingMaskIfNecessary();

                // need to clean up all the old listeners now that all reports have finished loading, so
                // that they don't continue to fire for shared models when navigating on other tabs
                Ext.each(reports, function(report) {
                    report.un('load', countDown, this);
                    report.un('error', countDown, this);
                    report.un('shortcircuit', countDown, this);
                }, this);
            }
        };

        // attach listeners for each report to keep track them while loading
        Ext.each(reports, function(report) {
            report.on('load', countDown, this);
            report.on('error', countDown, this);
            report.on('shortcircuit', countDown, this);
        }, this);

        this.loadModels(config);

        this.setLastLoadedLocationHierarchy(config.locationHierarchy);
        this.setLastLoadedPeriodHierarchy(config.periodHierarchy);
    },

    _updateNavBar: function() {
        // Need a better way to get route, aside from using CMT internals
        var route = this.getDefaultRoute() || this. _getFirstRouteName();

        // Remove current nav bar items. It would be nice if we could avoid this and just update existing.
        Jda.mobility.plugins.NavigationBarComponentManager.removeAllButtons(route);

        // Recreate the config, updating the period index
        this._createNavBarConfig();

        // Reload the nav bar items
        this.configureNavBar();
    },

    _onSharePressed: function(method) {
        var failure = function(err) {
            Jda.mobility.plugins.DialogManager.alert({ message: err });
        };

        var mailConfig = {
            subject: this.getNavBarTitle()
        };

        if (method.value === Jda.getMessage('jda.scexecutive.share.Annotate')) {
            Jda.mobility.plugins.ScreenSharer.screenshotAnnotateAndSend(undefined, failure, mailConfig);
        }
        else {
            Jda.mobility.plugins.ScreenSharer.screenshotAndSend(undefined, failure, mailConfig);
        }
    },

    _onGroupSelectorPressed: function(selection) {
        Jda.SCExecutive.controller.SCExecutiveController.periodHierarchySelection = selection;

        this.getApplication().applyTimePeriodFilter(selection.group, selection.index);
    }
});
