Ext.define('Jda.SCExecutive.controller.Overview', {
    extend: 'Jda.SCExecutive.controller.SCExecutiveController',

    config: {
        defaultRoute: 'Overview',
        routes: {
            'Overview': 'routeOverview'
        },
        refs: {
            customerServicePerformanceView: 'overviewcustomerserviceperformanceview',
            customerServiceTitleLabel: '#overviewcustomerservicetitlelabel',
            transportationSpendView: 'overviewtransportationspendview',
            transportationSpendTitleLabel: '#overviewtransspendtitlelabel',
            forecastAccuracyView: 'overviewforecastaccuracyview',
            inventoryValueView: 'overviewinventoryvalueview',
            inventoryValueTitleLabel: '#overviewinventoryvaluetitlelabel',
            averageDaysOfSupplyView: 'overviewaveragedaysofsupplyview',
            averageDaysOfSupplyTitleLabel: '#overviewavgdaysofsupplytitlelabel',
            laborSpendView: 'overviewlaborspendview',
            laborHoursView: 'overviewlaborhoursview',
            laborSpendTitleLabel: '#overviewlaborspendtitlelabel'
        },
        navBarTitle: Jda.getMessage('jda.scexecutive.overview.NavBarTitle'),
        view: {
            xtype: 'overview'
        },

        customerServicePerformanceModel: null,
        forecastAccuracyModel: null,
        transportationSpendModel: null,
        inventoryValueModel: null,
        averageDaysOfSupplyModel: null,
        laborSpendModel: null,
        laborHoursModel: null
    },

    init: function() {
        this.callParent();

        this.setForecastAccuracyModel(Ext.create('Jda.SCExecutive.model.ForecastAccuracy'));

        this.bindViewToModel(this.getForecastAccuracyView(), this.getForecastAccuracyModel());

        this._addPanelTapListeners();
    },

    updateCustomerServicePerformanceModel: function(model) {
        this.bindViewToModel(this.getCustomerServicePerformanceView(), model);
    },

    updateTransportationSpendModel: function(model) {
        this.bindViewToModel(this.getTransportationSpendView(), model);
    },

    updateInventoryValueModel: function(model) {
        this.bindViewToModel(this.getInventoryValueView(), model);
    },

    updateAverageDaysOfSupplyModel: function(model) {
        this.bindViewToModel(this.getAverageDaysOfSupplyView(), model);
    },

    updateLaborSpendModel: function(model) {
        this.bindViewToModel(this.getLaborSpendView(), model);
    },

    updateLaborHoursModel: function(model) {
        this.bindViewToModel(this.getLaborHoursView(), model);
    },

    getReportDependencies: function() {
        return [
            this.getCustomerServicePerformanceModel(),
            this.getForecastAccuracyModel(),
            this.getLaborSpendModel(),
            this.getLaborHoursModel(),
            this.getTransportationSpendModel(),
            this.getInventoryValueModel(),
            this.getAverageDaysOfSupplyModel()
        ];
    },

    loadModels: function(config) {
        this.getCustomerServicePerformanceModel().load(config);
        this.getForecastAccuracyModel().load(config);
        this.getLaborSpendModel().load(config);
        this.getLaborHoursModel().load(config);
        this.getTransportationSpendModel().load(config);
        this.getInventoryValueModel().load(config);
        this.getAverageDaysOfSupplyModel().load(config);
    },

    routeOverview: function() {
        this.setViewportActiveItem();
    },

    _addPanelTapListeners: function() {
        // Add listeners to items that aren't controls, and can't be targeted by the control block.
        this._addTabChangeOnTapListener(this.getCustomerServiceTitleLabel(), 'CustomerService');

        this._addTabChangeOnTapListener(this.getTransportationSpendTitleLabel(), 'Transportation');

        this._addTabChangeOnTapListener(this.getLaborSpendTitleLabel(), 'Labor');

        this._addTabChangeOnTapListener(this.getAverageDaysOfSupplyTitleLabel(), 'Inventory');

        this._addTabChangeOnTapListener(this.getInventoryValueTitleLabel(), 'Inventory');
    },

    _addTabChangeOnTapListener: function(view, destinationRoute) {
        var onTapCallback = function() {
            Jda.mobility.plugins.PageContextManager.setActiveTab(destinationRoute);
        };

        view.addListener('tap', onTapCallback, this, { element: 'element', event: 'tap' });
    }
});
