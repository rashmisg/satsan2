Ext.define('Jda.SCExecutive.controller.CustomerService', {
    extend: 'Jda.SCExecutive.controller.SCExecutiveController',

    config: {
        routes: {
            'CustomerService': 'routeCustomerService'
        },
        refs: {
            customerServicePerformanceView: 'customerserviceperformanceview',
            orderFillRateView: 'customerserviceorderfillrateview',
            topTenCustomersView: 'customerservicetoptencustomersview',
            unshippedOrdersView: 'customerserviceunshippedordersview',
            onTimeDeliveryView: 'customerserviceontimedeliveryview'
        },
        navBarTitle: Jda.getMessage('jda.scexecutive.customerservice.NavBarTitle'),
        view: {
            xtype: 'customerserviceview'
        },

        customerServicePerformanceModel: null,
        orderFillRateModel: null,
        topTenCustomersModel: null,
        unshippedOrdersModel: null,
        onTimeDeliveryModel: null
    },

    init: function() {
        this.callParent();

        this.setOrderFillRateModel(Ext.create('Jda.SCExecutive.model.OrderFillRate'));
        this.setTopTenCustomersModel(Ext.create('Jda.SCExecutive.model.TopTenCustomers'));
        this.setUnshippedOrdersModel(Ext.create('Jda.SCExecutive.model.UnshippedOrders'));

        this.bindViewToModel(this.getOrderFillRateView(), this.getOrderFillRateModel());
        this.bindViewToModel(this.getTopTenCustomersView(), this.getTopTenCustomersModel());
        this.bindViewToModel(this.getUnshippedOrdersView(), this.getUnshippedOrdersModel());
    },

    routeCustomerService: function() {
        this.setViewportActiveItem();
    },

    updateCustomerServicePerformanceModel: function(model) {
        this.bindViewToModel(this.getCustomerServicePerformanceView(), model);
    },

    updateOnTimeDeliveryModel: function(model) {
        this.bindViewToModel(this.getOnTimeDeliveryView(), model);
    },

    getReportDependencies: function() {
        return [
            this.getCustomerServicePerformanceModel(),
            this.getTopTenCustomersModel(),
            this.getOrderFillRateModel(),
            this.getUnshippedOrdersModel(),
            this.getOnTimeDeliveryModel()
        ];
    },

    loadModels: function(config) {
        // Temporary hack until Cognos doesn't need param for root request
        var unshippedConfig = { locationHierarchy: config.locationHierarchy, forceLoad: config.forceLoad };
        if (config.locationHierarchy.get('isRoot')) {
            unshippedConfig.params = { p_Country: 'All' };
        }

        this.getCustomerServicePerformanceModel().load(config);
        this._topTenCustomersModel.load(config);
        this._orderFillRateModel.load(config);
        this._unshippedOrdersModel.load(unshippedConfig);
        this.getOnTimeDeliveryModel().load(config);
    }
});
