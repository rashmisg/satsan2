Ext.define('Jda.SCExecutive.constant.TimePeriods', {
    singleton: true,

    WEEK: 'WEEK',
    MONTH: 'MONTH',
    QUARTER: 'QUARTER',
    YEAR: 'YEAR'
});
