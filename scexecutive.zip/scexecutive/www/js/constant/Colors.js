Ext.define('Jda.SCExecutive.constant.Colors', {
    singleton: true,

    map: {},

    colorPalete: [
        '#ff9e36', // orange
        '#249f33', // green
        '#6f51a1', // violet
        '#42b9ff', // light blue
        '#ffeb4b', // yellow
        '#6ce07a', // light green
        '#9c27b0', // purple
        '#ff6536', // outrageous orange
        '#5677fc', // cornflower blue
        '#e91e63', // amaranth
        '#cddc39', // pear
        '#95a5ff' // melrose
    ],

    // mirrored colors from css since the styles cannot be reused for canvas charting
    blue: '#2073bc',
    red: '#bc0a0a',

    chartAxis: '#838383',
    chartAxisLabel: '#838383',
    chartAxisGridStroke: '#e9e9e9',
    chartAxisBoundaryLine: '#d0d0d0',
    chartThresholdSeriesStroke: '#e9e9e9',
    chartSeriesMarkerStroke: '#ffffff',
    chartSeriesPrimaryColor: '#2073bc',
    chartSeriesSecondaryColor: '#d0d0d0',

    chartSeriesDefaultOpacity: 0.85,

    colorForLocationHierarchyAtIndex: function(index) {
        var adjustedIndex = index % this.colorPalete.length;
        if (index < 0) {
            adjustedIndex += this.colorPalete.length;
        }

        return this.colorPalete[adjustedIndex];
    }
});
