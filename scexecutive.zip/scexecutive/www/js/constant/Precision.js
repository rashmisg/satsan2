Ext.define('Jda.SCExecutive.constant.Precision', {
    singleton: true,

    Low: 0,
    Medium: 2,
    High: 4
});
