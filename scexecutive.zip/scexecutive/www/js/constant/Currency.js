Ext.define('Jda.SCExecutive.constant.Currency', {
    statics: {
        CORPORATE_CURRENCY_REGION_SYMBOL: 'CORPORATE_CURRENCY_REGION_SYMBOL'
    }
});