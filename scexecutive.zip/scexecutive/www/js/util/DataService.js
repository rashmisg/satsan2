Ext.define('Jda.SCExecutive.util.DataService', {
    singleton: true,

    isDemoMode: false,

    DEMO_BASE_URL: './resources/data',

    buildCognosUrl: function(report, config) {
        var dataServiceConfig = config || {};
        
        // In demo mode, we build a url to point at the filesystem
        if (this.isDemoMode) {
            return this.buildDemoCognosUrl(report, dataServiceConfig);
        }

        return this._buildProductionCognosUrl(report, dataServiceConfig);
    },

    _buildProductionCognosUrl: function(report, config) {
        var params = Ext.apply({}, config.params, report.getBaseParams());

        // Add params for location hierarchy, if present
        if (config.locationHierarchy) {
            Ext.apply(params, this._buildLocationHierarchyParams(config.locationHierarchy));
        }

        // Add params for period hierarchy, if presnt
        if (config.periodHierarchy) {
            Ext.apply(params, this._buildPeriodHierarchyParams(config.periodHierarchy));
        }

        return Jda.buildDataServiceUrl('cognos', report.getBeanPath(), params);
    },

    _buildLocationHierarchyParams: function(locationHierarchy) {
        var params = { };

        if (!locationHierarchy.get('isRoot')) {
            var parentParams = this._buildLocationHierarchyParams(locationHierarchy.get('parent'));
            params = Ext.apply(params, parentParams);

            params['p_' + locationHierarchy.get('level')] = locationHierarchy.get('code');
        }

        return params;
    },

    _buildPeriodHierarchyParams: function(periodHierarchy) {
        var params = { };

        if (!periodHierarchy.get('isRoot')) {
            var parentParams = this._buildPeriodHierarchyParams(periodHierarchy.get('parent'));
            params = Ext.apply(params, parentParams);

            params['p_' + periodHierarchy.get('type')] = periodHierarchy.get('value');
        }

        return params;
    },

    buildDemoCognosUrl: function(report, config) {
        var requestUrl = this.DEMO_BASE_URL;
        var reportName = report.getReportName();

        // First, we append the folder name (report name) and the base name of that report (report name)
        // This should look like /data/resources/Location_hierarchy/Location_hierarchy
        requestUrl += '/' + reportName + '/' + reportName;

        // Add ad-hoc params (mostly just to support UnshippedOrders)
        if (config.params) {
            Ext.Object.each(config.params, function(key, value) {
                // Need to actually remove the 'p_' here
                requestUrl += '-' + key.substr(2) + '-' + value;
            });
        }

        // Append hierarchy params
        if (config.locationHierarchy) {
            requestUrl += this.buildLocationHierarchyDemoPathString(config.locationHierarchy);
        }

        if (config.periodHierarchy) {
            requestUrl += this.buildPeriodHierarchyDemoPathString(config.periodHierarchy);
        }

        // Finally tack on the file extension
        requestUrl += '.json';

        return requestUrl;
    },

    buildLocationHierarchyDemoPathString: function(locationHierarchy) {
        var params = '';

        if (!locationHierarchy.get('isRoot')) {
            params += this.buildLocationHierarchyDemoPathString(locationHierarchy.get('parent'));

            params += '-' + locationHierarchy.get('level') + '-' + locationHierarchy.get('code');
        }

        return params;
    },

    buildPeriodHierarchyDemoPathString: function(periodHierarchy) {
        var params = '';

        if (!periodHierarchy.get('isRoot')) {
            params += this.buildPeriodHierarchyDemoPathString(periodHierarchy.get('parent'));

            params += '-' + periodHierarchy.get('type') + '-' + periodHierarchy.get('value');
        }

        return params;
    },

    // for reuse purposes until we have more direction around how errors should be handled in the app
    handleRequestError: function(url, response) {
        console.error('Error requesting URL: ' + url);

        if (response) {
            console.error(Ext.String.format('\tstatus: {0}, responseText: {1}', response.status, response.responseText));
        }
    }
});
