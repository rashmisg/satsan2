Ext.define('Jda.SCExecutive.util.Formatters.MetricFormatter', {
    singleton: true,

    _numbers: [{
        letter: 'T',
        divisor: 1000000000000,
        threshold: 1000000000000
    }, {
        letter: 'B',
        divisor: 1000000000,
        threshold: 1000000000
    }, {
        letter: 'M',
        divisor: 1000000,
        threshold: 1000000
    }, {
        letter: 'K',
        divisor: 1000,
        threshold: 1000
    }],

    _corporateCurrencyRegionSymbol: '$',

    setCorporateCurrencyRegionSymbol: function(symbol) {
        this._corporateCurrencyRegionSymbol = symbol;
    },

    getCorporateCurrencyRegionSymbol: function() {
        return this._corporateCurrencyRegionSymbol;
    },

    /**
     *  formatNumber handles converting numbers to the metric style number format with a
     *  K (kilo, thousands), M (mega, millions), B (giga, billions), T (tera, trillions).
     *  In the metrics system B should be G but I talked this over with the BA who thought
     *  B made more sense. The precision value is applied to the numbers formatted not
     *  anything less than 1000 because wanting to show a precision of 2 for 4.53K and 140.33
     *  are very different cases.
     */
    formatNumber: function(number, precision, padZeroes) {
        var formattedNumber = null,
            normalizedPrecision = Ext.isDefined(precision) ? precision : Jda.SCExecutive.constant.Precision.Medium;

        // Find the correct bucket for the number (e.g. between 1000 and 999999), then truncate (1-999.99).
        // Pad Zeroes if desired, and append the appropriate letter (K), to get 999.99K
        Ext.Array.each(this._numbers, function(format) {
            if (number >= format.threshold) {
                formattedNumber = this._truncateToPrecision(number / format.divisor, normalizedPrecision);

                if (padZeroes) {
                    formattedNumber = this._padZeroes(formattedNumber, normalizedPrecision);
                }

                formattedNumber += format.letter;

                return false;
            }
        }, this);

        // If this number was not inside of one of our buckets, that means it's less than 1000.
        // In that case, just truncate to precision and pad zeroes if desired
        if (formattedNumber === null) {
            formattedNumber = this._truncateToPrecision(number, normalizedPrecision);

            if (padZeroes) {
                formattedNumber = this._padZeroes(formattedNumber, normalizedPrecision);
            }
        }

        // Use the correct decimal separator. Note, we don't need to worry about
        // commas because they won't be present (1-999, 1k-999k, 1m-999m, etc).
        formattedNumber = formattedNumber.replace('.', Globalize.culture().numberFormat['.']);

        return formattedNumber;
    },

    /**
     *  formatCurrency handles converting numbers to currency, in the same style as formatNumber.
     *  Note that this is not currently localized, and will always just return the number prefixed
     *  with a dollar symbol. The actually localized work will be done at a later date, once we've
     *  started localizing the application, but it will use much of the same logic already present
     *  in this class. To avoid having to either duplicate this logic to a separate class, or having
     *  a breaking change to move currency into this class later, we're moving it now.
     */
    formatCurrency: function(number, precision, padZeroes) {
        var formattedNumber = this.formatNumber(number, precision, padZeroes);

        var isNegative = /-/.test(formattedNumber);
        if (isNegative) {
            // Drop the sign for now.
            formattedNumber = formattedNumber.substring(1);
        }

        var corporateCurrencySymbol = this.getCorporateCurrencyRegionSymbol();

        // Build the number
        var formattedNumberWithCurrencySymbol = '';

        // Start with the sign
        if (isNegative) {
            formattedNumberWithCurrencySymbol += '-';
        }

        // Then add the currency symbol
        formattedNumberWithCurrencySymbol += corporateCurrencySymbol;

        // Finally the formatted number
        formattedNumberWithCurrencySymbol += formattedNumber;

        return formattedNumberWithCurrencySymbol;
    },

    /**
     *  formatPercent handles converting 0-100 numbers (not 0-1) to percents. Currently, this
     *  is just a wrapper around the RP formatting method make it meet the format we desire.
     */
    formatPercent: function(number, precision) {
        var formattedNumber = this._truncateToPrecision(number, precision);

        formattedNumber = this._passPercentThroughToGlobalize(formattedNumber, precision);

        return formattedNumber.replace(' ', '');
    },

    _passPercentThroughToGlobalize: function(value, precision) {
        var number = parseFloat(value);
        return Jda.mobility.i18n.Percent.format(number, Jda.mobility.i18n.Percent.CUSTOM_PRECISION, precision);
    },

    /** 
     *  Truncates a number to the specified precision
     */
    _truncateToPrecision: function(value, precision) {
        var stringifiedValue = value + '',
            pieces = stringifiedValue.split('.'),
            wholePiece = pieces[0],
            decimalPiece = pieces[1];

        if (decimalPiece && precision > Jda.SCExecutive.constant.Precision.Low) {
            wholePiece += '.' + decimalPiece.substring(0, precision);
        }

        // Convert to a number to drop trailing zeroes, then back to a string for desired output format
        return +wholePiece + '';
    },

    /** 
     *  Pads a string representation of a number to guarantee a period and a certain number of decimal places.
     *  Calculates the required length of the string as the location of the period + the specified precision. Appends 0
     *  until the length is correct.
     */
    _padZeroes: function(value, precision) {
        var lengthUpToPeriod = value.indexOf('.') + 1,
            requiredLength = lengthUpToPeriod + precision;

        if (lengthUpToPeriod <= 0 && precision > Jda.SCExecutive.constant.Precision.Low) {
            value += '.';
            requiredLength = value.length + precision;
        }

        while (value.length < requiredLength) {
            value += '0';
        }

        return value;
    }
});
