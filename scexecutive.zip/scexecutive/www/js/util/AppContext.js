Ext.define('Jda.SCExecutive.util.AppContext', {
    mixins: [ 'Ext.mixin.Observable' ],

    singleton: true,

    config: {
        rootLocationHierarchy: null,
        currentLocationHierarchy: null,
        currentPeriodHierarchy: null,

        // The goal here is to temporarily prevent caching between logout/login (/page load)
        pageUuid: new Ext.data.identifier.Uuid().generate()
    },

    constructor: function(config) {
        this.initConfig(config);
    },

    refresh: function() {
        this.fireEvent('contextchanged', { locationHierarchy: this._currentLocationHierarchy, periodHierarchy: this._currentPeriodHierarchy, forceLoad: true });
    },

    setAppContext: function(currentLocationHierarchy, currentPeriodHierarchy) {
        this._currentLocationHierarchy = currentLocationHierarchy;
        this._currentPeriodHierarchy = currentPeriodHierarchy;

        this.fireEvent('contextchanged', { locationHierarchy: this._currentLocationHierarchy, periodHierarchy: this._currentPeriodHierarchy });
    },

    updateCurrentLocationHierarchy: function(currentLocationHierarchy) {
        this.fireEvent('contextchanged', { locationHierarchy: currentLocationHierarchy, periodHierarchy: this.getCurrentPeriodHierarchy() });
    },

    updateCurrentPeriodHierarchy: function(currentPeriodHierarchy) {
        this.fireEvent('contextchanged', { locationHierarchy: this.getCurrentLocationHierarchy(), periodHierarchy: currentPeriodHierarchy });
    }
});
