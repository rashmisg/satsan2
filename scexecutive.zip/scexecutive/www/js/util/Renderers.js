Ext.define('Jda.SCExecutive.util.Renderers', {
    singleton: true,

    getBarChartXAxisRenderer: function(showAllTicks) {
        return function(periodHierarchy, attr) {
            var formattedDate = '';
            var start;
            var end;
            var parentPeriodHierarchy = periodHierarchy.get('parent');

            switch (parentPeriodHierarchy.get('type')) {
                case Jda.SCExecutive.model.PeriodHierarchy.types.WEEK:
                    var recordIndex = Ext.Array.indexOf(attr.data, periodHierarchy);
                    var isEvenRecord = recordIndex % 2 === 0;
                    if (showAllTicks || isEvenRecord) {
                        formattedDate = Jda.mobility.i18n.Date.format(periodHierarchy.get('start'), Jda.mobility.i18n.Date.SHORT_WEEKDAY);
                    }
                    break;
                case Jda.SCExecutive.model.PeriodHierarchy.types.MONTH:
                    formattedDate = Jda.mobility.i18n.Date.format(periodHierarchy.get('end'), Jda.mobility.i18n.Date.MONTH_DATE);
                    break;
                case Jda.SCExecutive.model.PeriodHierarchy.types.QUARTER:
                    start = Jda.mobility.i18n.Date.format(periodHierarchy.get('start'), Jda.mobility.i18n.Date.MONTH_DATE);
                    end = Jda.mobility.i18n.Date.format(periodHierarchy.get('end'), Jda.mobility.i18n.Date.MONTH_DATE);
                    formattedDate = Ext.String.format(Jda.getMessage('jda.scexecutive.periodhierarchy.MonthToMonthDisplayStringFormat'), start, end);
                    break;
                case Jda.SCExecutive.model.PeriodHierarchy.types.YEAR:
                    var value = periodHierarchy.get('value');
                    var number = value.substr(value.length - 1);
                    formattedDate = Ext.String.format(Jda.getMessage('jda.scexecutive.periodhierarchy.QuarterDisplayStringFormat'), number);
                    break;
            }

            return formattedDate;
        };
    },

    getLineChartXAxisRenderer: function(showAllTicks) {
        return function(periodHierarchy, attr) {
            var store = this.getAxis().getChart().getStore();
            var recordIndex = Ext.Array.indexOf(attr.data, periodHierarchy);
            var isEvenRecord = recordIndex % 2 === 0;
            var record = store.getAt(recordIndex);
            var contextPeriodHierarchy = record.get('contextPeriodHierarchy');
            var contextPeriodHierarchyType = contextPeriodHierarchy.get('type');
            var formattedDate = '';

            if (contextPeriodHierarchyType == Jda.SCExecutive.model.PeriodHierarchy.types.WEEK) {
                if (showAllTicks || isEvenRecord) {
                    formattedDate = Jda.mobility.i18n.Date.format(periodHierarchy.get('start'), Jda.mobility.i18n.Date.SHORT_WEEKDAY);
                }
            }
            else if (contextPeriodHierarchyType === Jda.SCExecutive.model.PeriodHierarchy.types.MONTH) {
                formattedDate = Jda.mobility.i18n.Date.format(periodHierarchy.get('end'), Jda.mobility.i18n.Date.MONTH_DATE);
            }
            else if (contextPeriodHierarchyType === Jda.SCExecutive.model.PeriodHierarchy.types.QUARTER) {
                if (showAllTicks || isEvenRecord) {
                    // The way the value is obtained here is kinda just a temporary hack until we start showing spans
                    formattedDate = periodHierarchy.get('value').split('-')[1];
                }
            }
            else if (contextPeriodHierarchyType === Jda.SCExecutive.model.PeriodHierarchy.types.YEAR) {
                if (showAllTicks || isEvenRecord) {
                    formattedDate = Jda.mobility.i18n.Date.format(periodHierarchy.get('start'), Jda.mobility.i18n.Date.MONTH);
                }
            }

            return formattedDate;
        };
    },

    getAdjustedLineChartYAxisConfig: function(config) {
        var percentPaddingTop = Ext.isDefined(config.percentPaddingTop) ? config.percentPaddingTop : 0.05; //5%, padding added to the top, based on a percent of the max
        var percentPaddingBottom = Ext.isDefined(config.percentPaddingBottom) ? config.percentPaddingBottom : 0.10; //10%, padding added to the bottom, based on a percent of the max
        var minRangePercentage = Ext.isDefined(config.minRange) ? config.minRange : 0.15; //15%, the minimum amount between the min and max, based on a percent of the max
        var maxMajorTickSteps = config.maxMajorTickSteps || 5; //The maximum tick steps on the axis

        //set the defaults for undefined values
        var minimumCap = config.minimumCap || 0; //almost every chart starts at zero
        var lowestValue = config.lowestValue || 0; //assumes 0 units or 0%
        var highestValue = Ext.isDefined(config.highestValue) ? config.highestValue : 100; //assumes 100%
        var maximumCap = Ext.isDefined(config.maximumCap) ? config.maximumCap : Number.MAX_VALUE;
        var hasDoubleTicks = config.hasDoubleTicks;

        //calc max
        var max = highestValue + highestValue * percentPaddingTop;
        max = Math.ceil(Math.min(max, maximumCap));

        var minRange = max * minRangePercentage;

        //calc min
        var min = lowestValue - highestValue * percentPaddingBottom;
        if (max - min < minRange) { //prevent min and max being too close to each other
            min = max - minRange;
        }

        min = Math.floor(Math.max(min, minimumCap));

        //This doubles the number of available ticks that the axis might require. It does not outright
        //double the number of ticks because this might lead to an uneven tickStepSize.
        if (hasDoubleTicks) {
            maxMajorTickSteps *= 2;
        }

        var range = Math.floor(max - min);
        var majorTickStepSizes = [ 1, 2, 5, 10, 20, 50 ];
        var digits = range.toString().length;

        for (var i = 0; i < majorTickStepSizes.length; i++) {
            var majorTickStepSize = majorTickStepSizes[i] * Math.pow(10, digits - 2);
            var potentialMajorTickStepSolution = range / majorTickStepSize;

            if (potentialMajorTickStepSolution <= maxMajorTickSteps) { // this is our max number of majorTickSteps
                var graphMinimum = Math.floor(min / majorTickStepSize) * majorTickStepSize;
                var graphMaximum = Math.ceil(max / majorTickStepSize) * majorTickStepSize;
                var majorTickSteps = Math.ceil((graphMaximum - graphMinimum) / majorTickStepSize);

                //This final check prevents the rare cases where correcting the graph max/min can
                //cause the majorTickSteps to be larger than the max.
                if (majorTickSteps <= maxMajorTickSteps) {
                    return {
                        minimum: graphMinimum,
                        maximum: graphMaximum,
                        majorTickSteps: majorTickSteps
                    };
                }
            }
        }

        throw new Error('Failed to Determine Y Axis Config');
    }
});
