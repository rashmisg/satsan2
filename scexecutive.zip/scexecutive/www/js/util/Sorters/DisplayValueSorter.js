// As part of CAGE-3192, we are hoping to make a sort of UX tweak to sorting
// such that lists are not sorted by raw value, but instead by their display
// value. For example, observe the following values sorted by value:
//
// US: 80.9
// CAN: 80.1
// MX: 79.7
//
// In a view where these are rendered as just whole numbers, you end up with
//
// US: 80
// CAN: 80
// MX: 79
//
// This is non ideal; CAN appears to be the value that should be on top, since US
// appears to be of equal value, but lower value in terms of Alphabetical sorting.
// This class will handle this by running values through their formatter and
// sorting them based on the output of the formatter.
//
// Config for the createSorter function is as follows:
// {
//    field: required, name of field on required
//    precision: optional, number of decimal places of precision
//    direction: optional, direction of sort (defaults to ASC)
// }
//
Ext.define('Jda.SCExecutive.util.Sorters.DisplayValueSorter', {
    statics: {
        createSorter: function(sorterConfig) {
            var field = sorterConfig.field;
            var precision = Ext.isDefined(sorterConfig.precision) ? sorterConfig.precision : 2;

            return {
                sorterFn: function(record1, record2) {
                    var rawValue1 = record1.get(field);
                    var dispValue1 = Jda.SCExecutive.util.Formatters.MetricFormatter.formatNumber(rawValue1, precision);
                    var roundedValue1 = parseFloat(dispValue1);

                    var rawValue2 = record2.get(field);
                    var dispValue2 = Jda.SCExecutive.util.Formatters.MetricFormatter.formatNumber(rawValue2, precision);
                    var roundedValue2 = parseFloat(dispValue2);

                    if (roundedValue1 > roundedValue2) {
                        return 1;
                    }
                    else if (roundedValue1 === roundedValue2) {
                        return 0;
                    }

                    return -1;
                },
                direction: sorterConfig.direction || 'ASC'
            };
        }
    }
});
