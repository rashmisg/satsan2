Ext.define('Jda.SCExecutive.grid.Grid', {
    extend: 'Ext.Container',
    xtype: 'scexecutivegrid',

    config: {
        store: undefined,
        columns: undefined,

        layout: {
            type: 'vbox',
            align: 'stretch'
        }
    },

    initialize: function() {
        this.callParent(arguments);

        this.gridHeader = Ext.create('Ext.Component');
        this.gridBody = Ext.create('Ext.Container', { flex: 1 });

        this.add(this.gridHeader);
        this.add(this.gridBody);

        this._setupHackToEnableScrolling();

        // NOTE: this currently assumes every column has a width specified

        this.gridHeaderTpl = new Ext.XTemplate(
            '<table class="cage-grid">',
                '<thead>',
                    '<tr class="cage-grid-header-row">',
                        '<tpl for="columns">',
                            '<th style="width: {width};">{text}</th>',
                        '</tpl>',
                    '</tr>',
                '</thead>',
            '</table>'
        );

        this.gridBodyTpl = new Ext.XTemplate(
            '<table class="cage-grid">',
                '<tbody>',
                    '<tpl for="data">',
                        '<tr class="cage-grid-row">',
                            '<tpl for="parent.columns">',
                                '<td style="width: {width};">{[ this.renderDataValue(parent.get(values.dataIndex), parent, values) ]}</td>', // parent is the record, values is the column
                            '</tpl>',
                        '</tr>',
                        '<tr class="cage-grid-row-separator">',
                            '<td colspan="5"><div></td>', //this is done because tr cannot have margin
                        '</tr>',
                    '</tpl>',
                '</tbody>',
            '</table>',
            {
                renderDataValue: function(value, record, columnConfig) {
                    if (columnConfig.renderer) {
                        return columnConfig.renderer(value, record);
                    }
                    return value;
                }
            }
        );
        
        this.renderGrid();
    },

    applyStore: function(store) {
        return Ext.StoreManager.lookup(store);
    },

    updateStore: function(newStore, oldStore) {
        if (oldStore && Ext.isObject(oldStore) && oldStore.isStore) {
            oldStore.un('refresh', this.renderGrid, this);
        }

        newStore.on('refresh', this.renderGrid, this);

        this.renderGrid();
    },

    renderGrid: function() {
        if (this.getStore() && this.gridHeader && this.gridBody) {
            this.gridHeaderTpl.overwrite(this.gridHeader.getInnerHtmlElement(), { columns: this.getColumns(), data: this.getStore().getData().items });
            this.gridBodyTpl.overwrite(this.gridBody.getInnerHtmlElement(), { columns: this.getColumns(), data: this.getStore().getData().items });

            // If we've enabled the scroling (after first paint)
            if (this.gridBody.getScrollable()) {
                // Reset scroll position to top.
                this.gridBody.getScrollable().getScroller().scrollTo(0, 0);
            }
        }
    },

    // see http://jira.jda.com/browse/CAGE-2555 for more details
    _setupHackToEnableScrolling: function() {
        this.on('painted', function() {
            this.gridBody.setScrollable('vertical');
        }, this, { delay: 50, single: true });
    }
});
