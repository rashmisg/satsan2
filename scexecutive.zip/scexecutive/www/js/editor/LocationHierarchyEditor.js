Ext.define('Jda.SCExecutive.editor.LocationHierarchyEditor', {
    singleton: true,

    config: {
        editorView: null,
        dataCacheManagerId: 'locationHierarchyEditor'
    },

    constructor: function(config) {
        this.initConfig(config);
    },

    integrateCustomizedNames: function(callback, scope) {
        var me = this;

        Jda.mobility.plugins.DataCacheManager.loadData(this.getDataCacheManagerId(), function(data) {
            me._applyCustomizedNamesToHierarchy(data);

            Ext.callback(callback, scope);
        });
    },

    showEditorView: function() {
        if (this.getEditorView()) {
            return;
        }

        var editorView = Ext.create('Jda.SCExecutive.editor.LocationHierarchyEditorView', {
            listeners: {
                applychanges: this._applyChanges,
                cancelchanges: this._destroyEditorView,
                resetchanges: this._promptResetConfirmation,
                scope: this
            }
        });

        Ext.Viewport.add(editorView);

        this.setEditorView(editorView);
    },

    _applyChanges: function() {
        var treeStoreRecords = this.getEditorView().getStore().getData().all;
        var data = {};

        Ext.Array.each(treeStoreRecords, function(record) {
            if (record.hasModifiedNameAndItsNotEmpty()) {
                var hierarchyPath = record.get('location').getHierarchyPath();

                data[hierarchyPath] = record.get('name');
            }
        });

        Jda.mobility.plugins.DataCacheManager.saveData(this.getDataCacheManagerId(), data);

        this._applyCustomizedNamesToHierarchy(data);

        Jda.SCExecutive.util.AppContext.refresh();

        this._destroyEditorView();
    },

    _promptResetConfirmation: function() {
        Jda.mobility.plugins.DialogManager.confirm({
            message: Jda.getMessage('jda.scexecutive.editor.ResetConfirmationMessage'),
            callback: Ext.bind(this._resetChanges, this)
        });
    },

    _resetChanges: function() {
        Jda.mobility.plugins.DataCacheManager.clearCache();

        this._iterateHierarchy(function(locationHierarchy) {
            locationHierarchy.set('name', locationHierarchy.get('originalName'));

            this._clearCachedLocationHierarchyColor(locationHierarchy);
        });

        Jda.SCExecutive.util.AppContext.refresh();

        this._destroyEditorView();
    },

    _destroyEditorView: function() {
        this.getEditorView().destroy();
        this.setEditorView(null);
    },

    /**
     * Traverses the location hierarchy and updates any locations that have customized names.
     * @param {Object} data An object where the keys are location hierarchy paths and the values
     * are the customized names, e.g. { "USA": "'Merica", "USA/Midwest/WI": "The Badger State" }
     */
    _applyCustomizedNamesToHierarchy: function(data) {
        if (data) {
            this._iterateHierarchy(function(locationHierarchy) {
                var locationPath = locationHierarchy.getHierarchyPath();
                var customizedName = data[locationPath];

                if (customizedName) {
                    locationHierarchy.set('name', customizedName);
                }
                else {
                    locationHierarchy.set('name', locationHierarchy.get('originalName'));
                }

                this._clearCachedLocationHierarchyColor(locationHierarchy);
            });
        }
    },

    _iterateHierarchy: function(fn) {
        var rootLocationHierarchy = Jda.SCExecutive.util.AppContext.getRootLocationHierarchy();

        var iterate = function(parentHierarchy, scope) {
            parentHierarchy.children().each(function(childHierarchy) {
                fn.call(scope, childHierarchy);

                iterate(childHierarchy, scope);
            }, scope);
        };

        iterate(rootLocationHierarchy, this);
    },

    /**
     * Clears the cached color on the LocationHierarchy object.  This needs to happen as a part of the apply + reset process
     * because the names in the store(s) are changing (a change event per record update).  This needs to be called after the
     * record edit (which fires the event), because the color is not a normal store field, and is derived based on that record's
     * location within the parent store.  After all the edits are made, the global context refresh happens, which will then
     * trigger calls to the location's getColor method which will then re-cache the new value.
     */
    _clearCachedLocationHierarchyColor: function(locationHierarchy) {
        locationHierarchy.setColor(null);
    }
});
