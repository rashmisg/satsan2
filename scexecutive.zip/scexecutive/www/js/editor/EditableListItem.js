Ext.define('Jda.SCExecutive.editor.EditableListItem', {
    extend: 'Ext.dataview.component.ListItem',
    xtype: 'editablelistitem',

    config: {
        textfield: {
            xtype: 'textfield',
            padding: 8,
            width: 300,
            labelWidth: 0
        },

        dataMap: {
            getTextfield: {
                setValue: 'name'
            }
        }
    },

    applyTextfield: function(config) {
        return Ext.factory(config, Ext.field.Textfield, this.getTextfield());
    },

    updateTextfield: function(field) {
        field.on('change', this._onTextFieldChange, this);

        this.add(field);
    },

    _onTextFieldChange: function(field, newValue) {
        this.getRecord().set('name', newValue);
    }
});
