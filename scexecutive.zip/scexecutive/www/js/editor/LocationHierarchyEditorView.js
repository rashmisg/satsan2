Ext.define('Jda.SCExecutive.editor.LocationHierarchyEditorView', {
    extend: 'Ext.Container',

    config: {
        store: null,

        width: 600,
        height: 500,
        top: 40,
        modal: true,
        layout: 'fit'
    },

    initialize: function() {
        this.callParent(arguments);

        this.setStore(this._createStore());

        this.add(this._createNestedListConfig());
        this.add(this._createBottomToolbarConfig());

        // programmatically centering the editor horizontally because there doesn't seem to
        // be a config or API to easily do this without vertically centering it as well
        this.setLeft((Ext.Viewport.getWidth() / 2) - (this.getWidth() / 2));
    },

    _createNestedListConfig: function() {
        return {
            xtype: 'editablenestedlist',
            title: Jda.getMessage('jda.scexecutive.editor.Title'),
            store: this.getStore()
        };
    },

    _createBottomToolbarConfig: function() {
        return {
            xtype: 'toolbar',
            docked: 'bottom',
            items: [{
                text: Jda.getMessage('jda.scexecutive.editor.CancelButtonText'),
                handler: Ext.Function.pass(this.fireEvent, ['cancelchanges'], this),
                scope: this
            }, {
                text: Jda.getMessage('jda.scexecutive.editor.ResetButtonText'),
                handler: Ext.Function.pass(this.fireEvent, ['resetchanges'], this),
                scope: this
            }, {
                xtype: 'spacer'
            }, {
                text: Jda.getMessage('jda.scexecutive.editor.ApplyButtonText'),
                handler: Ext.Function.pass(this.fireEvent, ['applychanges'], this),
                scope: this
            }]
        };
    },

    _createStore: function() {
        var rootLocationHierarchy = Jda.SCExecutive.util.AppContext.getRootLocationHierarchy();

        var data = {
            name: rootLocationHierarchy.get('name'),
            location: rootLocationHierarchy,
            children: []
        };

        function addChildNodes(parentNode) {
            parentNode.location.children().each(function(childLocation) {
                var childNode = {
                    name: childLocation.get('name'),
                    location: childLocation,
                    children: []
                };

                parentNode.children.push(childNode);

                if (childLocation.children().getCount() === 0) {
                    childNode.leaf = true;
                    childNode.disclosure = false;
                } else {
                    addChildNodes(childNode);
                }
            });
        }

        addChildNodes(data);

        return Ext.create('Ext.data.TreeStore', {
            model: 'Jda.SCExecutive.editor.LocationTreeStoreModel',
            root: data
        });
    }
});
