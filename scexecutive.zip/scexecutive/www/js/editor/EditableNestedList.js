Ext.define('Jda.SCExecutive.editor.EditableNestedList', {
    extend: 'Ext.dataview.NestedList',
    xtype: 'editablenestedlist',

    config: {
        cls: 'editable-nested-list',
        onItemDisclosure: true,
        updateTitleText: false,
        useTitleAsBackText: false,
        useSimpleItems: false,
        listConfig: {
            defaultType: 'editablelistitem',
            selectedCls: null,
            itemHeight: 60
        }
    },

    // Override to prevent list item selection (and consequently drilling down to the
    // next hierarchy level) when tapping on the text field to begin editing
    onItemInteraction: function(list, index, target, record, e, eOpts) {
        var tappedOnTextField = target.getTextfield().element.contains(e.target);
        if (tappedOnTextField) {
            return false;
        }

        return this.callParent(arguments);
    },

    goToNode: function(node) {
        this.callParent(arguments);
        if (node.parentNode) {
            this.getBackButton().setText(node.get('name'));
        }
        else {
            this.getBackButton().setText('');
        }
    },

    // Override to prevent the keyboard from automatically popping up when drilling down a
    // level because the event continues on as the DOM is being rejiggered.  Seemingly
    // related to the following Sencha Touch bug:
    // http://www.sencha.com/forum/showthread.php?261377-Keyboard-opens-up-when-touching-the-screen-where-a-text-field-is-about-to-show
    onItemTap: function (list, index, target, record, e) {
        this.callParent(arguments);

        e.preventDefault();
    }
});
