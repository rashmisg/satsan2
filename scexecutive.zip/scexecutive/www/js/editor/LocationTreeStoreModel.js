Ext.define('Jda.SCExecutive.editor.LocationTreeStoreModel', {
    extend: 'Ext.data.Model',
    config: {
        fields: ['name', 'location', 'children', 'disclosure']
    },

    hasModifiedNameAndItsNotEmpty: function() {
        var hasModifiedName = this.get('name') !== this.get('location').get('originalName');
        var itsNotEmpty = !Ext.isEmpty(this.get('name'));

        return hasModifiedName && itsNotEmpty;
    }
});
