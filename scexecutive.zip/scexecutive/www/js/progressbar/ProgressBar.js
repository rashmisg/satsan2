Ext.define('Jda.SCExecutive.progressbar.ProgressBar', {
    extend: 'Ext.Container',
    xtype: 'progressbar',

    config: {
        labelText: null,

        cls: 'progress-bar',
        layout: 'vbox',
        items: [{
            xtype: 'draw',
            itemId: 'bardrawingregion',
            cls: 'bar-drawing-region',
            height: 10
        }, {
            layout: 'hbox',
            height: 15,
            items: [{
                itemId: 'progressbarlabel',
                cls: 'progress-bar-label',
                xtype: 'label'
            }, {
                flex: 1 // spacer
            }, {
                itemId: 'progressbarvalues',
                cls: 'progress-bar-values',
                xtype: 'label'
            }]
        }]
    },

    _value: undefined,
    _budget: undefined,

    initialize: function() {
        this.callParent(arguments);

        this.on('resize', this._updateProgressBar, this);
    },

    updatePeriodHierarchy: function(periodHierarchy) {
        var displayString = this._calculateTimePeriodString(periodHierarchy);
        var progressBarLabel = this.down('#progressbarlabel');

        progressBarLabel.setHtml(displayString);
    },

    updateValues: function(value, budget) {
        this._value = value || 0;
        this._budget = budget || 0;

        var progressBarValues = this.down('#progressbarvalues'),
            progressBarLabel = this.down('#progressbarlabel'),
            formattedValue = Jda.SCExecutive.util.Formatters.MetricFormatter.formatCurrency(value),
            formattedBudget = Jda.SCExecutive.util.Formatters.MetricFormatter.formatCurrency(budget),
            labelText = Ext.String.format(Jda.getMessage('jda.scexecutive.progressbar.ValueLabelFormat'), formattedValue, formattedBudget);

        // Update the display label
        progressBarValues.setHtml(labelText);

        // Attempt progress bar update
        this._updateProgressBar();
    },

    _updateProgressBar: function() {
        // If this container hasn't yet been rendered, we won't have any size to use while laying out.
        // If we don't have a value and budget, we won't be able to calculate an appropriate bar.
        if (!this.isRendered() || this._value === undefined || this._budget === undefined) {
            return;
        }

        if (!this.isPainted()) {
            this.on('painted', this._updateProgressBar, this, { single: true });
        }

        var drawingRegion = this.down('#bardrawingregion'),
            surface = drawingRegion.getSurface('main'),
            width = drawingRegion.element.getWidth(),
            height = drawingRegion.element.getHeight(),
            numDividers = 4,
            dividerWidth = width / numDividers,
            currentPoint, i,
            baseBarConf = { // This item spans the whole drawing region
                type: 'rect',
                x: 0,
                y: 0,
                width: width,
                height: height,
                fillStyle: '#f1f1f1'
            },
            dividerLineConf = { // These represent evenly spaced interval separators, currently 25% each
                type: 'path',
                path: [],
                stroke: '#fff'
            };

        // Clear any existing elements
        surface.removeAll();

        // Create dividers each region. Skip 0
        for (i = 1; i < numDividers; i++) {
            currentPoint = Math.floor(dividerWidth * i) + 0.5; // Floor, then add 0.5 to avoid antialiasing

            // Add this to the divider config's path elements
            dividerLineConf.path.push('M ' + currentPoint + ',0 L ' + currentPoint + ',' + height + ' Z');
        }

        // If the value is greater than the budget, we just fill the whole bar with red
        if (this._value > this._budget) {
            baseBarConf.fillStyle = Jda.SCExecutive.constant.Colors.red;

            surface.add(baseBarConf, dividerLineConf);
        }
        // Otherwise, we have a gray base bar with a proportional blue bar showing progress
        else {
            var blueBarConf = {
                type: 'rect',
                x: 0,
                y: 0,
                width: width * (this._value / this._budget),
                height: height,
                fillStyle: Jda.SCExecutive.constant.Colors.blue
            };

            surface.add(baseBarConf, blueBarConf, dividerLineConf);
        }
    },

    _calculateTimePeriodString: function(periodHierarchy) {
        var type = periodHierarchy.get('type');
        var types = Jda.SCExecutive.model.PeriodHierarchy.types;
        var start, periodString;

        if (type === types.MONTH) {
            start = periodHierarchy.get('start');
            periodString = Jda.mobility.i18n.Date.format(start, Jda.mobility.i18n.Date.FULL_MONTH);
        }
        else if (type === types.WEEK) {
            var month = periodHierarchy.get('parent');
            start = month.get('start');
            periodString = Jda.mobility.i18n.Date.format(start, Jda.mobility.i18n.Date.FULL_MONTH);
        }
        else {
            periodString = periodHierarchy.getDisplayString();
        }

        return Ext.String.format(Jda.getMessage('jda.scexecutive.progressbar.TimePeriodBudgetFormat'), periodString);
    }
});
