Ext.Loader.setConfig({
    disableCaching: false
});

Ext.Loader.setPath({
    'Jda': '.'
});

Ext.application({
    name: 'SCExecutive',

    viewport: {
        layout: 'card'
    },

    controllers: [ 'Jda.SCExecutive.controller.Overview', 'Jda.SCExecutive.controller.CustomerService', 'Jda.SCExecutive.controller.Transportation', 'Jda.SCExecutive.controller.Inventory', 'Jda.SCExecutive.controller.Labor' ],

    launch: function() {
        var pageContext = Jda.mobility.plugins.PageContextManager.getLastPageContext();
        var isDemoMode = pageContext.isDemoMode;

        Jda.SCExecutive.util.DataService.isDemoMode = pageContext.isDemoMode;

        if (isDemoMode) {
            // The demo data files only work for this specific date.  This workaround is so that if whatever REFS server
            // was used to login for demo mode purposes didn't have the right demo date set, the requests will still work.
            Jda.mobility.core.Sundial.setServerTime(new Date('2014-02-11T00:00:00-06:00'));
        }

        // We listen for active item changes on the viewport to move the shared legend around
        Ext.Viewport.on('activeitemchange', this._onViewportActiveItemChange, this);
        Ext.Viewport.on('childitemchange', this._onViewportChildItemChange, this);
        Jda.mobility.plugins.NotificationManager.addListener(Jda.mobility.constants.Notifications.REAUTH_SUCCESS_NOTIFICATION, this._onReauthenticationSuccessNotification);
        this._configureCorporateCurrency();

        // The native side is already showing the loading mask at this point.
        this._isShowingLoadingMask = true;

        this._locationHierarchyReport = Ext.create('Jda.SCExecutive.model.LocationHierarchyReport');
        this._locationHierarchyReport.on('load', this._onGlobalContextItemLoad, this);
        this._locationHierarchyReport.on('error', this._onGlobalContextItemError, this);
        this._locationHierarchyReport.load();

        this._periodHierarchyReport = Ext.create('Jda.SCExecutive.model.PeriodHierarchyReport');
        this._periodHierarchyReport.on('load', this._onGlobalContextItemLoad, this);
        this._periodHierarchyReport.on('error', this._onGlobalContextItemError, this);
        this._periodHierarchyReport.load();

        // Create shared Models and give them to their corresponding controllers
        var overviewController = this.getController('Jda.SCExecutive.controller.Overview');
        var customerServiceController = this.getController('Jda.SCExecutive.controller.CustomerService');
        var transportationController = this.getController('Jda.SCExecutive.controller.Transportation');
        var inventoryController = this.getController('Jda.SCExecutive.controller.Inventory');
        var laborController = this.getController('Jda.SCExecutive.controller.Labor');

        this._customerServicePerformanceModel = Ext.create('Jda.SCExecutive.model.CustomerServicePerformance');
        overviewController.setCustomerServicePerformanceModel(this._customerServicePerformanceModel);
        customerServiceController.setCustomerServicePerformanceModel(this._customerServicePerformanceModel);

        this._transportationSpendModel = Ext.create('Jda.SCExecutive.model.TransportationSpend');
        overviewController.setTransportationSpendModel(this._transportationSpendModel);
        transportationController.setTransportationSpendModel(this._transportationSpendModel);

        this._onTimeDeliveryModel = Ext.create('Jda.SCExecutive.model.OnTimeDelivery');
        customerServiceController.setOnTimeDeliveryModel(this._onTimeDeliveryModel);
        transportationController.setOnTimeDeliveryModel(this._onTimeDeliveryModel);

        this._inventoryValueModel = Ext.create('Jda.SCExecutive.model.InventoryValue');
        overviewController.setInventoryValueModel(this._inventoryValueModel);
        inventoryController.setInventoryValueModel(this._inventoryValueModel);

        this._averageDaysOfSupply = Ext.create('Jda.SCExecutive.model.AverageDaysOfSupply');
        overviewController.setAverageDaysOfSupplyModel(this._averageDaysOfSupply);
        inventoryController.setAverageDaysOfSupplyModel(this._averageDaysOfSupply);

        this._laborSpendModel = Ext.create('Jda.SCExecutive.model.LaborSpend');
        overviewController.setLaborSpendModel(this._laborSpendModel);
        laborController.setLaborSpendModel(this._laborSpendModel);

        this._laborHoursModel = Ext.create('Jda.SCExecutive.model.LaborHours');
        overviewController.setLaborHoursModel(this._laborHoursModel);
        laborController.setLaborHoursModel(this._laborHoursModel);
    },

    applyTimePeriodFilter: function(group, index) {
        var selectedPeriodHierarchy = this._periodHierarchyReport.getPeriodGroups()[group][index];
        Jda.SCExecutive.util.AppContext.setCurrentPeriodHierarchy(selectedPeriodHierarchy);
    },

    showLoadingMaskIfNecessary: function() {
        if (this._isShowingLoadingMask === false) {
            this._isShowingLoadingMask = true;

            Jda.mobility.plugins.LoadingMaskManager.showLoadingMask();
        }
    },

    hideLoadingMaskIfNecessary: function() {
        if (this._isShowingLoadingMask === true) {
            this._isShowingLoadingMask = false;

            Jda.mobility.plugins.LoadingMaskManager.hideLoadingMask();
        }
    },

    _configureCorporateCurrency: function() {
        var corporateCurrencyRegionSymbol = Jda.mobility.plugins.PageContextManager.getLastPageContext()[Jda.SCExecutive.constant.Currency.CORPORATE_CURRENCY_REGION_SYMBOL];
        Jda.SCExecutive.util.Formatters.MetricFormatter.setCorporateCurrencyRegionSymbol(corporateCurrencyRegionSymbol);
    },

    _onGlobalContextItemLoad: function() {
        var rootLocationHierarchy = this._locationHierarchyReport.getRootLocationHierarchy();
        var rootPeriodHierarchy = this._periodHierarchyReport.getRootPeriodHierarchy();

        if (rootLocationHierarchy && rootPeriodHierarchy) {
            Jda.SCExecutive.util.AppContext.setRootLocationHierarchy(rootLocationHierarchy);

            if (Jda.SCExecutive.util.DataService.isDemoMode) {
                Jda.SCExecutive.editor.LocationHierarchyEditor.integrateCustomizedNames(this._finishContextInitialization, this);
            }
            else {
                this._finishContextInitialization();
            }
        }
    },

    _finishContextInitialization: function() {
        var rootLocationHierarchy = this._locationHierarchyReport.getRootLocationHierarchy();
        var sharedLegendView = Jda.SCExecutive.view.Legend.View.getSharedLegendView();

        sharedLegendView.setupLegendWithRootLocationHierarchy(rootLocationHierarchy);

        Jda.SCExecutive.controller.SCExecutiveController.initializeTimePeriodSelectorOptions(this._periodHierarchyReport);

        var lastWeek = this._periodHierarchyReport.getPeriodGroups()[0][0];

        Jda.SCExecutive.util.AppContext.setAppContext(rootLocationHierarchy, lastWeek);
    },

    _onGlobalContextItemError: function() {
        this.hideLoadingMaskIfNecessary();
    },

    _onViewportChildItemChange: function(viewport, activeItem) {
        this._addSharedViewComponentsToActiveView(activeItem);
    },

    _onViewportActiveItemChange: function(viewport, activeItem) {
        this._addSharedViewComponentsToActiveView(activeItem.getActiveItem());
    },

    _onReauthenticationSuccessNotification: function() {
        Jda.SCExecutive.util.AppContext.refresh();
    },

    _addSharedViewComponentsToActiveView: function(activeItem) {
        var legendView = Jda.SCExecutive.view.Legend.View.getSharedLegendView();
        var legendContainer = activeItem.down('legendcontainer');

        var contextView = Jda.SCExecutive.context.View.getSharedContextView();
        var contextContainer = activeItem.down('contextcontainer');

        if (legendContainer) {
            legendContainer.add(legendView);
        }

        if (contextContainer) {
            contextContainer.add(contextView);
        }
    }
});
