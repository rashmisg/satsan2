Ext.define('Jda.SCExecutive.model.OrderFillRate', {
    extend: 'Jda.SCExecutive.model.CognosReport',

    config: {
        reportName: 'CS_Order_Fill_Rate',
        reportFolder: 'Customer%20Service',

        store: null,
        locationHierarchies: null,
        periodHierarchy: null,
        lowestValue: null,
        highestValue: null,
        averageOutboundOrderFillRatePercent: null,
        orderFillRateTargetPercent: null,
        totalOrdersCount: null,
        ordersFilledCount: null
    },

    isOrderFillRatePercentGood: function() {
        var actual = this.getAverageOutboundOrderFillRatePercent();
        var target = this.getOrderFillRateTargetPercent();

        return target === undefined || actual >= target;
    },

    processResponse: function(config) {
        var targetPercent = this.extractMetaDataValue('Outbound_Order_Fill_Rate_Target_Pct', 'Outbound__Order__Fill__Rate__Target__Pct', config.periodHierarchy);
        var lowestValue = Number.MAX_VALUE;
        var highestValue = Number.MIN_VALUE;
        var reportDataRows = this.extractDataRows('Order_Fill_Rate_Pct', config.periodHierarchy, config.locationHierarchy);
        var periodRowLookupMap = {};
        var locationMap = {};
        var locationHierarchies = [];
        var locationLookupMap = this._getLocationHierarchyMap(config.locationHierarchy);
        var data = reportDataRows ? this._getBaselineRows(config.periodHierarchy, targetPercent, periodRowLookupMap) : undefined;

        Ext.each(reportDataRows, function(reportDataRow) {
            var periodCode = reportDataRow.Period;
            var periodRow = periodRowLookupMap[periodCode];
            var locationCode = reportDataRow.Location;
            var locationHierarchy = locationLookupMap[locationCode];

            if (!periodRow) {
                this.logMissingHierarchy(periodCode);
                return;
            }

            if (!locationHierarchy) {
                this.logMissingHierarchy(locationCode);
                return;
            }

            var value = reportDataRow.Order__Fill__Rate__Pct;

            periodRow[locationHierarchy] = value;
            lowestValue = Math.min(lowestValue, value);
            highestValue = Math.max(highestValue, value);

            // using this effectively as a set collection, it contains the location codes encountered in the reports data
            locationMap[locationHierarchy] = true;
            locationHierarchies.push(locationHierarchy);
        }, this);

        var locationFields = Ext.Object.getKeys(locationMap);

        // Check for the case that the target value is lower than the lowest observed value
        if (targetPercent !== undefined) {
            lowestValue = Math.min(lowestValue, targetPercent);
            highestValue = Math.max(highestValue, targetPercent);
        }

        this.setStore(Ext.create('Ext.data.Store', {
            fields: locationFields.concat('targetPercent', 'periodHierarchy', 'contextPeriodHierarchy'),
            data: data
        }));

        this.setLocationHierarchies(Ext.Array.unique(locationHierarchies));
        this.setPeriodHierarchy(config.periodHierarchy);
        this.setLowestValue(lowestValue);
        this.setHighestValue(highestValue);
        this.setAverageOutboundOrderFillRatePercent(this.extractMetaDataValue('Avg_Outbound_Order_Fill_Rate_Pct', 'Avg__Outbound__Order__Fill__Rate__Pct'));
        this.setOrderFillRateTargetPercent(targetPercent);
        this.setTotalOrdersCount(this.extractMetaDataValue('Total_Orders', 'Total__Orders'));
        this.setOrdersFilledCount(this.extractMetaDataValue('Orders_Filled', 'Orders__Filled'));
    },

    _getBaselineRows: function(parentPeriodHierarchy, targetPercent, periodRowLookupMap) {
        var rows = [];
        var type = parentPeriodHierarchy.get('type');
        var types = Jda.SCExecutive.model.PeriodHierarchy.types;

        var addRowObject = function(periodHierarchy) {
            var row = {
                date: periodHierarchy.get('value'),
                periodHierarchy: periodHierarchy,
                contextPeriodHierarchy: parentPeriodHierarchy,
                targetPercent: targetPercent
            };

            // populate to use for quick lookups of row objects while processing the report rows
            periodRowLookupMap[row.date] = row;

            rows.push(row);
        };

        // week + month show direct children, quarter + year show grandchildren
        if (type === types.WEEK || type === types.MONTH) {
            parentPeriodHierarchy.children().each(addRowObject);
        }
        else if (type == types.QUARTER || type === types.YEAR) {
            parentPeriodHierarchy.children().each(function(child) {
                child.children().each(addRowObject);
            });
        }

        return rows;
    },

    _getLocationHierarchyMap: function(parentLocationHierarchy) {
        var locationLookupMap = {};

        parentLocationHierarchy.children().each(function(locationHierarchy) {
            locationLookupMap[locationHierarchy.get('code')] = locationHierarchy;
        });

        return locationLookupMap;
    }
});
