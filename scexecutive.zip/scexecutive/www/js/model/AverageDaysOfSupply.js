Ext.define('Jda.SCExecutive.model.AverageDaysOfSupply', {
    extend: 'Jda.SCExecutive.model.CognosReport',

    config: {
        reportName: 'IN_Days_of_Supply',
        reportFolder: 'Inventory',

        periodHierarchy: null,

        store: null,
        priorSupplyChainAverage: null,
        supplyChainAverage: null,

        lowestSupplyValue: null,
        highestSupplyValue: null
    },

    processResponse: function(config) {
        var averageDaysOfSupply = this.extractMetaDataValue('Avg_Days_of_Supply', 'Avg__Days__of__Supply');
        var priorAverageDaysOfSupply = this.extractMetaDataValue('Prior_Avg_Days_of_Supply', 'Prior__Avg__Days__of__Supply', config.periodHierarchy);
        var chartData = this.extractDataRows('Days_of_Supply', config.periodHierarchy, config.locationHierarchy);

        var lowestSupply = Number.MAX_VALUE;
        var highestSupply = Number.MIN_VALUE;
        var storeData = [];
        Ext.each(chartData, function(datum) {
            var locationCode = datum.Location;
            var locationHierarchy = config.locationHierarchy.getChildFromCode(locationCode);

            if (!locationHierarchy) {
                this.logMissingHierarchy(locationCode);
                return;
            }

            storeData.push({
                locationHierarchy: locationHierarchy,
                value: datum.Days__of__Supply
            });

            lowestSupply = Math.min(lowestSupply, datum.Days__of__Supply);
            highestSupply = Math.max(highestSupply, datum.Days__of__Supply);
        }, this);

        this.setStore(Ext.create('Ext.data.Store', {
            fields: [ 'locationHierarchy', 'value' ],
            sorters:[
                Jda.SCExecutive.util.Sorters.DisplayValueSorter.createSorter({
                    direction: 'DESC',
                    field: 'value'
                }),
                {
                    property: 'locationHierarchy',
                    direction: 'ASC'
                }
            ],
            data: storeData
        }));

        this.setPeriodHierarchy(config.periodHierarchy);
        this.setPriorSupplyChainAverage(priorAverageDaysOfSupply);
        this.setSupplyChainAverage(averageDaysOfSupply);
        this.setLowestSupplyValue(lowestSupply);
        this.setHighestSupplyValue(highestSupply);
    }
});
