Ext.define('Jda.SCExecutive.model.TopTenCustomers', {
    extend: 'Jda.SCExecutive.model.CognosReport',


    config: {
        reportName: 'CS_Top_10_Customers',
        reportFolder: 'Customer%20Service',

        store: null
    },

    processResponse: function(config) {
        var data = this.extractDataRows('Revenue', config.periodHierarchy, config.locationHierarchy);

        this.setStore(Ext.create('Ext.data.Store', {
            fields: [{
                name: 'name', mapping: 'Customer'
            }, {
                name: 'revenue', type: 'int', mapping: 'Revenue'
            }, {
                name: 'fillRate', type: 'float', mapping: 'Fill__Rate__Pct'
            }, {
                name: 'onTime', type: 'float', mapping: 'On__Time__Pct'
            }, {
                name: 'unshipped', type: 'int', mapping: 'Unshipped'
            }],
            sorters:[
                Jda.SCExecutive.util.Sorters.DisplayValueSorter.createSorter({
                    direction: 'DESC',
                    field: 'revenue'
                }),
                {
                    property: 'name',
                    direction: 'ASC'
                }
            ],
            data: data
        }));
    }
});
