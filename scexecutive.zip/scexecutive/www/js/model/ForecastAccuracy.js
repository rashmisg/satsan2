Ext.define('Jda.SCExecutive.model.ForecastAccuracy', {
    extend: 'Jda.SCExecutive.model.CognosReport',

    config: {
        reportName: 'OV_Forecast_Accuracy',
        reportFolder: 'Overview',

        periodHierarchy: null,

        store: null,
        forecastAccuracyPercent: null,
        forecastAccuracyPercentTarget: null,

        totalSales: null,
        priorTotalSales: null,
        forecastedSales: null,
        priorForecastedSales: null,

        lag: null
    },

    // Good if no target is defined, or average is less than or equal to target
    isForecastAccuracyGood: function() {
        var actual = this.getForecastAccuracyPercent();
        var target = this.getForecastAccuracyPercentTarget();

        return target === undefined || actual >= target;
    },

    processResponse: function(config) {
        // forecastAccuracy and the target are now subtracted from 100% to demo better, instead of representing the MAPE.
        var forecastAccuracyPercent = 100 - this.extractMetaDataValue('Forecast_Accuracy_Pct', 'Forecast__Accuracy__Pct');
        var forecastAccuracyPercentTarget = 100 - this.extractMetaDataValue('Forecast_Accuracy_Pct_Target', 'Forecast__Accuracy__Pct__Target', config.periodHierarchy);

        var totalSales = this.extractMetaDataValue('Total_Sales', 'Total__Sales');
        var priorTotalSales = this.extractMetaDataValue('Prior_Total_Sales', 'Prior__Total__Sales', config.periodHierarchy);

        var forecastedSales = this.extractMetaDataValue('Total_Sales_Forecast', 'Total__Sales__Forecast');
        var priorForecastedSales = this.extractMetaDataValue('Prior_Total_Sales_Forecast', 'Prior__Total__Sales__Forecast', config.periodHierarchy);

        var lag = this.extractMetaDataValue('Lag', 'Lag');
        var data = this.extractDataRows('Sales', config.periodHierarchy, config.locationHierarchy);
        var storeData = [];

        Ext.each(data, function(row) {
            var locationCode = row.Location;
            var locationHierarchy = config.locationHierarchy.getChildFromCode(locationCode);

            if (!locationHierarchy) {
                this.logMissingHierarchy(locationCode);
                return;
            }

            storeData.push({
                locationHierarchy: locationHierarchy,
                sales: row.Sales,
                forecast: row.Forecast__Sales
            });
        }, this);

        this.setStore(Ext.create('Ext.data.Store', {
            fields: [ 'locationHierarchy', 'sales', 'forecast' ],
            sorters:[
                Jda.SCExecutive.util.Sorters.DisplayValueSorter.createSorter({
                    direction: 'DESC',
                    field: 'sales'
                }),
                {
                    property: 'locationHierarchy',
                    direction: 'ASC'
                }
            ],
            data: storeData
        }));

        this.setPeriodHierarchy(config.periodHierarchy);
        this.setForecastAccuracyPercent(forecastAccuracyPercent);
        this.setForecastAccuracyPercentTarget(forecastAccuracyPercentTarget);
        this.setTotalSales(totalSales);
        this.setPriorTotalSales(priorTotalSales);
        this.setForecastedSales(forecastedSales);
        this.setPriorForecastedSales(priorForecastedSales);
        this.setLag(lag);
    }
});
