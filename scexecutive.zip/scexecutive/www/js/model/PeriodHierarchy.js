Ext.define('Jda.SCExecutive.model.PeriodHierarchy', {
    extend: 'Ext.data.Model',

    config: {
        fields: [ 'value', 'fiscalCount', 'type', 'parent', 'isRoot', 'hasPrevious', { name: 'start', type: 'date' }, { name: 'end', type: 'date' } ],
        associations: [{
            type: 'hasMany',
            model: 'Jda.SCExecutive.model.PeriodHierarchy',
            name: 'children',
            associationKey: 'children'
        }, {
            type: 'hasOne',
            model: 'Jda.SCExecutive.model.PeriodHierarchy',
            name: 'next',
            associatedName: 'next'
        }, {
            type: 'hasOne',
            model: 'Jda.SCExecutive.model.PeriodHierarchy',
            name: 'previous',
            associatedName: 'previous'
        }]
    },

    statics: {
        types: {
            YEAR: 'Year',
            QUARTER: 'Quarter',
            MONTH: 'Month',
            WEEK: 'Week',
            DATE: 'Date'
        },

        typesList: [
            'Week',
            'Month',
            'Quarter',
            'Year'
        ]
    },

    getDisplayString: function(isShortFormat) {
        var type = this.get('type'),
            types = Jda.SCExecutive.model.PeriodHierarchy.types;

        if (type === types.YEAR) {
            return this.get('value') + '';
        }
        else if (type === types.QUARTER) {
            var value = this.get('value'),
                pieces = value.split('-'),
                year = pieces[0],
                quarter = pieces[1].substring(1), // just the number portion
                quarterFormatString = Jda.getMessage('jda.scexecutive.periodhierarchy.QuarterYearDisplayStringFormat');

            return Ext.String.format(quarterFormatString, quarter, year);
        }
        else if (type === types.MONTH || type === types.WEEK) {
            var formattedStart, formattedEnd;
            if (isShortFormat) {
                formattedStart = Jda.mobility.i18n.Date.format(this.get('start'), Jda.mobility.i18n.Date.MEDIUM_DATE_EXP);
                //This formatting will obviously break localization. We need to add a 'MMM dd, yyyy' format to globalize.
                formattedEnd = Jda.mobility.i18n.Date.format(this.get('end'), Jda.mobility.i18n.Date.MEDIUM_DATE_EXP) + ', ' + Jda.mobility.i18n.Date.format(this.get('end'), Jda.mobility.i18n.Date.LONG_YEAR);
            }
            else {
                formattedStart = Jda.mobility.i18n.Date.format(this.get('start'), Jda.mobility.i18n.Date.FULL_MONTH_DATE);
                formattedEnd = Jda.mobility.i18n.Date.format(this.get('end'), Jda.mobility.i18n.Date.FULL_DATE_WITHOUT_DAY_NAME);
            }

            if (type === types.WEEK) {
                var fiscalCount = this.get('fiscalCount');
                var weekFormatString = Jda.getMessage('jda.scexecutive.periodhierarchy.WeekDisplayStringFormat');
                return Ext.String.format(weekFormatString, formattedStart, formattedEnd, fiscalCount);
            }

            var monthFormatString = Jda.getMessage('jda.scexecutive.periodhierarchy.MonthDisplayStringFormat');
            return Ext.String.format(monthFormatString, formattedStart, formattedEnd);
        }
    },

    getPeriodFromDateString: function(dateString) {
        return this.children().findRecord('value', dateString);
    },

    // Overriding toString so that we can pass PeriodHierarchy objects into charts, which toString's objects when it's determining
    // the points on the graph. The default behavior of this would be [Object object], and only ever show one record.
    toString: function() {
        return this.get('value');
    }
});
