Ext.define('Jda.SCExecutive.model.UnshippedOrders', {
    extend: 'Jda.SCExecutive.model.CognosReport',

    config: {
        reportName: 'CS_Unshipped_Orders',
        reportFolder: 'Customer%20Service',

        store: null,
        totalRevenue: null,
        unshippedOrdersCount: null,
        maximumValue: null
    },

    processResponse: function(config) {
        var locationHierarchyLookupMap = this._getLocationHierarchyMap(config.locationHierarchy);
        var totalRevenue = this.extractMetaDataValue('Total_Unshipped_Orders_Revenue', 'Total__Unshipped__Orders__Revenue');
        var unshippedOrdersCount = this.extractMetaDataValue('Number_of_Unshipped_Orders', 'Number__of__Unshipped__Orders');
        var dataRows = this.extractDataRows('Unshipped_Orders_Revenue', undefined, config.locationHierarchy) || [];
        var data = [];

        // Presort so that we can keep running percent totals
        Ext.Array.sort(dataRows, function(a, b) {
            // Start by comparing the values of these two rows.
            // If they're equal, compare their location hierarchy names.
            if (b.Unshipped__Orders__Revenue === a.Unshipped__Orders__Revenue) {
                var aLocationCode = a.Location;
                var aLocationHierarchy = locationHierarchyLookupMap[aLocationCode];
                var bLocationCode = a.Location;
                var bLocationHierarchy = locationHierarchyLookupMap[bLocationCode];

                // If either of the locations doesn't have an appropriate location hierarchy, just filter it out. Order doesn't
                // really matter, these will just get sorted to an end of the array, then be filtered out in the parsing below.
                if (!aLocationHierarchy || !bLocationHierarchy) {
                    return 1;
                }

                var aName = aLocationHierarchy.toString();
                var bName = bLocationHierarchy.toString();

                return aName.localeCompare(bName); //ASC Name sort
            }

            return b.Unshipped__Orders__Revenue - a.Unshipped__Orders__Revenue; //DESC value sort
        });

        // Go through each of the sorted points and figure out
        // how much of the running total it is (e.g. with
        // [ 6, 4, 2 ], 6 is 50%, 4 is 84%, 2 is 100%)
        var runningTotal = 0;
        Ext.each(dataRows, function(datum) {
            runningTotal += datum.Unshipped__Orders__Revenue;
            datum.percent = (runningTotal / totalRevenue) * 100;
        });

        Ext.each(dataRows, function(dataRow) {
            var locationCode = dataRow.Location;
            var locationHierarchy = locationHierarchyLookupMap[locationCode];

            if (!locationHierarchy) {
                this.logMissingHierarchy(locationCode);
                return;
            }

            var row = {
                locationHierarchy: locationHierarchy,
                value: dataRow.Unshipped__Orders__Revenue,
                percent: dataRow.percent
            };

            data.push(row);
        }, this);

        this.setStore(Ext.create('Ext.data.Store', {
            fields: [ 'locationHierarchy', 'value', 'percent' ],
            data: data,
            sorters: [
                Jda.SCExecutive.util.Sorters.DisplayValueSorter.createSorter({
                    direction: 'DESC',
                    field: 'value'
                })
            ]
        }));

        // The data values are sorted by value, so the max value is the value of the first item in the array
        this.setMaximumValue(dataRows[0] ? dataRows[0].Unshipped__Orders__Revenue : undefined);
        this.setTotalRevenue(totalRevenue);
        this.setUnshippedOrdersCount(unshippedOrdersCount);
    },

    _getLocationHierarchyMap: function(parentLocationHierarchy) {
        var locationLookupMap = {};

        parentLocationHierarchy.children().each(function(locationHierarchy) {
            locationLookupMap[locationHierarchy.get('code')] = locationHierarchy;
        });

        return locationLookupMap;
    }
});
