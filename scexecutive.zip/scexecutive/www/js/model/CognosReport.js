Ext.define('Jda.SCExecutive.model.CognosReport', {
    mixins: ['Ext.mixin.Observable'],

    config: {
        activeRequest: null,
        jsonData: null,

        reportName: null,
        reportFolder: null,
        reportRoot: 'rds/reportData/path/Public%20Folders/JDABA/Template%20Reports/SCExec%20Analytics%208.2/Interface',

        lastLoadedConfig: null
    },

    constructor: function(config) {
        this.initConfig(config);
    },

    load: function(config) {
        var url = Jda.SCExecutive.util.DataService.buildCognosUrl(this, config);

        // Prevent redundant load. Note that this prevents reloading. This could be addressed in the future if needed with a "force reload" concept
        // This currently assumes object order will be the same between loads, which could be unsafe (though in our case shouldn't ever be).
        var configString = Ext.Object.toQueryString(config);

        if (configString === this.getLastLoadedConfig() && !config.forceLoad) {
            this.fireEvent('shortcircuit');

            return;
        }

        this.setLastLoadedConfig(configString);

        var activeRequest = this.getActiveRequest();
        if (!Ext.isEmpty(activeRequest)) {
            Ext.Ajax.abort(activeRequest);
        }

        console.log('Requesting url: ' + url);

        var request = Ext.Ajax.request({
            url: url,
            config: config,
            callback: this._reportLoadCallback,
            headers: { accept: 'application/json' },
            timeout: 240000, // TODO remove this once Cognos isn't a turtle
            disableCaching: false,
            scope: this
        });

        this.setActiveRequest(request);
    },

    /**
     * Abstract methods for subclasses to implement.
     * @method
     */
    processResponse: function(config) {
        throw new Error(this.$className + ' must implement processResponse.');
    },

    getBeanPath: function() {
        return this.getReportRoot() + '/' + this.getReportFolder() + '/' + this.getReportName();
    },

    getBaseParams: function() {
        return { fmt: 'DataSet', uuid: Jda.SCExecutive.util.AppContext.getPageUuid() };
    },

    extractMetaDataValue: function(dataTableIdPrefix, rowId, periodHierarchy, locationHierarchy) {
        var dataKey = this._buildDataKey(dataTableIdPrefix, periodHierarchy, locationHierarchy);
        var number;

        Ext.Object.each(this.getJsonData(), function(key, value) {
            if (key === dataKey) {
                if (value.length > 0) {
                    number = value[0][rowId];
                }

                return false;
            }
        });

        return number;
    },

    extractDataRows: function(dataTableIdPrefix, periodHierarchy, locationHierarchy) {
        var dataKey = this._buildDataKey(dataTableIdPrefix, periodHierarchy, locationHierarchy);
        var array;

        Ext.Object.each(this.getJsonData(), function(key, value) {
            if (key === dataKey) {
                array = value;

                return false;
            }
        });

        return array;
    },

    logMissingHierarchy: function(hierarchy) {
        console.warn('Found an unknown hierarchy item while parsing ' + this.$className + ': ' + hierarchy);
    },

    _buildDataKey: function(dataTableIdPrefix, periodHierarchy, locationHierarchy) {
        var dataKey = dataTableIdPrefix;

        if (periodHierarchy) {
            dataKey += this._getSuffixForPeriodHierarchy(periodHierarchy);
        }

        if (locationHierarchy) {
            dataKey += this._getSuffixForLocationHierarchy(locationHierarchy);
        }

        return dataKey;
    },

    _getSuffixForPeriodHierarchy: function(periodHierarchy) {
        return '_' + periodHierarchy.get('type');
    },

    _getSuffixForLocationHierarchy: function(locationHierarchy) {
        if (locationHierarchy.get('isRoot') === true) {
            return '_All';
        }

        return '_' + locationHierarchy.get('level');
    },

    _reportLoadCallback: function(options, success, response) {
        this.setActiveRequest(null);

        if (success) {
            try {
                var jsonData = JSON.parse(response.responseText).data[0];
                this.setJsonData(jsonData);

                this.processResponse(options.config);

                this.fireEvent('load');
            }
            catch (e) {
                console.error('Error processing report class ' + this.$className + ': ' + e);

                this.fireEvent('error');
            }
        }
        else if (response.request.aborted !== true) {
            Jda.SCExecutive.util.DataService.handleRequestError(options.url, response);

            this.fireEvent('error');
        }
    }
});
