Ext.define('Jda.SCExecutive.model.LocationHierarchyReport', {
    extend: 'Jda.SCExecutive.model.CognosReport',

    config: {
        reportName: 'Location_Hierarchy',
        reportFolder: 'Hierarchy',
        reportRoot: "metadataXml/rds/outputFormat/searchPath/content/folder[@name='JDABA']/folder[@name='Template%20Reports']/folder[@name='SCExec%20Analytics%208.2']/folder[@name='Interface']",

        rootLocationHierarchy: null
    },

    getBeanPath: function() {
        return Ext.String.format("{0}/folder[@name='{1}']/report[@name='{2}']/XML", this.getReportRoot(), this.getReportFolder(), this.getReportName());
    },

    getBaseParams: function() {
        return { version: 'LATEST' };
    },

    processResponse: function() {
        var dataRows = this.extractDataRows('Location_Hierarchy');
        var levels = [];
        var levelCodeRegex = /L(\d+)__(.+)__Code/; // e.g. 'L1__Country__Code'

        // from the first row, parse the meta data of the hierarchy that the report contains
        Ext.Object.each(dataRows[0], function(key, value) {
            var match = key.match(levelCodeRegex);

            if (match !== null) {
                var levelOrder = parseInt(match[1], 10);
                var levelName = match[2];

                levels[levelOrder - 1] = {
                    name: levelName,
                    codeKey: match[0],
                    nameKey: 'L' + levelOrder + '__' + levelName + '__Name'
                };
            }
        });

        levels.pop(); // last one is assumed to be the bottom level 'Location' that we don't care about (yet)

        var rootLocationHierarchy = Ext.create('Jda.SCExecutive.model.LocationHierarchy', { name: 'all', level: 'root', isRoot: true }),
            rootLocation =  { model: rootLocationHierarchy, children: {} },
            currentLocation;

        // parse the actual rows
        Ext.each(dataRows, function(dataRow) {

            currentLocation = rootLocation; // set the current back to the root

            Ext.each(levels, function(level, index) {
                var locationCode = dataRow[level.codeKey];

                if (!currentLocation.children[locationCode]) {
                    var newModel = Ext.create('Jda.SCExecutive.model.LocationHierarchy', {
                        code: locationCode,
                        name: dataRow[level.nameKey],
                        originalName: dataRow[level.nameKey],
                        level: level.name,
                        parent: currentLocation.model
                    });

                    currentLocation.children[locationCode] = { model: newModel, children: {} };

                    currentLocation.model.children().add(newModel);
                }

                currentLocation = currentLocation.children[locationCode];
            });
        });

        this.setRootLocationHierarchy(rootLocationHierarchy);
    }
});
