Ext.define('Jda.SCExecutive.model.TransportationSpend', {
    extend: 'Jda.SCExecutive.model.CognosReport',

    config: {
        reportName: 'TR_Transportation_Cost_Summary',
        reportFolder: 'Transportation',

        periodHierarchy: null,

        inboundSpend: null,
        priorInboundSpend: null,
        inboundBudgetSpend: null,
        inboundBudget: null,
        inboundStore: null,
        inboundMinimumValue: null,
        inboundMaximumValue: null,
        inboundLocationHierarchies: null,

        outboundSpend: null,
        priorOutboundSpend: null,
        outboundBudgetSpend: null,
        outboundBudget: null,
        outboundStore: null,
        outboundMinimumValue: null,
        outboundMaximumValue: null,
        outboundLocationHierarchies: null,

        totalSpend: null,
        totalBudgetSpend: null,
        totalBudget: null,
        totalStore: null,
        totalMinimumValue: null,
        totalMaximumValue: null,
        totalMinimumLocationValue: null,
        totalMaximumLocationValue: null,
        totalLocationHierarchies: null
    },

    processResponse: function(config) {
        var periodHierarchy = config.periodHierarchy;
        var locationHierarchy = config.locationHierarchy;
        var inboundPeriodLookupMap = {};
        var inboundMinValue = Number.MAX_VALUE;
        var inboundMaxValue = Number.MIN_VALUE;
        var inboundLocationFields = [];
        var inboundLocationHierarchies = [];
        var outboundPeriodLookupMap = {};
        var outboundMinValue = Number.MAX_VALUE;
        var outboundMaxValue = Number.MIN_VALUE;
        var outboundLocationFields = [];
        var outboundLocationHierarchies = [];
        var totalPeriodLookupMap = {};
        var totalMinValue = Number.MAX_VALUE;
        var totalMaxValue = Number.MIN_VALUE;
        var totalMinLocationValue = Number.MAX_VALUE;
        var totalMaxLocationValue = Number.MIN_VALUE;
        var totalLocationFields = [];
        var totalLocationHierarchies = [];
        var locationLookupMap = this._getLocationLookupMap(locationHierarchy);

        var currentInboundSpend = this.extractMetaDataValue('Current_Period_Total_Inbound', 'Current__Period__Total__Inbound');
        var priorInboundSpend = this.extractMetaDataValue('Prior_Period_Budget_Spent_Inbound', 'Prior__Period__Budget__Spent__Inbound', periodHierarchy);
        var inboundBudgetSpend = this.extractMetaDataValue('Cumulative_Spend_Inbound', 'Cumulative__Spend__Inbound');
        var inboundBudget = this.extractMetaDataValue('Total_Spend_Budget_Inbound', 'Total__Spend__Budget__Inbound', periodHierarchy);
        var inboundDataRows = this.extractDataRows('Inbound_Trans_Costs', periodHierarchy, locationHierarchy);
        var currentOutboundSpend = this.extractMetaDataValue('Current_Period_Total_Outbound', 'Current__Period__Total__Outbound');
        var priorOutboundSpend = this.extractMetaDataValue('Prior_Period_Budget_Spent_Outbound', 'Prior__Period__Budget__Spent__Outbound', periodHierarchy);
        var outboundBudgetSpend = this.extractMetaDataValue('Cumulative_Spend_Outbound', 'Cumulative__Spend__Outbound');
        var outboundBudget = this.extractMetaDataValue('Total_Spend_Budget_Outbound', 'Total__Spend__Budget__Outbound', periodHierarchy);
        var outboundDataRows = this.extractDataRows('Outbound_Trans_Costs', periodHierarchy, locationHierarchy);

        var inboundPeriodRows = inboundDataRows ? this._getPeriodRows(periodHierarchy, inboundPeriodLookupMap) : undefined;
        var outboundPeriodRows = outboundDataRows ? this._getPeriodRows(periodHierarchy, outboundPeriodLookupMap) : undefined;
        var totalPeriodRows = inboundDataRows || outboundDataRows ? this._getPeriodRows(periodHierarchy, totalPeriodLookupMap) : undefined;

        Ext.each(inboundDataRows, function(row) {
            var value = row.Inbound__Trans__Costs;
            var periodCode = row.Period;
            var inboundRow = inboundPeriodLookupMap[periodCode];
            var totalRow = totalPeriodLookupMap[periodCode];
            var locationCode = row.Location;
            var locationHierarchy = locationLookupMap[locationCode];

            if (!inboundRow) {
                this.logMissingHierarchy(periodCode);
                return;
            }

            if (!locationHierarchy) {
                this.logMissingHierarchy(locationCode);
                return;
            }

            inboundMinValue = Math.min(inboundMinValue, value);
            inboundMaxValue = Math.max(inboundMaxValue, value);

            inboundRow[locationHierarchy] = value;
            totalRow[locationHierarchy] = value;
            totalRow.totalSpend += value;

            inboundLocationFields.push(locationHierarchy.toString());
            inboundLocationHierarchies.push(locationHierarchy);
            totalLocationFields.push(locationHierarchy.toString());
            totalLocationHierarchies.push(locationHierarchy);
        }, this);

        Ext.each(outboundDataRows, function(row) {
            var value = row.Outbound__Trans__Costs;
            var periodCode = row.Period;
            var outboundRow = outboundPeriodLookupMap[periodCode];
            var totalRow = totalPeriodLookupMap[periodCode];
            var locationCode = row.Location;
            var locationHierarchy = locationLookupMap[locationCode];

            if (!outboundRow) {
                this.logMissingHierarchy(periodCode);
                return;
            }

            if (!locationHierarchy) {
                this.logMissingHierarchy(locationCode);
                return;
            }

            outboundMinValue = Math.min(outboundMinValue, value);
            outboundMaxValue = Math.max(outboundMaxValue, value);

            outboundRow[locationHierarchy] = value;
            totalRow[locationHierarchy] = (totalRow[locationHierarchy] || 0) + value; // can't do += as this location may not exist yet
            totalRow.totalSpend += value;

            //The totalRow[locationHierarchy] is now aggregated, so we can check for min/max now.
            totalMinLocationValue = Math.min(totalMinLocationValue, totalRow[locationHierarchy]);
            totalMaxLocationValue = Math.max(totalMaxLocationValue, totalRow[locationHierarchy]);

            outboundLocationFields.push(locationHierarchy.toString());
            outboundLocationHierarchies.push(locationHierarchy);
            totalLocationFields.push(locationHierarchy.toString());
            totalLocationHierarchies.push(locationHierarchy);
        }, this);

        //Cannot check for min value until everything is aggregated.
        Ext.each(totalPeriodRows, function(row) {
            totalMinValue = Math.min(totalMinValue, row.totalSpend);
            totalMaxValue = Math.max(totalMaxValue, row.totalSpend);
        });

        this.setInboundStore(Ext.create('Ext.data.Store', {
            fields: Ext.Array.unique(inboundLocationFields).concat([ 'periodHierarchy' ]),
            data: inboundPeriodRows
        }));

        this.setOutboundStore(Ext.create('Ext.data.Store', {
            fields: Ext.Array.unique(outboundLocationFields).concat([ 'periodHierarchy' ]),
            data: outboundPeriodRows
        }));

        this.setTotalStore(Ext.create('Ext.data.Store', {
            fields: Ext.Array.unique(totalLocationFields).concat([ 'totalSpend', 'periodHierarchy' ]),
            data: totalPeriodRows
        }));

        var uniqueInboundLocationHierarchies = Ext.Array.unique(inboundLocationHierarchies);
        var sortedInboundLocationHierarchies = Ext.Array.sort(uniqueInboundLocationHierarchies);
        var uniqueOutboundLocationHierarchies = Ext.Array.unique(outboundLocationHierarchies);
        var sortedOutboundLocationHierarchies = Ext.Array.sort(uniqueInboundLocationHierarchies);
        var uniqueTotalLocationHierarchies = Ext.Array.unique(totalLocationHierarchies);
        var sortedTotalLocationHierarchies = Ext.Array.sort(uniqueTotalLocationHierarchies);

        this.setPeriodHierarchy(periodHierarchy);

        this.setInboundSpend(currentInboundSpend);
        this.setPriorInboundSpend(priorInboundSpend);
        this.setInboundBudgetSpend(inboundBudgetSpend);
        this.setInboundBudget(inboundBudget);
        this.setInboundMinimumValue(inboundMinValue);
        this.setInboundMaximumValue(inboundMaxValue);
        this.setInboundLocationHierarchies(sortedInboundLocationHierarchies);

        this.setOutboundSpend(currentOutboundSpend);
        this.setPriorOutboundSpend(priorOutboundSpend);
        this.setOutboundBudgetSpend(outboundBudgetSpend);
        this.setOutboundBudget(outboundBudget);
        this.setOutboundMinimumValue(outboundMinValue);
        this.setOutboundMaximumValue(outboundMaxValue);
        this.setOutboundLocationHierarchies(sortedOutboundLocationHierarchies);

        this.setTotalSpend(currentInboundSpend + currentOutboundSpend);
        this.setTotalBudgetSpend(inboundBudgetSpend + outboundBudgetSpend);
        this.setTotalBudget(inboundBudget + outboundBudget);
        this.setTotalMinimumValue(totalMinValue);
        this.setTotalMaximumValue(totalMaxValue);
        this.setTotalMinimumLocationValue(totalMinLocationValue);
        this.setTotalMaximumLocationValue(totalMaxLocationValue);
        this.setTotalLocationHierarchies(sortedTotalLocationHierarchies);
    },

    _getPeriodRows: function(parentPeriodHierarchy, periodRowLookupMap) {
        var rows = [];

        parentPeriodHierarchy.children().each(function(periodHierarchy) {
            var row = {
                date: periodHierarchy.get('value'),
                periodHierarchy: periodHierarchy,
                totalSpend: 0
            };

            // populate to use for quick lookups of row objects while processing the report rows
            periodRowLookupMap[row.date] = row;

            rows.push(row);
        });

        return rows;
    },

    _getLocationLookupMap: function(parentLocationHierarchy) {
        var locationLookupMap = {};

        parentLocationHierarchy.children().each(function(locationHierarchy) {
            locationLookupMap[locationHierarchy.get('code')] = locationHierarchy;
        });

        return locationLookupMap;
    }
});
