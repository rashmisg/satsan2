Ext.define('Jda.SCExecutive.model.OrderFill', {
    extend: 'Jda.SCExecutive.model.CognosReport',

    config: {
        reportName: 'IN_Order_Fill_Rate',
        reportFolder: 'Inventory',

        periodHierarchy: null,

        inboundPartyCount: null,
        inboundOrderFillValue: null,
        inboundOrderFillCount: null,
        inboundStore: null,
        inboundMaximumValue: null,
        inboundMaximumCount: null,
        outboundPartyCount: null,
        outboundOrderFillValue: null,
        outboundOrderFillCount: null,
        outboundStore: null,
        outboundMaximumValue: null,
        outboundMaximumCount: null
    },

    processResponse: function(config) {
        var inboundPartyCount = this.extractMetaDataValue('Inbound_Suppliers', 'Inbound__Suppliers');
        var inboundOrderFillValue = this.extractMetaDataValue('Total_Order_Value_Inbound', 'Total__Order__Value__Inbound');
        var inboundOrderFillCount = this.extractMetaDataValue('Total_Inbound_Orders', 'Total__Inbound__Orders');
        var inboundOrderValues = this.extractDataRows('Inbound_Order_Value', config.periodHierarchy, config.locationHierarchy);
        var inboundPeriodRowLookupMap = {};
        // If there isn't any inbound data don't create blank period records
        var inboundPeriodRows = inboundOrderValues ? this._getPeriodRows(config.periodHierarchy, inboundPeriodRowLookupMap) : undefined;
        var inboundMaximumValue = 0;
        var inboundMaximumCount = 0;
        var outboundPartyCount = this.extractMetaDataValue('Outbound_Customers', 'Outbound__Customers');
        var outboundOrderFillValue = this.extractMetaDataValue('Total_Order_Value_Outbound', 'Total__Order__Value__Outbound');
        var outboundOrderFillCount = this.extractMetaDataValue('Total_Outbound_Orders', 'Total__Outbound__Orders');
        var outboundOrderValues = this.extractDataRows('Outbound_Order_Value', config.periodHierarchy, config.locationHierarchy);
        var outboundPeriodRowLookupMap = {};
        // If there isn't any outbound data don't create blank period records
        var outboundPeriodRows = outboundOrderValues ? this._getPeriodRows(config.periodHierarchy, outboundPeriodRowLookupMap) : undefined;
        var outboundMaximumValue = 0;
        var outboundMaximumCount = 0;

        Ext.each(inboundOrderValues, function(row) {
            var periodCode = row.Period;
            var inboundPeriodRow = inboundPeriodRowLookupMap[periodCode];

            if (!inboundPeriodRow) {
                this.logMissingHierarchy(periodCode);
                return;
            }

            inboundPeriodRow.orderValue = row.Inbound__Order__Value;
            if (inboundPeriodRow.orderValue > inboundMaximumValue) {
                inboundMaximumValue = inboundPeriodRow.orderValue;
            }

            inboundPeriodRow.orderCount = row.Inbound__Orders;
            if (inboundPeriodRow.orderCount > inboundMaximumCount) {
                inboundMaximumCount = inboundPeriodRow.orderCount;
            }
        }, this);

        Ext.each(outboundOrderValues, function(row) {
            var periodCode = row.Period;
            var outboundPeriodRow = outboundPeriodRowLookupMap[periodCode];

            if (!outboundPeriodRow) {
                this.logMissingHierarchy(periodCode);
                return;
            }

            outboundPeriodRow.orderValue = row.Outbound__Order__Value;
            if (outboundPeriodRow.orderValue > outboundMaximumValue) {
                outboundMaximumValue = outboundPeriodRow.orderValue;
            }

            outboundPeriodRow.orderCount = row.Outbound__Orders;
            if (outboundPeriodRow.orderCount > outboundMaximumCount) {
                outboundMaximumCount = outboundPeriodRow.orderCount;
            }
        }, this);

        var inboundStore = Ext.create('Ext.data.Store', {
            fields: [ 'orderValue', 'periodHierarchy', 'orderCount' ],
            data: inboundPeriodRows
        });

        var outboundStore = Ext.create('Ext.data.Store', {
            fields: [ 'orderValue', 'periodHierarchy', 'orderCount' ],
            data: outboundPeriodRows
        });

        this.setPeriodHierarchy(config.periodHierarchy);
        this.setInboundPartyCount(inboundPartyCount);
        this.setInboundOrderFillValue(inboundOrderFillValue);
        this.setInboundOrderFillCount(inboundOrderFillCount);
        this.setInboundStore(inboundStore);
        this.setInboundMaximumValue(inboundMaximumValue);
        this.setInboundMaximumCount(inboundMaximumCount);
        this.setOutboundPartyCount(outboundPartyCount);
        this.setOutboundOrderFillValue(outboundOrderFillValue);
        this.setOutboundOrderFillCount(outboundOrderFillCount);
        this.setOutboundStore(outboundStore);
        this.setOutboundMaximumValue(outboundMaximumValue);
        this.setOutboundMaximumCount(outboundMaximumCount);
    },

    _getPeriodRows: function(parentPeriodHierarchy, periodRowLookupMap) {
        var rows = [];

        parentPeriodHierarchy.children().each(function(periodHierarchy) {
            var row = {
                date: periodHierarchy.get('value'),
                periodHierarchy: periodHierarchy,
                orderValue: 0,
                orderCount: 0
            };

            // populate to use for quick lookups of row objects while processing the report rows
            periodRowLookupMap[row.date] = row;

            rows.push(row);
        });

        return rows;
    }
});
