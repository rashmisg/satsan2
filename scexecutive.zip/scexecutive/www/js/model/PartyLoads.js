Ext.define('Jda.SCExecutive.model.PartyLoads', {
    extend: 'Jda.SCExecutive.model.CognosReport',

    config: {
        reportName: 'TR_Transportation_Activity_Totals',
        reportFolder: 'Transportation',

        inboundLoads: null,
        inboundAverageCost: null,
        inboundAverageValue: null,
        inboundParties: null,
        inboundCarriers: null,
        inboundSuppliers: null,

        outboundLoads: null,
        outboundAverageCost: null,
        outboundAverageValue: null,
        outboundParties: null,
        outboundCarriers: null,
        outboundCustomers: null,

        totalLoads: null,
        totalAverageCost: null,
        totalAverageValue: null,
        totalParties: null,
        totalCarriers: null,
        totalCustomers: null,
        totalSuppliers: null
    },

    processResponse: function(config) {
        var inboundLoads = this._extractNumberMetaDataValueDefaultingToZero('Loads_Inbound', 'Loads__Inbound');
        var inboundAverageCost = this._extractNumberMetaDataValueDefaultingToZero('Average_Cost_Inbound', 'Average__Cost__Inbound');
        var inboundAverageValue = this._extractNumberMetaDataValueDefaultingToZero('Average_Value_Inbound', 'Average__Value__Inbound');
        var inboundParties = this._extractNumberMetaDataValueDefaultingToZero('Parties_Inbound', 'Parties__Inbound');
        var inboundCarriers = this._extractNumberMetaDataValueDefaultingToZero('Carriers_Inbound', 'Carriers__Inbound');
        var inboundSuppliers = this._extractNumberMetaDataValueDefaultingToZero('Suppliers_Inbound', 'Suppliers__Inbound');

        var outboundLoads = this._extractNumberMetaDataValueDefaultingToZero('Loads_Outbound', 'Loads__Outbound');
        var outboundAverageCost = this._extractNumberMetaDataValueDefaultingToZero('Average_Cost_Outbound', 'Average__Cost__Outbound');
        var outboundAverageValue = this._extractNumberMetaDataValueDefaultingToZero('Average_Value_Outbound', 'Average__Value__Outbound');
        var outboundParties = this._extractNumberMetaDataValueDefaultingToZero('Parties_Outbound', 'Parties__Outbound');
        var outboundCarriers = this._extractNumberMetaDataValueDefaultingToZero('Carriers_Outbound', 'Carriers__Outbound');
        var outboundCustomers = this._extractNumberMetaDataValueDefaultingToZero('Customers_Outbound', 'Customers__Outbound');

        this.setInboundLoads(inboundLoads);
        this.setInboundAverageCost(inboundAverageCost);
        this.setInboundAverageValue(inboundAverageValue);
        this.setInboundParties(inboundParties);
        this.setInboundCarriers(inboundCarriers);
        this.setInboundSuppliers(inboundSuppliers);

        this.setOutboundLoads(outboundLoads);
        this.setOutboundAverageCost(outboundAverageCost);
        this.setOutboundAverageValue(outboundAverageValue);
        this.setOutboundParties(outboundParties);
        this.setOutboundCarriers(outboundCarriers);
        this.setOutboundCustomers(outboundCustomers);

        this.setTotalLoads(inboundLoads + outboundLoads);
        this.setTotalAverageCost(inboundAverageCost + outboundAverageCost);
        this.setTotalAverageValue(inboundAverageValue + outboundAverageValue);
        this.setTotalParties(inboundParties + outboundParties);
        this.setTotalCarriers(inboundCarriers + outboundCarriers);
        this.setTotalCustomers(outboundCustomers); // customers only exists for outbound
        this.setTotalSuppliers(inboundSuppliers); // suppliers only exists for inbound
    },

    _extractNumberMetaDataValueDefaultingToZero: function(dataTableIdPrefix, rowId) {
        var value = this.extractMetaDataValue(dataTableIdPrefix, rowId);

        return Ext.isNumber(value) ? value : 0;
    }
});
