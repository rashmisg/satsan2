Ext.define('Jda.SCExecutive.model.LocationHierarchy', {
    extend: 'Ext.data.Model',

    config: {
        color: null,
        fields: [ 'code', 'name', 'originalName', 'level', 'parent', 'isRoot' ],
        hasMany: {
            model: 'Jda.SCExecutive.model.LocationHierarchy',
            name: 'children',
            associationKey: 'children',
            store: {
                sorters: [ 'name' ]
            }
        }
    },

    getChildFromCode: function(code) {
        return this.children().findRecord('code', code);
    },

    getColor: function() {
        if (!this._color) {
            this._color = Jda.SCExecutive.constant.Colors.colorForLocationHierarchyAtIndex(this.get('parent').children().indexOf(this));
        }

        return this._color;
    },

    getViewingString: function() {
        if (this.get('isRoot')) {
            return Jda.getMessage('jda.scexecutive.locationhierarchy.ViewingAllRegions');
        }

        var parent = this.get('parent'),
            parentName = parent.get('name'),
            name = this.get('name');

        if (parent.get('isRoot')) {
            return Ext.String.format(Jda.getMessage('jda.scexecutive.locationhierarchy.ViewingParentRootFormat'), name);
        }

        return Ext.String.format(Jda.getMessage('jda.scexecutive.locationhierarchy.ViewingNonRootParentFormat'), parentName, name);
    },

    /**
     * Returns an XPath-style String representing the full location hierarchy
     * code path leading to this location (e.g. "USA/Midwest/WI").
     * @return {String}
     */
    getHierarchyPath: function() {
        var codes = [ this.get('code') ];
        var parent = this.get('parent');

        while (parent && !parent.get('isRoot')) {
            codes.unshift(parent.get('code'));

            parent = parent.get('parent');
        }

        return codes.join('/');
    },

    // Overriding toString so that we can pass LocationHierarchy objects into charts, which toString's objects when it's determining
    // the points on the graph. The default behavior of this would be [Object object], and only ever show one record.
    toString: function() {
        return this.get('code');
    }
});
