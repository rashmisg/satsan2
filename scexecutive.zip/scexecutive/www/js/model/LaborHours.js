Ext.define('Jda.SCExecutive.model.LaborHours', {
    extend: 'Jda.SCExecutive.model.CognosReport',

    config: {
        reportName: 'LA_Labor_Hours',
        reportFolder: 'Labor',

        store: null,
        periodHierarchy: null,

        priorTotalRegularHours: null,
        totalRegularHours: null,
        priorTotalOvertimeHours: null,
        totalOvertimeHours: null,

        totalCombinedHours: null,
        lowestValue: null,
        highestValue: null
    },

    processResponse: function(config) {
        var regularHours = this.extractMetaDataValue('Regular_Hours', 'Regular__Hours');
        var priorRegularHours = this.extractMetaDataValue('Prior_Regular_Hours', 'Prior__Regular__Hours', config.periodHierarchy);
        var overtimeHours = this.extractMetaDataValue('Overtime_Hours', 'Overtime__Hours');
        var priorOvertimeHours = this.extractMetaDataValue('Prior_Overtime_Hours', 'Prior__Overtime__Hours', config.periodHierarchy);
        var laborHourRows = this.extractDataRows('Labor_Hours', config.periodHierarchy, config.locationHierarchy);
        var locationLookupMap = {};
        var locationRows = laborHourRows ? this._getLocationRows(config.locationHierarchy, locationLookupMap) : undefined;
        var hasPreviousPeriodHierarchy = config.periodHierarchy.get('hasPrevious');

        var lowestValue = Number.MAX_VALUE;
        var highestValue = Number.MIN_VALUE;
        Ext.each(laborHourRows, function(laborHourRow) {
            var locationCode = laborHourRow.Location;
            var locationRow = locationLookupMap[locationCode];

            if (!locationRow) {
                this.logMissingHierarchy(locationCode);
                return;
            }

            locationRow.hours = laborHourRow.Labor__Hours;
            locationRow.overtimeHours = laborHourRow.OT__Hours;
            locationRow.totalHours = laborHourRow.Labor__Hours + laborHourRow.OT__Hours;

            var priorLaborHours = laborHourRow.Prior__Labor__Hours;
            var priorOvertimeHours = laborHourRow.Prior__OT__Hours;

            // If you have a previous period hierarchy, and at least one of the prior items is not null,
            // you can add them together. The addition of null and any number will be that number.
            if (hasPreviousPeriodHierarchy && (!Ext.isEmpty(priorLaborHours) || !Ext.isEmpty(priorOvertimeHours))) {
                locationRow.priorTotalHours = priorLaborHours + priorOvertimeHours;

                var isTrendingUp = locationRow.totalHours >= locationRow.priorTotalHours;
                var trend = isTrendingUp ? Jda.SCExecutive.component.TrendIndicator.TREND_UP : Jda.SCExecutive.component.TrendIndicator.TREND_DOWN;
                locationRow.totalHoursTrend = trend;
            }
            // Otherwise, use just set the trend to 'unknown'
            else {
                console.warn('No prior labor hour data for location.');
                locationRow.totalHoursTrend = Jda.SCExecutive.component.TrendIndicator.TREND_UNKNOWN;
            }

            locationRow.spend = laborHourRow.Labor__Spend;
            locationRow.overtimeSpend = laborHourRow.OT__Spend;

            locationRow.periodHierarchy = config.periodHierarchy;

            lowestValue = Math.min(lowestValue, laborHourRow.Labor__Hours);
            lowestValue = Math.min(lowestValue, laborHourRow.OT__Hours);

            highestValue = Math.max(highestValue, laborHourRow.Labor__Hours);
            highestValue = Math.max(highestValue, laborHourRow.OT__Hours);
        }, this);

        var laborHoursStore = Ext.create('Ext.data.Store', {
            fields: [ 'color', 'locationName', 'locationHierarchy', 'periodHierarchy', 'hours', 'overtimeHours', 'totalHours', 'priorTotalHours', 'totalHoursTrend', 'spend', 'overtimeSpend' ],
            sorters:[
                Jda.SCExecutive.util.Sorters.DisplayValueSorter.createSorter({
                    direction: 'DESC',
                    field: 'hours'
                }),
                {
                    property: 'locationHierarchy',
                    direction: 'ASC'
                }
            ],
            data: locationRows
        });

        this.setPeriodHierarchy(config.periodHierarchy);
        this.setStore(laborHoursStore);

        this.setPriorTotalRegularHours(priorRegularHours);
        this.setTotalRegularHours(regularHours);
        this.setPriorTotalOvertimeHours(priorOvertimeHours);
        this.setTotalOvertimeHours(overtimeHours);
        
        this.setTotalCombinedHours(regularHours + overtimeHours);
        this.setLowestValue(lowestValue);
        this.setHighestValue(highestValue);
    },

    _getLocationRows: function(parentLocationHierarchy, locationLookupMap) {
        var rows = [];

        parentLocationHierarchy.children().each(function(locationHierarchy) {
            var row = {
                locationHierarchy: locationHierarchy,
                locationName: locationHierarchy.get('name'),
                color: locationHierarchy.getColor()
            };

            // populate to use for quick lookups of row objects while processing the report rows
            locationLookupMap[locationHierarchy.get('code')] = row;

            rows.push(row);
        });

        return rows;
    }
});
