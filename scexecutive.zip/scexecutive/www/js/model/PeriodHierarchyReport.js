Ext.define('Jda.SCExecutive.model.PeriodHierarchyReport', {
    extend: 'Jda.SCExecutive.model.CognosReport',

    config: {
        reportName: 'Period_Hierarchy',
        reportFolder: 'Hierarchy',
        reportRoot: "metadataXml/rds/outputFormat/searchPath/content/folder[@name='JDABA']/folder[@name='Template%20Reports']/folder[@name='SCExec%20Analytics%208.2']/folder[@name='Interface']",

        rootPeriodHierarchy: null,

        periodGroups: null
    },

    getBeanPath: function() {
        return Ext.String.format("{0}/folder[@name='{1}']/report[@name='{2}']/XML", this.getReportRoot(), this.getReportFolder(), this.getReportName());
    },

    getBaseParams: function() {
        return { version: 'LATEST' };
    },

    processResponse: function() {
        var periodRows = this.extractDataRows('Period_Hierarchy');
        var rootPeriodHierarchy = Ext.create('Jda.SCExecutive.model.PeriodHierarchy', { name: 'root', level: 'root', isRoot: true });
        var today = Ext.Date.clearTime(Jda.mobility.core.Sundial.now());
        var todaysTime = today.getTime();
        var previousYearRecord, previousQuarterRecord, previousMonthRecord, previousWeekRecord, previousDateRecord;
        var periodGroups = { };
        var yearLookupMap = { };
        var quarterLookupMap = { };
        var monthLookupMap = { };
        var weekLookupMap = { };

        Ext.each(Jda.SCExecutive.model.PeriodHierarchy.typesList, function(type) {
            periodGroups[type] = [];
        });

        Ext.each(periodRows, function(periodRow) {
            var year = periodRow.Year,
                quarter = periodRow.Quarter,
                month = periodRow.Month,
                week = periodRow.Week,
                date = periodRow.Date;

            // If this Year record hasn't been created yet, do so.
            var yearRecord = yearLookupMap[year];
            if (!yearRecord) {
                yearRecord = Ext.create('Jda.SCExecutive.model.PeriodHierarchy', {
                    value: year,
                    type: Jda.SCExecutive.model.PeriodHierarchy.types.YEAR,
                    start: Jda.mobility.i18n.Date.parse(periodRow.Year__Start__DT, Jda.mobility.i18n.Date.ISO8601),
                    end: Jda.mobility.i18n.Date.parse(periodRow.Year__End__DT, Jda.mobility.i18n.Date.ISO8601),
                    parent: rootPeriodHierarchy,
                    hasPrevious: true
                });

                // Set up sibling years
                if (previousYearRecord) {
                    previousYearRecord.setNext(yearRecord);
                    yearRecord.setPrevious(previousYearRecord);
                }
                else {
                    yearRecord.set('hasPrevious', false);
                }

                if (todaysTime >= yearRecord.get('end').getTime()) {
                    periodGroups[Jda.SCExecutive.model.PeriodHierarchy.types.YEAR].push(yearRecord);
                }

                previousYearRecord = yearRecord;

                // Add to root
                rootPeriodHierarchy.children().add(yearRecord);

                // Save for lookup
                yearLookupMap[year] = yearRecord;
            }

            // If this Quarter record hasn't been created yet, do so.
            var quarterRecord = quarterLookupMap[quarter];
            if (!quarterRecord) {
                quarterRecord = Ext.create('Jda.SCExecutive.model.PeriodHierarchy', {
                    value: quarter,
                    type: Jda.SCExecutive.model.PeriodHierarchy.types.QUARTER,
                    parent: yearRecord,
                    start: Jda.mobility.i18n.Date.parse(periodRow.Quarter__Start__DT, Jda.mobility.i18n.Date.ISO8601),
                    end: Jda.mobility.i18n.Date.parse(periodRow.Quarter__End__DT, Jda.mobility.i18n.Date.ISO8601),
                    hasPrevious: true
                });

                // Set up sibling quarters
                if (previousQuarterRecord) {
                    previousQuarterRecord.setNext(quarterRecord);
                    quarterRecord.setPrevious(previousQuarterRecord);
                }
                else {
                    quarterRecord.set('hasPrevious', false);
                }

                if (todaysTime >= quarterRecord.get('end').getTime()) {
                    periodGroups[Jda.SCExecutive.model.PeriodHierarchy.types.QUARTER].push(quarterRecord);
                }

                previousQuarterRecord = quarterRecord;

                // Add to year
                yearRecord.children().add(quarterRecord);

                // Save for lookup
                quarterLookupMap[quarter] = quarterRecord;
            }

            // If this Month record hasn't been created yet, do so.
            var monthRecord = monthLookupMap[month];
            if (!monthRecord) {
                var monthNumber = parseInt(month.split('M')[1], 10);
                monthRecord = Ext.create('Jda.SCExecutive.model.PeriodHierarchy', {
                    value: month,
                    fiscalCount: monthNumber,
                    type: Jda.SCExecutive.model.PeriodHierarchy.types.MONTH,
                    parent: quarterRecord,
                    start: Jda.mobility.i18n.Date.parse(periodRow.Month__Start__DT, Jda.mobility.i18n.Date.ISO8601),
                    end: Jda.mobility.i18n.Date.parse(periodRow.Month__End__DT, Jda.mobility.i18n.Date.ISO8601),
                    hasPrevious: true
                });

                // Set up sibling months
                if (previousMonthRecord) {
                    previousMonthRecord.setNext(monthRecord);
                    monthRecord.setPrevious(previousMonthRecord);
                }
                else {
                    monthRecord.set('hasPrevious', false);
                }

                if (todaysTime >= monthRecord.get('end').getTime()) {
                    periodGroups[Jda.SCExecutive.model.PeriodHierarchy.types.MONTH].push(monthRecord);
                }

                previousMonthRecord = monthRecord;

                // Add to quarter
                quarterRecord.children().add(monthRecord);

                // Save for lookup
                monthLookupMap[month] = monthRecord;
            }

            // If this Week record hasn't been created yet, do so.
            var weekRecord = monthRecord.children().findRecord('value', week);
            if (!weekRecord) {
                var weekNumber = parseInt(week.split('W')[1], 10);
                weekRecord = Ext.create('Jda.SCExecutive.model.PeriodHierarchy', {
                    value: week,
                    fiscalCount: weekNumber,
                    type: Jda.SCExecutive.model.PeriodHierarchy.types.WEEK,
                    parent: monthRecord,
                    start: Jda.mobility.i18n.Date.parse(periodRow.Week__Start__DT, Jda.mobility.i18n.Date.ISO8601),
                    end: Jda.mobility.i18n.Date.parse(periodRow.Week__End__DT, Jda.mobility.i18n.Date.ISO8601),
                    hasPrevious: true
                });

                // Set up sibling weeks
                if (previousWeekRecord) {
                    previousWeekRecord.setNext(weekRecord);
                    weekRecord.setPrevious(previousWeekRecord);
                }
                else {
                    weekRecord.set('hasPrevious', false);
                }

                if (todaysTime >= weekRecord.get('end').getTime()) {
                    periodGroups[Jda.SCExecutive.model.PeriodHierarchy.types.WEEK].push(weekRecord);
                }

                previousWeekRecord = weekRecord;

                // Add to month
                monthRecord.children().add(weekRecord);

                // Save for lookup
                weekLookupMap[week] = weekRecord;
            }

            var dateRecord = Ext.create('Jda.SCExecutive.model.PeriodHierarchy', {
                value: date,
                type: Jda.SCExecutive.model.PeriodHierarchy.types.DATE,
                parent: weekRecord,
                start: Jda.mobility.i18n.Date.parse(date, Jda.mobility.i18n.Date.ISO8601),
                end: Jda.mobility.i18n.Date.parse(date, Jda.mobility.i18n.Date.ISO8601),
                hasPrevious: true
            });

            // Set up sibling dates
            if (previousDateRecord) {
                previousDateRecord.setNext(dateRecord);
                dateRecord.setPrevious(previousDateRecord);
            }
            else {
                dateRecord.set('hasPrevious', false);
            }

            previousDateRecord = dateRecord;

            // Add to week
            weekRecord.children().add(dateRecord);
        }, this);

        this.setRootPeriodHierarchy(rootPeriodHierarchy);

        Ext.each(Jda.SCExecutive.model.PeriodHierarchy.typesList, function(type, index) {
            periodGroups[type].sort(function(a, b) {
                return b.get('start').getTime() - a.get('start').getTime();
            });

            periodGroups[index] = periodGroups[type];
        });

        // In demo mode, we limit the number of periods displayed for each group
        var pageContext = Jda.mobility.plugins.PageContextManager.getLastPageContext();
        if (pageContext.isDemoMode) {
            var types = Jda.SCExecutive.model.PeriodHierarchy.types;
            var NUM_WEEKS_FOR_DEMO = 4;
            var NUM_MONTHS_FOR_DEMO = 3;
            var NUM_QUARTERS_FOR_DEMO = 4;
            var NUM_YEARS_FOR_DEMO = 1;

            periodGroups[types.YEAR] = periodGroups[types.YEAR].slice(0, NUM_YEARS_FOR_DEMO);
            periodGroups[types.QUARTER] = periodGroups[types.QUARTER].slice(0, NUM_QUARTERS_FOR_DEMO);
            periodGroups[types.MONTH] = periodGroups[types.MONTH].slice(0, NUM_MONTHS_FOR_DEMO);
            periodGroups[types.WEEK] = periodGroups[types.WEEK].slice(0, NUM_WEEKS_FOR_DEMO);
        }

        this.setPeriodGroups(periodGroups);
    }
});
