Ext.define('Jda.SCExecutive.model.CustomerServicePerformance', {
    extend: 'Jda.SCExecutive.model.CognosReport',

    config: {
        reportName: 'CS_Customer_Service_Performance',
        reportFolder: 'Customer%20Service',

        store: null,
        locationHierarchies: null,
        periodHierarchy: null,
        lowestValue: null,
        highestValue: null,
        customerServiceLevelTargetPercent: null,

        priorAverageCustomerServiceLevelPercent: null,
        averageCustomerServiceLevelPercent: null,
        ordersFilledValue: null,
        priorOrdersFilledValue: null,

        customersCount: null,
        loadsCount: null
    },

    // Good if no target is defined, or average is greater than or equal to target
    isCustomerServiceLevelGood: function() {
        var actual = this.getAverageCustomerServiceLevelPercent();
        var target = this.getCustomerServiceLevelTargetPercent();

        return target === undefined || actual >= target;
    },

    processResponse: function(config) {
        var overallAverage = this.extractMetaDataValue('Avg_Cust_Service_Performance_Pct', 'Avg__Cust__Service__Performance__Pct');
        var priorOverallAverage = this.extractMetaDataValue('Prior_Avg_Cust_Service_Performance_Pct', 'Prior__Avg__Cust__Service__Performance__Pct', config.periodHierarchy);
        var orderFilledValue = this.extractMetaDataValue('Orders_Filled', 'Orders__Filled');
        var priorOrderFilledValue = this.extractMetaDataValue('Prior_Orders_Filled', 'Prior__Orders__Filled', config.periodHierarchy);
        var customerCount = this.extractMetaDataValue('Customers_Served', 'Customers__Served');
        var loadCount = this.extractMetaDataValue('Loads_Delivered', 'Loads__Delivered');
        var performancePercentRows = this.extractDataRows('Cust_Service_Performance_Pct', config.periodHierarchy, config.locationHierarchy);
        var trendRows = this.extractDataRows('Cust_Service_Trend_Pct', config.periodHierarchy, config.locationHierarchy);
        var targetPercent = this.extractMetaDataValue('Cust_Service_Performance_Target_Pct', 'Cust__Service__Performance__Target__Pct', config.periodHierarchy);
        var locationHierarchyLookupMap = this._getLocationHierarchyMap(config.locationHierarchy);
        var locationHierarchies = [];

        var periodRowLookupMap = {};
        var lowestValue = Number.MAX_VALUE;
        var highestValue = Number.MIN_VALUE;
        var locationMap = {};
        var data = performancePercentRows || trendRows ? this._getBaselineRows(config.periodHierarchy, targetPercent, periodRowLookupMap) : undefined;

        Ext.each(performancePercentRows, function(row, index) {
            var value = row.Cust__Service__Performance__Pct;
            var periodCode = row.Period;
            var periodRow = periodRowLookupMap[periodCode];
            var locationCode = row.Location;
            var locationHierarchy = locationHierarchyLookupMap[locationCode];

            if (!periodRow) {
                this.logMissingHierarchy(periodCode);
                return;
            }

            if (!locationHierarchy) {
                this.logMissingHierarchy(locationCode);
                return;
            }

            periodRow[locationHierarchy] = value;
            lowestValue = Math.min(lowestValue, value);
            highestValue = Math.max(highestValue, value);

            // using this effectively as a set collection, it contains the location codes encountered in the reports data
            locationMap[locationHierarchy] = true;
            locationHierarchies.push(locationHierarchy);
        }, this);

        Ext.each(trendRows, function(trend, index) {
            var value = trend.Cust__Service__Trend__Pct;
            var periodCode = trend.Period;
            var periodRow = periodRowLookupMap[periodCode];

            if (!periodRow) {
                this.logMissingHierarchy(periodCode);
                return;
            }

            periodRow.average = value;
        }, this);

        var locationFields = Ext.Object.getKeys(locationMap);

        // Check for the case that the target value is lower than the lowest observed value
        if (targetPercent !== undefined) {
            lowestValue = Math.min(lowestValue, targetPercent);
            highestValue = Math.max(highestValue, targetPercent);
        }

        this.setStore(Ext.create('Ext.data.Store', {
            fields: locationFields.concat('average', 'targetPercent', 'periodHierarchy', 'contextPeriodHierarchy'),
            data: data
        }));

        this.setLocationHierarchies(Ext.Array.unique(locationHierarchies));
        this.setPeriodHierarchy(config.periodHierarchy);
        this.setLowestValue(lowestValue);
        this.setHighestValue(highestValue);
        this.setCustomerServiceLevelTargetPercent(targetPercent);

        this.setPriorAverageCustomerServiceLevelPercent(priorOverallAverage);
        this.setAverageCustomerServiceLevelPercent(overallAverage);
        this.setPriorOrdersFilledValue(priorOrderFilledValue);
        this.setOrdersFilledValue(orderFilledValue);

        this.setCustomersCount(customerCount);
        this.setLoadsCount(loadCount);
    },

    _getBaselineRows: function(parentPeriodHierarchy, targetPercent, periodRowLookupMap) {
        var rows = [];
        var type = parentPeriodHierarchy.get('type');
        var types = Jda.SCExecutive.model.PeriodHierarchy.types;

        var addRowObject = function(periodHierarchy) {
            var row = {
                date: periodHierarchy.get('value'),
                periodHierarchy: periodHierarchy,
                targetPercent: targetPercent,
                contextPeriodHierarchy: parentPeriodHierarchy
            };

            // populate to use for quick lookups of row objects while processing the report rows
            periodRowLookupMap[row.date] = row;

            rows.push(row);
        };

        // week + month show direct children, quarter + year show grandchildren
        if (type === types.WEEK || type === types.MONTH) {
            parentPeriodHierarchy.children().each(addRowObject);
        }
        else if (type == types.QUARTER || type === types.YEAR) {
            parentPeriodHierarchy.children().each(function(child) {
                child.children().each(addRowObject);
            });
        }

        return rows;
    },

    _getLocationHierarchyMap: function(parentLocationHierarchy) {
        var locationLookupMap = {};

        parentLocationHierarchy.children().each(function(locationHierarchy) {
            locationLookupMap[locationHierarchy.get('code')] = locationHierarchy;
        });

        return locationLookupMap;
    }
});
