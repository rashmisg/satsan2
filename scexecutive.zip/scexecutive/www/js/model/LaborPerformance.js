Ext.define('Jda.SCExecutive.model.LaborPerformance', {
    extend: 'Jda.SCExecutive.model.CognosReport',

    config: {
        reportName: 'LA_Labor_Performance',
        reportFolder: 'Labor',

        periodHierarchy: null,
        colors: null,
        directPerformanceDetailsStore: null,
        totalPerformanceDetailsStore: null,
        totalHours: null,
        totalDirectHours: null,
        totalIndirectHours: null,

        priorTotalPerformance: null,
        totalPerformance: null,
        priorTotalEfficiency: null,
        totalEfficiency: null
    },

    processResponse: function(config) {
        var totalHours = this.extractMetaDataValue('Total_Labor_Hours','Total__Labor__Hours');
        var totalPerformance = this.extractMetaDataValue('Labor_Performance','Labor__Performance');
        var priorPerformance = this.extractMetaDataValue('Prior_Labor_Performance','Prior__Labor__Performance', config.periodHierarchy);
        var totalEfficiency = this.extractMetaDataValue('Labor_Efficiency','Labor__Efficiency');
        var priorEfficiency = this.extractMetaDataValue('Prior_Labor_Efficiency','Prior__Labor__Efficiency', config.periodHierarchy);
        var totalIndirectHours = this.extractMetaDataValue('Indirect_Labor_Hours', 'Indirect__Labor__Hours');
        var totalDirectHours = 0;
        var directHourCategoryRows = this.extractDataRows('Direct_Hours', config.periodHierarchy, config.locationHierarchy);
        var directHourObjs = [];

        Ext.each(directHourCategoryRows, function(directHourCategoryRow) {
            var massagedDirectHourObj = {
                category: directHourCategoryRow.Work__Category,
                hours: directHourCategoryRow.Direct__Hours,
                unitsPerHour: directHourCategoryRow.Units__Per__Hour,
                performance: directHourCategoryRow.Performance
            };

            totalDirectHours += massagedDirectHourObj.hours;
            directHourObjs.push(massagedDirectHourObj);
        });

        // Sort by # hours descending and then category ascending.
        Ext.Array.sort(directHourObjs, function(a, b) {
            if (b.hours === a.hours) {
                return a.category.localeCompare(b.category); //ASC Name sort
            }
            return b.hours - a.hours; //DESC Hour sort
        });

        // Add the colors to each of the object, starting with the highest # of hours
        // being pure blue, then assigning each after at 75% of the previous blue.
        var colors = [];
        var nextColor = Jda.SCExecutive.constant.Colors.chartSeriesPrimaryColor;
        Ext.Array.each(directHourObjs, function(directHourObj) {
            directHourObj.color = nextColor;

            colors.push(nextColor);

            nextColor = this._lightenColor(nextColor);
        }, this);

        // Add our gray as the final color
        colors.push(Jda.SCExecutive.constant.Colors.chartSeriesSecondaryColor);

        // Create the direct hours store used for the grid. Note that it doesn't include indirect work.
        var directHoursStore = Ext.create('Ext.data.Store', {
            fields: [ 'category', 'hours', 'unitsPerHour', 'performance' ],
            data: directHourObjs
        });

        // Create the total hours store used for the chart. It is a clone of the direct hours, and adds the indirect work object as well.
        var totalHourObjs = Ext.Array.clone(directHourObjs);
        totalHourObjs.push({
            category: Jda.getMessage('jda.scexecutive.laborperformance.IndirectWork'),
            hours: totalIndirectHours,
            color: Jda.SCExecutive.constant.Colors.chartSeriesSecondaryColor
        });

        var totalHoursStore = Ext.create('Ext.data.Store', {
            fields: [ 'category', 'hours', 'color' ],
            data: totalHourObjs
        });

        this.setPeriodHierarchy(config.periodHierarchy);
        this.setColors(colors);
        this.setTotalHours(totalHours);
        this.setTotalDirectHours(totalDirectHours);
        this.setTotalIndirectHours(totalIndirectHours);

        this.setPriorTotalPerformance(priorPerformance);
        this.setTotalPerformance(totalPerformance);
        this.setPriorTotalEfficiency(priorEfficiency);
        this.setTotalEfficiency(totalEfficiency);

        this.setTotalPerformanceDetailsStore(totalHoursStore);
        this.setDirectPerformanceDetailsStore(directHoursStore);
    },

    // Taken from http://stackoverflow.com/a/13542669/1252541
    _lightenColor: function(color) {
        var f = parseInt(color.slice(1), 16);
        var t = 255;
        var p = 0.25;
        var R = f >> 16;
        var G = f >> 8 & 0x00FF;
        var B = f & 0x0000FF;

        return '#' + (0x1000000 + (Math.round((t - R) * p) + R) * 0x10000 + (Math.round((t - G) * p) + G) * 0x100 + (Math.round((t - B) * p) + B)).toString(16).slice(1);
    }
});
