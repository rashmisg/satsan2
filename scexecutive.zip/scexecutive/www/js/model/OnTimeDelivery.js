Ext.define('Jda.SCExecutive.model.OnTimeDelivery', {
     extend: 'Jda.SCExecutive.model.CognosReport',

    config: {
        reportName: 'TR_Transportation_Delivery_Performance',
        reportFolder: 'Transportation',

        periodHierarchy: null,

        inboundOnTimePercent: null,
        inboundOnTimeTarget: null,
        inboundLocationHierarchies: null,
        inboundStore: null,
        inboundLowestValue: null,
        inboundHighestValue: null,

        outboundOnTimePercent: null,
        outboundOnTimeTarget: null,
        outboundLocationHierarchies: null,
        outboundStore: null,
        outboundLowestValue: null,
        outboundHighestValue: null,

        totalOnTimePercent: null,
        totalOnTimeTarget: null,
        totalLocationHierarchies: null,
        totalStore: null,
        totalLowestValue: null,
        totalHighestValue: null
    },

    processResponse: function(config) {
        var locationHierarchyLookupMap = this._getLocationHierarchyMap(config.locationHierarchy);

        var inboundOnTimeTarget = this.extractMetaDataValue('Avg_On_Time_Delivery_Target_Pct_Inbound', 'Avg__On__Time__Delivery__Target__Pct__Inbound', config.periodHierarchy);
        var inboundOnTimePercent = this.extractMetaDataValue('Avg_On_Time_Delivery_Pct_Inbound', 'Avg__On__Time__Delivery__Pct__Inbound');
        var inboundOnTimeRows = this.extractDataRows('On_Time_Delivery_Pct_Inbound', config.periodHierarchy, config.locationHierarchy);
        var inboundRowLookupMap = {};
        var inboundDateRows = inboundOnTimeRows ? this._createDateRowsObject(config.periodHierarchy, inboundOnTimeTarget, inboundRowLookupMap) : undefined;
        var inboundLocationFieldObject = {};
        var inboundLocationHierarchies = [];
        var inboundLowValue = Number.MAX_VALUE;
        var inboundHighValue = Number.MIN_VALUE;

        var outboundOnTimeTarget = this.extractMetaDataValue('Avg_On_Time_Delivery_Target_Pct_Outbound', 'Avg__On__Time__Delivery__Target__Pct__Outbound', config.periodHierarchy);
        var outboundOnTimePercent = this.extractMetaDataValue('Avg_On_Time_Delivery_Pct_Outbound', 'Avg__On__Time__Delivery__Pct__Outbound');
        var outboundOnTimeRows = this.extractDataRows('On_Time_Delivery_Pct_Outbound', config.periodHierarchy, config.locationHierarchy);
        var outboundRowLookupMap = {};
        var outboundDateRows = outboundOnTimeRows ? this._createDateRowsObject(config.periodHierarchy, outboundOnTimeTarget, outboundRowLookupMap) : undefined;
        var outboundLocationFieldObject = {};
        var outboundLocationHierarchies = [];
        var outboundLowValue = Number.MAX_VALUE;
        var outboundHighValue = Number.MIN_VALUE;

        var totalOnTimeTarget = this.extractMetaDataValue('Avg_On_Time_Delivery_Target_Pct_Total', 'Avg__On__Time__Delivery__Target__Pct__Total', config.periodHierarchy);
        var totalOnTimePercent = this.extractMetaDataValue('Avg_On_Time_Delivery_Pct_Total', 'Avg__On__Time__Delivery__Pct__Total');
        var totalOnTimeRows = this.extractDataRows('On_Time_Delivery_Pct_Total', config.periodHierarchy, config.locationHierarchy);
        var totalRowLookupMap = {};
        var totalDateRows = totalOnTimeRows ? this._createDateRowsObject(config.periodHierarchy, totalOnTimeTarget, totalRowLookupMap) : undefined;
        var totalLocationFieldObject = {};
        var totalLocationHierarchies = [];
        var totalLowValue = Number.MAX_VALUE;
        var totalHighValue = Number.MIN_VALUE;

        Ext.each(inboundOnTimeRows, function(inboundOnTimeRow) {
            var inboundPeriodCode = inboundOnTimeRow.Period;
            var inboundDateRow = inboundRowLookupMap[inboundPeriodCode];
            var locationCode = inboundOnTimeRow.Location;
            var locationHierarchy = locationHierarchyLookupMap[locationCode];
            var percentage = inboundOnTimeRow.On__Time__Delivery__Pct__Inbound;

            if (!inboundDateRow) {
                this.logMissingHierarchy(inboundPeriodCode);
                return;
            }

            if (!locationHierarchy) {
                this.logMissingHierarchy(locationCode);
                return;
            }

            inboundLowValue = Math.min(inboundLowValue, percentage);
            inboundHighValue = Math.max(inboundHighValue, percentage);

            inboundDateRow[locationHierarchy] = percentage;
            inboundLocationFieldObject[locationHierarchy] = true;
            inboundLocationHierarchies.push(locationHierarchy);
        }, this);

        Ext.each(outboundOnTimeRows, function(outboundOnTimeRow) {
            var outboundPeriodCode = outboundOnTimeRow.Period;
            var outboundDateRow = outboundRowLookupMap[outboundPeriodCode];
            var locationCode = outboundOnTimeRow.Location;
            var locationHierarchy = locationHierarchyLookupMap[locationCode];
            var percentage = outboundOnTimeRow.On__Time__Delivery__Pct__Outbound;

            if (!outboundDateRow) {
                this.logMissingHierarchy(outboundPeriodCode);
                return;
            }

            if (!locationHierarchy) {
                this.logMissingHierarchy(locationCode);
                return;
            }

            outboundLowValue = Math.min(outboundLowValue, percentage);
            outboundHighValue = Math.max(outboundHighValue, percentage);

            outboundDateRow[locationHierarchy] = percentage;
            outboundLocationFieldObject[locationHierarchy] = true;
            outboundLocationHierarchies.push(locationHierarchy);
        }, this);

        Ext.each(totalOnTimeRows, function(totalOnTimeRow) {
            var totalPeriodCode = totalOnTimeRow.Period;
            var totalDateRow = totalRowLookupMap[totalPeriodCode];
            var locationCode = totalOnTimeRow.Location;
            var locationHierarchy = locationHierarchyLookupMap[locationCode];
            var percentage = totalOnTimeRow.On__Time__Delivery__Pct__Total;

            if (!totalDateRow) {
                this.logMissingHierarchy(totalPeriodCode);
                return;
            }

            if (!locationHierarchy) {
                this.logMissingHierarchy(locationCode);
                return;
            }

            totalLowValue = Math.min(totalLowValue, percentage);
            totalHighValue = Math.max(totalHighValue, percentage);

            totalDateRow[locationHierarchy] = percentage;
            totalLocationFieldObject[locationHierarchy] = true;
            totalLocationHierarchies.push(locationHierarchy);
        }, this);

        var inboundLocationFields = Ext.Object.getKeys(inboundLocationFieldObject);
        var inboundStore = Ext.create('Ext.data.Store', {
            fields: inboundLocationFields.concat([ 'periodHierarchy', 'target' ]),
            data: inboundDateRows
        });

        var outboundLocationFields = Ext.Object.getKeys(outboundLocationFieldObject);
        var outboundStore = Ext.create('Ext.data.Store', {
            fields: outboundLocationFields.concat([ 'periodHierarchy', 'target' ]),
            data: outboundDateRows
        });

        var totalLocationFields = Ext.Object.getKeys(totalLocationFieldObject);
        var totalStore = Ext.create('Ext.data.Store', {
            fields: totalLocationFields.concat([ 'periodHierarchy', 'target' ]),
            data: totalDateRows
        });

        var uniqueInboundLocationHierarchies = Ext.Array.unique(inboundLocationHierarchies);
        var sortedInboundLocationHierarchies = Ext.Array.sort(uniqueInboundLocationHierarchies);
        var uniqueOutboundLocationHierarchies = Ext.Array.unique(outboundLocationHierarchies);
        var sortedOutboundLocationHierarchies = Ext.Array.sort(uniqueInboundLocationHierarchies);
        var uniqueTotalLocationHierarchies = Ext.Array.unique(totalLocationHierarchies);
        var sortedTotalLocationHierarchies = Ext.Array.sort(uniqueTotalLocationHierarchies);

        this.setPeriodHierarchy(config.periodHierarchy);
        this.setInboundOnTimePercent(inboundOnTimePercent);
        this.setInboundOnTimeTarget(inboundOnTimeTarget);
        this.setInboundLocationHierarchies(sortedInboundLocationHierarchies);
        this.setInboundStore(inboundStore);
        this.setInboundLowestValue(inboundLowValue);
        this.setInboundHighestValue(inboundHighValue);

        this.setOutboundOnTimePercent(outboundOnTimePercent);
        this.setOutboundOnTimeTarget(outboundOnTimeTarget);
        this.setOutboundLocationHierarchies(sortedOutboundLocationHierarchies);
        this.setOutboundStore(outboundStore);
        this.setOutboundLowestValue(outboundLowValue);
        this.setOutboundHighestValue(outboundHighValue);

        this.setTotalOnTimePercent(totalOnTimePercent);
        this.setTotalOnTimeTarget(totalOnTimeTarget);
        this.setTotalLocationHierarchies(sortedTotalLocationHierarchies);
        this.setTotalStore(totalStore);
        this.setTotalLowestValue(totalLowValue);
        this.setTotalHighestValue(totalHighValue);
    },

    _createDateRowsObject: function(periodHierarchy, target, periodLookupMap) {
        var dateRows = [];
        var periodType = periodHierarchy.get('type');

        periodHierarchy.children().each(function(firstLevelChild) {
            var value = firstLevelChild.get('value');
            var row = {
                date: value,
                target: target,
                periodHierarchy: firstLevelChild
            };

            dateRows.push(row);
            periodLookupMap[value] = row;
        });

        return dateRows;
    },

    _getLocationHierarchyMap: function(parentLocationHierarchy) {
        var locationLookupMap = {};

        parentLocationHierarchy.children().each(function(locationHierarchy) {
            locationLookupMap[locationHierarchy.get('code')] = locationHierarchy;
        });

        return locationLookupMap;
    }
});
