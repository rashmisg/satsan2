Ext.define('Jda.SCExecutive.model.LaborSpend', {
    extend: 'Jda.SCExecutive.model.CognosReport',

    config: {
        reportName: 'LA_Labor_Spend',
        reportFolder: 'Labor',

        laborSpend: null,
        laborBudgetSpend: null,
        laborBudget: null,
        periodHierarchy: null,
        locationHierarchies: null,
        laborByPeriodStore: null,
        minimumLocationValue: null,
        maximumLocationValue: null,
        minimumTotalValue: null,
        maximumTotalValue: null
    },

    processResponse: function(config) {
        var spend = this.extractMetaDataValue('Current_Period_Spend_Total', 'Current__Period__Spend__Total', config.periodHierarchy);
        var budget = this.extractMetaDataValue('Total_Spend_Budget', 'Total__Spend__Budget', config.periodHierarchy);
        var budgetSpend = this.extractMetaDataValue('Cumulative_Spend', 'Cumulative__Spend', config.periodHierarchy);
        var laborByPeriod = this.extractDataRows('Labor_Spend', config.periodHierarchy, config.locationHierarchy);
        var periodLookupMap = {};
        var locationFieldMap = {};
        var locationHierarchies = [];
        var locationHierarchyLookupMap = this._getLocationHierarchyMap(config.locationHierarchy);
        var periodRows = laborByPeriod ? this._getPeriodRows(config.periodHierarchy, periodLookupMap) : undefined;
        var minTotalValue = Number.MAX_VALUE;
        var maxTotalValue = Number.MIN_VALUE;
        var minLocationValue = Number.MAX_VALUE;
        var maxLocationValue = Number.MIN_VALUE;

        Ext.each(laborByPeriod, function(periodLabor) {
            var cost = periodLabor.Labor__Costs || 0;
            var periodCode = periodLabor.Period;
            var periodRow = periodLookupMap[periodCode];
            var locationCode = periodLabor.Location;
            var locationHierarchy = locationHierarchyLookupMap[locationCode];

            if (!periodRow) {
                this.logMissingHierarchy(periodCode);
                return;
            }

            if (!locationHierarchy) {
                this.logMissingHierarchy(locationCode);
                return;
            }

            periodRow[locationHierarchy] = cost;
            periodRow.total += cost;

            minLocationValue = Math.min(minLocationValue, cost);
            maxLocationValue = Math.max(maxLocationValue, cost);

            // using this effectively as a set collection, it contains the location codes encountered in the reports data
            locationFieldMap[locationHierarchy] = true;
            locationHierarchies.push(locationHierarchy);
        }, this);

        //Cannot check for min value until everything is aggregated.
        Ext.each(periodRows, function(row) {
            minTotalValue = Math.min(minTotalValue, row.total);
            maxTotalValue = Math.max(maxTotalValue, row.total);
        });

        var locationFields = Ext.Object.getKeys(locationFieldMap);
        var periodStore = Ext.create('Ext.data.Store', {
            fields: locationFields.concat([ 'total', 'periodHierarchy' ]),
            data: periodRows
        });

        var uniqueLocationHierarchies = Ext.Array.unique(locationHierarchies);
        var sortedLocationHierarchies = Ext.Array.sort(uniqueLocationHierarchies);

        this.setPeriodHierarchy(config.periodHierarchy);
        this.setLaborSpend(spend);
        this.setLaborBudgetSpend(budgetSpend);
        this.setLaborBudget(budget);
        this.setLocationHierarchies(sortedLocationHierarchies);
        this.setLaborByPeriodStore(periodStore);
        this.setMinimumTotalValue(minTotalValue);
        this.setMaximumTotalValue(maxTotalValue);
        this.setMinimumLocationValue(minLocationValue);
        this.setMaximumLocationValue(maxLocationValue);
    },

    // TODO should we include location with no data?
    _getLocationRows: function(parentLocationHierarchy, locationLookupMap) {
        var rows = [];

        parentLocationHierarchy.children().each(function(locationHierarchy) {
            var row = {
                locationName: locationHierarchy.get('name'),
                color: locationHierarchy.getColor(),
                hours: 0,
                trend: Jda.SCExecutive.component.TrendIndicator.TREND_DOWN // TODO probably cant default down
            };

            // populate to use for quick lookups of row objects while processing the report rows
            locationLookupMap[locationHierarchy.get('code')] = row;

            rows.push(row);
        });

        return rows;
    },

    _getPeriodRows: function(parentPeriodHierarchy, periodRowLookupMap) {
        var rows = [];

        parentPeriodHierarchy.children().each(function(periodHierarchy) {
            var row = {
                date: periodHierarchy.get('value'),
                periodHierarchy: periodHierarchy,
                total: 0
            };

            // populate to use for quick lookups of row objects while processing the report rows
            periodRowLookupMap[row.date] = row;

            rows.push(row);
        });

        return rows;
    },

    _getLocationHierarchyMap: function(parentLocationHierarchy) {
        var locationLookupMap = {};

        parentLocationHierarchy.children().each(function(locationHierarchy) {
            locationLookupMap[locationHierarchy.get('code')] = locationHierarchy;
        });

        return locationLookupMap;
    }
});
