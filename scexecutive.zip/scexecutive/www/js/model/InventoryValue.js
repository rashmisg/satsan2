Ext.define('Jda.SCExecutive.model.InventoryValue', {
    extend: 'Jda.SCExecutive.model.CognosReport',

    config: {
        reportName: 'IN_Inventory_Value',
        reportFolder: 'Inventory',

        store: null,
        locationHierarchies: null,
        periodHierarchy: null,

        priorAverageInventoryValue: null,
        averageInventoryValue: null,
        priorAverageUnitValue: null,
        averageUnitValue: null,

        inventoryValueMinimum: null,
        inventoryValueMaximum: null,
        inventoryValueTotalMinimum: null,
        inventoryValueTotalMaximum: null
    },

    processResponse: function(config) {
        var averageInventoryValue = this.extractMetaDataValue('Avg_Inventory_Value', 'Avg__Inventory__Value');
        var priorAverageInventoryValue = this.extractMetaDataValue('Prior_Avg_Inventory_Value', 'Prior__Avg__Inventory__Value', config.periodHierarchy);
        var averageUnitValue = this.extractMetaDataValue('Avg_Unit_Value', 'Avg__Unit__Value');
        var priorAverageUnitValue = this.extractMetaDataValue('Prior_Avg_Unit_Value', 'Prior__Avg__Unit__Value', config.periodHierarchy);
        var chartData = this.extractDataRows('Inventory_Value', config.periodHierarchy, config.locationHierarchy);
        // Don't create base data if there isn't any chart data
        var dataObject = chartData ? this._createBaseDataRows(config.periodHierarchy) : { rows: undefined };

        var locationFieldMap = {};
        var locationHierarchyLookupMap = this._getLocationHierarchyMap(config.locationHierarchy);
        var locationHierarchies = [];
        var inventoryValueMinimum = Number.MAX_VALUE;
        var inventoryValueMaximum = Number.MIN_VALUE;
        var inventoryValueTotalMinimum = Number.MAX_VALUE;
        var inventoryValueTotalMaximum = Number.MIN_VALUE;

        Ext.each(chartData, function(row) {
            var value = row.Inventory__Value;
            var periodCode = row.Period;
            var dataBucket = dataObject.periodRowLookupMap[periodCode];
            var locationCode = row.Location;
            var locationHierarchy = locationHierarchyLookupMap[locationCode];

            if (!dataBucket) {
                this.logMissingHierarchy(periodCode);
                return;
            }

            if (!locationHierarchy) {
                this.logMissingHierarchy(locationCode);
                return;
            }

            dataBucket[locationHierarchy] = value;
            dataBucket.total += value;

            inventoryValueMinimum = Math.min(inventoryValueMinimum, value);
            inventoryValueMaximum = Math.max(inventoryValueMaximum, value);

            locationFieldMap[locationHierarchy] = true;
            locationHierarchies.push(locationHierarchy);
        }, this);

        //Cannot check for min value until everything is aggregated.
        Ext.each(dataObject.rows, function(row) {
            inventoryValueTotalMinimum = Math.min(inventoryValueTotalMinimum, row.total);
            inventoryValueTotalMaximum = Math.max(inventoryValueTotalMaximum, row.total);
        });

        var locationFields = Ext.Object.getKeys(locationFieldMap);

        this.setStore(Ext.create('Ext.data.Store', {
            fields: locationFields.concat([ 'total', 'periodHierarchy', 'contextPeriodHierarchy' ]),
            data: dataObject.rows
        }));

        this.setLocationHierarchies(Ext.Array.unique(locationHierarchies));
        this.setPeriodHierarchy(config.periodHierarchy);

        this.setPriorAverageInventoryValue(priorAverageInventoryValue);
        this.setAverageInventoryValue(averageInventoryValue);
        this.setPriorAverageUnitValue(priorAverageUnitValue);
        this.setAverageUnitValue(averageUnitValue);

        this.setInventoryValueMinimum(inventoryValueMinimum);
        this.setInventoryValueMaximum(inventoryValueMaximum);
        this.setInventoryValueTotalMinimum(inventoryValueTotalMinimum);
        this.setInventoryValueTotalMaximum(inventoryValueTotalMaximum);
    },

    _createBaseDataRows: function(parentPeriodHierarchy) {
        var rows = [];
        var periodRowLookupMap = [];

        var addRowObject = function(periodHierarchy) {
            var row = {
                date: periodHierarchy.get('value'),
                periodHierarchy: periodHierarchy,
                contextPeriodHierarchy: parentPeriodHierarchy,
                total: 0
            };

            // populate to use for quick lookups of row objects while processing the report rows
            periodRowLookupMap[row.date] = row;
            rows.push(row);
        };

        var type = parentPeriodHierarchy.get('type');
        var types = Jda.SCExecutive.model.PeriodHierarchy.types;

        // week + month show direct children, quarter + year show grandchildren
        if (type === types.WEEK || type === types.MONTH) {
            parentPeriodHierarchy.children().each(addRowObject);
        }
        else if (type == types.QUARTER || type === types.YEAR) {
            parentPeriodHierarchy.children().each(function(child) {
                child.children().each(addRowObject);
            });
        }

        return { rows: rows, periodRowLookupMap: periodRowLookupMap };
    },

    _getLocationHierarchyMap: function(parentLocationHierarchy) {
        var locationLookupMap = {};

        parentLocationHierarchy.children().each(function(locationHierarchy) {
            locationLookupMap[locationHierarchy.get('code')] = locationHierarchy;
        });

        return locationLookupMap;
    }
});
