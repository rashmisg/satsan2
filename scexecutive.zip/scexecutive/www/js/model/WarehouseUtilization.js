Ext.define('Jda.SCExecutive.model.WarehouseUtilization', {
    extend: 'Jda.SCExecutive.model.CognosReport',

    config: {
        reportName: 'IN_Warehouse_Utilization',
        reportFolder: 'Inventory',

        store: null,
        utilizationPercent: null
    },

    processResponse: function(config) {
        var locationLookupMap = this._getLocationLoookupMap(config.locationHierarchy);
        var utilizationPercent = this.extractMetaDataValue('Avg_Warehouse_Utilization_Pct', 'Avg__Warehouse__Utilization__Pct');
        var inventoryRows = this.extractDataRows('Inventory', config.periodHierarchy, config.locationHierarchy);
        var utilizationRows = this.extractDataRows('Utilization_Pct', config.periodHierarchy, config.locationHierarchy);
        var massagedRows = [];
        var massagedRowsObj = {};

        Ext.each(inventoryRows, function(inventoryRow) {
            var locationCode = inventoryRow.Location;
            var locationHierarchy = locationLookupMap[locationCode];

            if (!locationHierarchy) {
                this.logMissingHierarchy(locationCode);
                return;
            }

            var row = {
                locationHierarchy: locationHierarchy,
                warehouses: inventoryRow.Warehouses,
                invValue: inventoryRow.Inventory__Value,
                invQuantity: inventoryRow.Inventory__Quantity
            };

            massagedRows.push(row);
            massagedRowsObj[locationHierarchy] = row;
        }, this);

        Ext.each(utilizationRows, function(utilizationRow) {
            var locationCode = utilizationRow.Location;
            var locationHierarchy = locationLookupMap[locationCode];

            if (!locationHierarchy) {
                this.logMissingHierarchy(locationCode);
                return;
            }

            var massagedRow = massagedRowsObj[locationHierarchy];
            var trend = utilizationRow.Utilization__Pct > utilizationRow.Prior__Utilization__Pct ? Jda.SCExecutive.component.TrendIndicator.TREND_UP : Jda.SCExecutive.component.TrendIndicator.TREND_DOWN;

            massagedRow.utilization = utilizationRow.Utilization__Pct;
            massagedRow.trend = trend;
        }, this);

        this.setUtilizationPercent(utilizationPercent);
        this.setStore(Ext.create('Ext.data.Store', {
            fields: [ 'locationHierarchy', 'utilization', 'trend', 'warehouses', 'invValue', 'invQuantity' ],
            data: massagedRows,
            sorters: [
                Jda.SCExecutive.util.Sorters.DisplayValueSorter.createSorter({
                    direction: 'DESC',
                    field: 'utilization',
                    precision: 0
                }), {
                    property: 'locationHierarchy',
                    direction: 'ASC'
                }
            ]
        }));
    },

    _getLocationLoookupMap: function(parentLocationHierarchy) {
        var lookupMap = {};

        parentLocationHierarchy.children().each(function(locationHierarchy) {
            lookupMap[locationHierarchy.get('code')] = locationHierarchy;
        });

        return lookupMap;
    }
});
