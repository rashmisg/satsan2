/*
CAGE-3774
This override fixes the issue that Ext.chart.axis.layout.Layout.trimByRange() will limit the number of 
steps to whatever steps is set to in snapEnds(). This limiting of steps, causes the last few major ticks
to not be rendered.
SenchaFiddle: https://fiddle.sencha.com/#fiddle/hk4
*/

Ext.define('Ext.chart.axis.layout.Continuous', {
    override: 'Ext.chart.axis.layout.Continuous',

    snapEnds: function (context, min, max, estStepSize) {
        var segmenter = context.segmenter,
            axis = this.getAxis(),
            minimum = axis.getMinimum(),
            maximum = axis.getMaximum(),
            majorTickSteps = axis.getMajorTickSteps(),
            out = majorTickSteps && Ext.isNumber(minimum) && Ext.isNumber(maximum) && segmenter.exactStep ?
                segmenter.exactStep(min, (max - min) / majorTickSteps) :
                segmenter.preferredStep(min, estStepSize),
            unit = out.unit,
            step = out.step,
            from = segmenter.align(min, step, unit),
            steps = segmenter.diff(min, max, unit) / out.step + 1; //OVERRIDE: added out.step division
        return {
            min: segmenter.from(min),
            max: segmenter.from(max),
            from: from,
            to: segmenter.add(from, steps * step, unit),
            step: step,
            steps: steps,
            unit: unit,
            get: function (current) {
                return segmenter.add(this.from, this.step * current, unit);
            }
        };
    }
});
