
// Workaround for the following bug: http://www.sencha.com/forum/showthread.php?276282-Bar-Chart-with-multiple-series-and-stacked-false-will-create-a-stacked-bar-chart&p=1048035#post1048035
Ext.define('Jda.SCExecutive.overrides.NonStackedBarSeriesOverride', {
    override: 'Ext.chart.CartesianChart',

    updateSeries: function() {
        var groupCount = 0;
        var unrelatedSeriesOffset = 0;

        Ext.each(this.getSeries(), function(series) {
            if (series instanceof Ext.chart.series.Bar && series.getStacked() === false) {
                groupCount++;
            }
            else {
                unrelatedSeriesOffset++;
            }
        });

        Ext.each(this.getSeries(), function(series, index) {
            if (series instanceof Ext.chart.series.Bar && series.getStacked() === false) {
                var sprite = series.getSprites()[0];

                sprite.setAttributes({
                    groupCount: groupCount,
                    groupOffset: index - unrelatedSeriesOffset
                });
            }
        });

        this.callParent(arguments);
    }
});
