/*

When performLayout() is called, if the chart's element does not have any width/height, the method returns out early, which
ultimately ends up with charts that render looking squashed.  This can reproduced in the following (known) ways currently:
    
    1. Navigate between two tabs that share a model (e.g. Overview + CS tabs).  Drill down a level in the location hierarchy
       and then switch back to the previous tab.  The charts that share the data model will look squashed.
    2. Navigate to the Overview tab, and then to the Labor tab.  Go to the settings tab and change your corporate
       currency.  Navigate to the Overview tab, and then to the Labor tab.  The charts that share data models with the Overview
       tab will look squashed.  This same sequencing can be applied to other tabs that share a data model as well.

Sencha Fiddle: https://fiddle.sencha.com/#fiddle/css
Forum post: http://www.sencha.com/forum/showthread.php?294291-Chart-series-getting-scrunched-in-corner&p=1074552#post1074552

*/
Ext.define('Jda.SCExecutive.overrides.ChartPerformLayoutForceRepaintOverride', {
    override: 'Ext.chart.CartesianChart',

    performLayout: function() {
        this.callParent(arguments);

        if (!this.isPainted()) {
            this.on('painted', this.scheduleLayout, this, { single: true });
        }
    }
});
