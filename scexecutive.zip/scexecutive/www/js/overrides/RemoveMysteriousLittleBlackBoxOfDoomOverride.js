/*

This override prevents the mysterious little black box of doom from appearing on DataViews when they're
initially being rendered.  The symptom results from the faux scrollbar and how it's initially being hidden.
The scrollbar is configured by default to be hidden, and is done so by shoving it -10000px off the screen.
That works fine, but (presumably) in an attempt to minimize DOM interactions, the actual movement off the
screen is deferred onto the Ext.TaskQueue, so it doesn't actually get hidden right away.  Since it's not
immediately hidden, you get to briefly see the mysterious little black box of doom.

The override resolves this by immediately "hiding" the scroll indicator.

I was not able to reproduce this using a Sencha Fiddle... it seems to only happen on a physical device.  It
can be seen on both iOS 7 + 8.

JIRA: http://jira.jda.com/browse/CAGE-3782
Forum post: http://www.sencha.com/forum/showthread.php?274872-The-mysterious-little-black-box-of-doom

*/

Ext.define('Jda.SCExecutive.overrides.RemoveMysteriousLittleBlackBoxOfDoomOverride', {
    override: 'Ext.scroll.indicator.Abstract',

    initialize: function() {
        this.callParent(arguments);

        this.doSetOffset(-10000);
    }
});
