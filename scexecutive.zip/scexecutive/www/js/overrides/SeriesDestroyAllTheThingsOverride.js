
// http://www.sencha.com/forum/showthread.php?287878-Chart-series.destroy()-not-removing-sprites
Ext.define('Jda.SCExecutive.overrides.SeriesDestroyAllTheThingsOverride', {
    override: 'Ext.chart.series.Series',

    destroy: function() {
        var surface = this.getSurface();
        var overlaySurface = this.getOverlaySurface();

        Ext.each(this.getSprites(), function(sprite) {
            surface.remove(sprite, true);

            if (sprite.itemsMarker) {
                surface.remove(sprite.itemsMarker, true);
            }

            if (sprite.dataMarker) {
                overlaySurface.remove(sprite.dataMarker, true);
            }
        });

        this.setChart(null);

        this.callParent(arguments);
    }
});
