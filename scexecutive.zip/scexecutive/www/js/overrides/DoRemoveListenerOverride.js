Ext.define('Jda.SCExecutive.overrides.Component.DoRemoveListenerOverride', {
    override: 'Ext.Component',

    doRemoveListener: function(name, fn, scope, options, order) {
        if (options && 'element' in options) {
            //<debug error>
            if (this.referenceList.indexOf(options.element) === -1) {
                Ext.Logger.error("Removing event listener with an invalid element reference of '" + options.element +
                    "' for this component. Available values are: '" + this.referenceList.join('", "') + "'", this);
            }
            //</debug>

            // The default scope is this component
            this[options.element].doRemoveListener(name, fn, scope || this, options, order);
        }
        
        // doAddListern for resize and painted adds the listener to the element. The removal needs to also
        // remove the listeners from the element so it has the correct observableType and the listener can
        // actually be removed. This was causing an issue with aligning the legend to various placeholders
        // http://www.sencha.com/forum/showthread.php?283672-Ext.Viewport.un(-resize-myFunction-myScope)-doesn-t-work-in-release!
        if (name == 'painted' || name == 'resize') {
            return this.element.doRemoveListener(name, fn, scope || this, options, order);
        }

        return this.callParent(arguments);
    }
});