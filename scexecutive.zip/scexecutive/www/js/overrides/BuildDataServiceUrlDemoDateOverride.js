
Ext.define('Jda.SCExecutive.overrides.BuildDataServiceUrlDemoDateOverride', {
    override: 'Jda.mobility.core.ApplicationSites',
    buildDataServiceUrlConfig: function(appId, bean, params) {
        var config = this.callParent(arguments);
        delete config.baseParams.demoDate;
        return config;
    }
});
Jda.buildDataServiceUrlConfig = Jda.mobility.core.ApplicationSites.buildDataServiceUrlConfig;