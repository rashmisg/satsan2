Ext.define('Jda.SCExecutive.component.MetricPeriodComparisonPopover', {
    extend: 'Ext.Panel',

    config: {
        //setting left and top to zero is required for the modal because otherwise the panel is 
        //considered apart of the viewport and starts out set to the viewport's width and height.
        //This causes the showBy to align the modal to the wrong spot, and then to realign 
        //because the viewport has resized. This causes the whole screen to flicker when the modal
        //is first created. Setting left and top to zero tells Touch to float the panel.
        left: 0,
        top: 0,
        cls: 'metric-period-comparison-popover',
        layout: 'vbox',
        modal: true,
        hideAnimation: 'fadeOut',
        hideOnMaskTap: true,
        items: [{
            layout: 'hbox',
            cls: 'title-box',
            items: [{
                itemId: 'titleLabel',
                xtype: 'label',
                cls: 'title',
                maxWidth: 160
            }, {
                minWidth: 10,
                flex: 1 //spacer
            }, {
                xtype: 'pill',
                good: true // These pills will always be good
            }]
        }, {
            layout: 'hbox',
            padding: '0 0 10px',
            items: [{
                layout: 'hbox',
                width: 100,
                height: 100,
                cls: 'period-comparison-bar-region',
                margin: '0 20px 0 5px',
                items: [{
                    itemId: 'priorPeriodBar',
                    cls: 'prior-period-bar'
                }, {
                    itemId: 'currentPeriodBar',
                    cls: 'current-period-bar'
                }]
            }, {
                layout: 'vbox',
                items: [{
                    layout: 'hbox',
                    height: 34,
                    margin: '0 0 15px',
                    items: [{
                        cls: 'period-row-icon prior',
                        width: 10,
                        margin: '0 10px 0 0'
                    }, {
                        layout: 'vbox',
                        padding: '0 5px 0 0',
                        items: [{
                            itemId: 'priorValueLabel',
                            xtype: 'label',
                            cls: 'value-label'
                        }, {
                            itemId: 'priorDateRangeLabel',
                            xtype: 'label',
                            cls: 'date-range-label'
                        }]
                    }]
                }, {
                    layout: 'hbox',
                    height: 34,
                    items: [{
                        cls: 'period-row-icon current',
                        width: 10,
                        margin: '0 10px 0 0'
                    }, {
                        layout: 'vbox',
                        padding: '0 5px 0 0',
                        items: [{
                            itemId: 'currentValueLabel',
                            xtype: 'label',
                            cls: 'value-label'
                        }, {
                            itemId: 'currentDateRangeLabel',
                            xtype: 'label',
                            cls: 'date-range-label'
                        }]
                    }]
                }]
            }]
        }]
    },

    statics: {
        show: function(config, showByComponent) {
            var popover = Jda.SCExecutive.component.MetricPeriodComparisonPopover._instance = Ext.create('Jda.SCExecutive.component.MetricPeriodComparisonPopover');

            popover.configure(config);
            popover.showBy(showByComponent);
        }
    },

    initialize: function() {
        this.callParent(arguments);

        this.on('hide', this.destroy, this);

        Ext.Viewport.on('activeitemchange', this.hide, this); //tabchange
        Jda.SCExecutive.util.AppContext.on('contextchanged', this.hide, this); //periodHierarchy or location change
    },

    configure: function(config) {
        var titleLabel = this.down('#titleLabel');
        titleLabel.setHtml(config.title);

        // Set value labels
        var currentValueLabel = this.down('#currentValueLabel');
        currentValueLabel.setHtml(config.formattedCurrentValue);

        var priorValueLabel = this.down('#priorValueLabel');
        priorValueLabel.setHtml(config.formattedPriorValue);

        // Set date range labels
        var currentPeriodHierarchy = config.periodHierarchy;
        var priorPeriodHierarchy = currentPeriodHierarchy.getPrevious();

        var currentDateRangeLabel = this.down('#currentDateRangeLabel');
        currentDateRangeLabel.setHtml(currentPeriodHierarchy.getDisplayString(true));

        var priorDateRangeLabel = this.down('#priorDateRangeLabel');
        priorDateRangeLabel.setHtml(priorPeriodHierarchy.getDisplayString(true));

        var current = config.currentValue;
        var prior = config.priorValue;

        // Determine and set percentage change label value
        var percentChange = (current - prior) / prior * 100;
        var formattedPercentChange = Jda.SCExecutive.util.Formatters.MetricFormatter.formatPercent(Math.abs(percentChange));
        var percentTrendLabel = Jda.getMessage('jda.scexecutive.metricperiodcomparisonpopover.' + (percentChange >= 0 ? 'Increase' : 'Decrease'));

        var pill = this.down('pill');
        pill.setText('<span class="pill-value">' + formattedPercentChange + '</span> <span class="pill-label">' + percentTrendLabel + '</span>');

        // Determine and set up bar heights
        var priorPeriodBar = this.down('#priorPeriodBar');
        var currentPeriodBar = this.down('#currentPeriodBar');

        if (prior > current) {
            var currentPercentOfPrior = (current / prior) * 100;
            priorPeriodBar.setHeight('100%');
            currentPeriodBar.setHeight(currentPercentOfPrior + '%');
        }
        else {
            var priorPercentOfCurrent = (prior / current) * 100;
            currentPeriodBar.setHeight('100%');
            priorPeriodBar.setHeight(priorPercentOfCurrent + '%');
        }
    }
});
