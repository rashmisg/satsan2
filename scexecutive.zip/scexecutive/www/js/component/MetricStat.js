Ext.define('Jda.SCExecutive.component.MetricStat', {
    extend: 'Ext.Container',
    xtype: 'metricstat',

    config: {
        size: 'large-stat', // default to large
        qualifierText: null,
        valueText: null,
        good: true,
        shouldFlexItems: true,

        cls: 'metric-stat-container',
        layout: {
            type: 'hbox',
            align: 'center',
            pack: 'center'
        }
    },

    statics: {
        sizes: {
            LARGE: 'large-stat',
            MEDIUM: 'medium-stat'
        }
    },

    updateShouldFlexItems: function(shouldFlexItems) {
        this.removeAll();

        // Remove and re-add items. When horizontal, items are flexed to align their texts.
        // Otherwise, they just let the align and pack configs determine their container position.
        var flex = shouldFlexItems ? 1 : undefined;
        this.add([{
            xtype: 'label',
            itemId: 'metricValueLabel',
            cls: 'metric-stat',
            flex: flex
        }, {
            xtype: 'label',
            itemId: 'metricQualifierLabel',
            cls: 'metric-stat-qualifier',
            flex: flex
        }]);
    },

    updateSize: function(newSize, oldSize) {
        if (oldSize) {
            this.removeCls(oldSize);
        }

        this.addCls(newSize);
    },

    updateGood: function(isGood) {
        if (isGood) {
            this.removeCls('bad');
            this.addCls('good');
        }
        else {
            this.removeCls('good');
            this.addCls('bad');
        }
    },

    updateValueText: function(valueText) {
        var valueLabel = this.down('#metricValueLabel');

        valueLabel.setHtml(valueText);
    },

    updateQualifierText: function(qualifierText) {
        var qualifierLabel = this.down('#metricQualifierLabel');

        qualifierLabel.setHtml(qualifierText);
    }
});
