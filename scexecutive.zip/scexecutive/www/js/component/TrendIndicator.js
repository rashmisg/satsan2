Ext.define('Jda.SCExecutive.component.TrendIndicator', {
    extend: 'Ext.Container',
    xtype: 'trendindicator',

    statics: {
        TREND_UP: 'up',
        TREND_DOWN: 'down',
        TREND_UNKNOWN: 'unknown',

        ICON_LEFT: 'left',
        ICON_RIGHT: 'right'
    },

    config: {
        layout: {
            type: 'vbox',
            align: 'end'
        },
        items: [{
            itemId: 'valueText',
            cls: 'value-text'
        }, {
            itemId: 'labelText',
            cls: 'label-text'
        }],

        cmpCls: 'trend-indicator',
        trend: 'unknown',
        iconSide: 'left',
            
        labelText: null,

        priorValue: null,
        currentValue: null,
        priorValueText: null,
        currentValueText: null,
        currentPeriodHierarchy: null
    },

    configure: function(config) {
        this.setPriorValue(config.priorValue);
        this.setCurrentValue(config.currentValue);
        this.setPriorValueText(config.priorValueText);
        this.setCurrentValueText(config.currentValueText);

        this.setCurrentPeriodHierarchy(config.currentPeriodHierarchy);

        // If we have a prior value and there is a previous period hierarchy, set the trend
        var hasPreviousPeriodHierarchy = config.currentPeriodHierarchy.get('hasPrevious');
        if (hasPreviousPeriodHierarchy && !Ext.isEmpty(config.priorValue)) {
            var isTrendingUp = config.currentValue >= config.priorValue;
            var trend = isTrendingUp ? Jda.SCExecutive.component.TrendIndicator.TREND_UP : Jda.SCExecutive.component.TrendIndicator.TREND_DOWN;
            this.setTrend(trend);
        }
        // Otherwise, use an 'unknown' value
        else {
            console.warn('No prior data for trend indicator.');
            this.setTrend(Jda.SCExecutive.component.TrendIndicator.TREND_UNKNOWN);
        }
    },

    initialize: function() {
        this.callParent();

        this.element.on('tap', this._onTrendIndicatorTap, this);
    },

    updateCmpCls: function(newCls, oldCls) {
        if (this.element) {
            this.element.replaceCls(oldCls, newCls);
        }
    },

    updateLabelText: function(newText) {
        this.down('#labelText').setHtml(newText);
    },

    updateTrend: function(trend) {
        var statics = this.statics();
        this.replaceCls([ statics.TREND_UNKNOWN, statics.TREND_UP, statics.TREND_DOWN ], trend);
    },

    updateIconSide: function(side) {
        var statics = this.statics();
        this.getLayout().setAlign(side === statics.ICON_RIGHT ? 'end' : 'start');
        this.replaceCls([ statics.ICON_LEFT, statics.ICON_RIGHT ], side);
    },

    updateCurrentValueText: function(newText) {
        this.down('#valueText').setHtml(newText);
    },

    _onTrendIndicatorTap: function() {
        // Don't pop up a window if there is no prior value or period
        var hasPreviousPeriodHierarchy = this.getCurrentPeriodHierarchy().get('hasPrevious');
        if (!hasPreviousPeriodHierarchy || Ext.isEmpty(this.getPriorValue())) {
            return;
        }

        Jda.SCExecutive.component.MetricPeriodComparisonPopover.show({
            title: this.getLabelText(),
            periodHierarchy: this.getCurrentPeriodHierarchy(),
            currentValue: this.getCurrentValue(),
            formattedCurrentValue: this.getCurrentValueText(),
            priorValue: this.getPriorValue(),
            formattedPriorValue: this.getPriorValueText()
        }, this);
    }
});
