Ext.define('Jda.SCExecutive.view.Overview.AverageDaysOfSupply.View', {
    extend: 'Ext.Panel',
    xtype: 'overviewaveragedaysofsupplyview',

    config: {
        layout: 'vbox',
        items: [{
            xtype: 'label',
            itemId: 'overviewavgdaysofsupplytitlelabel',
            cls: 'title-container',
            html: '<span class="secondary-title">' + Jda.getMessage('jda.scexecutive.averagedaysofsupply.Title') + '</span>'
        }, {
            flex: 1,
            xtype: 'inventoryaveragedaysofsupplychart'
        }, {
            layout: {
                type: 'hbox',
                pack: 'center'
            },
            items: [{
                itemId: 'supplyChainAverageTrendIndicator',
                xtype: 'trendindicator',
                iconSide: Jda.SCExecutive.component.TrendIndicator.ICON_LEFT,
                labelText: Jda.getMessage('jda.scexecutive.averagedaysofsupply.SupplyChainAverageLabel')
            }]
        }],

        model: null,
        isMaximized: false
    },

    updateIsMaximized: function(isMaximized) {
        var chart = this.down('inventoryaveragedaysofsupplychart');
        chart.setIsMaximized(isMaximized);
    },

    loadFromModel: function(model) {
        var chart = this.down('inventoryaveragedaysofsupplychart');
        chart.loadFromModel(model);

        var supplyChainAverageTrendIndicator = this.down('#supplyChainAverageTrendIndicator');
        supplyChainAverageTrendIndicator.configure({
            priorValue: model.getPriorSupplyChainAverage(),
            currentValue: model.getSupplyChainAverage(),
            priorValueText: Jda.SCExecutive.util.Formatters.MetricFormatter.formatNumber(model.getPriorSupplyChainAverage(), Jda.SCExecutive.constant.Precision.Medium),
            currentValueText: Jda.SCExecutive.util.Formatters.MetricFormatter.formatNumber(model.getSupplyChainAverage(), Jda.SCExecutive.constant.Precision.Medium),
            currentPeriodHierarchy: model.getPeriodHierarchy()
        });

        this.setModel(model);
    }
});
