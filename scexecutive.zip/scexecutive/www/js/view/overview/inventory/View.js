Ext.define('Jda.SCExecutive.view.Overview.Inventory.View', {
    extend: 'Ext.Panel',
    xtype: 'overviewinventoryview',

    config: {
        layout: 'vbox',
        cls: 'sub-metric-panel',
        items: [{
            flex: 1,
            xtype: 'overviewinventoryvalueview'
        }, {
            xtype: 'component',
            cls: 'metric-divider-horizontal'
        }, {
            flex: 1,
            xtype: 'overviewaveragedaysofsupplyview',
            padding: '0 0 15px'
        }],
        plugins: [ 'maximize' ]
    },

    getMaximizedView: function() {
        var inventoryValueView = this.down('overviewinventoryvalueview');
        var inventoryValueModel = inventoryValueView.getModel();

        var daysOfSupplyView = this.down('overviewaveragedaysofsupplyview');
        var daysOfSupplyModel = daysOfSupplyView.getModel();

        var maximizedView = Ext.create('Jda.SCExecutive.view.Overview.Inventory.MaximizedView');
        maximizedView.loadFromInventoryValueModel(inventoryValueModel);
        maximizedView.loadFromDaysOfSupplyModel(daysOfSupplyModel);

        return maximizedView;
    }
});
