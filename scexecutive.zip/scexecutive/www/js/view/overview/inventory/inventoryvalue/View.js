Ext.define('Jda.SCExecutive.view.Overview.InventoryValue.View', {
    extend: 'Ext.Panel',
    xtype: 'overviewinventoryvalueview',

    config: {
        layout: 'vbox',
        items: [{
            xtype: 'label',
            itemId: 'overviewinventoryvaluetitlelabel',
            cls: 'title-container',
            html: '<span class="title">' + Jda.getMessage('jda.scexecutive.inventoryvalue.Title') + '</span>'
        }, {
            flex: 1,
            xtype: 'inventoryvaluechart',
            showAggregatedData: true
        }, {
            layout: {
                type: 'hbox',
                pack: 'center'
            },
            items: [{
                itemId: 'averageUnitValueTrendIndicator',
                xtype: 'trendindicator',
                iconSide: Jda.SCExecutive.component.TrendIndicator.ICON_LEFT,
                labelText: Jda.getMessage('jda.scexecutive.inventoryvalue.AverageUnitValueLabel')
            }]
        }],

        model: null,
        isMaximized: false
    },

    updateIsMaximized: function(isMaximized) {
        var chart = this.down('inventoryvaluechart');
        chart.setIsMaximized(isMaximized);
    },

    loadFromModel: function(model) {
        var chart = this.down('inventoryvaluechart');
        chart.loadFromModel(model);

        var averageUnitValueTrendIndicator = this.down('#averageUnitValueTrendIndicator');
        averageUnitValueTrendIndicator.configure({
            priorValue: model.getPriorAverageUnitValue(),
            currentValue: model.getAverageUnitValue(),
            priorValueText: Jda.SCExecutive.util.Formatters.MetricFormatter.formatCurrency(model.getPriorAverageUnitValue(), Jda.SCExecutive.constant.Precision.Medium),
            currentValueText: Jda.SCExecutive.util.Formatters.MetricFormatter.formatCurrency(model.getAverageUnitValue(), Jda.SCExecutive.constant.Precision.Medium),
            currentPeriodHierarchy: model.getPeriodHierarchy()
        });

        this.setModel(model);
    }
});
