Ext.define('Jda.SCExecutive.view.Overview.Inventory.MaximizedView', {
    extend: 'Ext.Panel',

    config: {
        layout: 'hbox',
        cls: 'expanded-metric-panel',
        items: [{
            flex: 1,
            xtype: 'overviewinventoryvalueview',
            padding: '0 0 15px',
            isMaximized: true
        }, {
            xtype: 'component',
            cls: 'metric-divider-vertical',
            margin: '10px 0'
        }, {
            flex: 1,
            xtype: 'overviewaveragedaysofsupplyview',
            padding: '0 0 15px',
            isMaximized: true
        }]
    },

    loadFromInventoryValueModel: function(model) {
        var inventoryValueView = this.down('overviewinventoryvalueview');
        inventoryValueView.loadFromModel(model);
    },

    loadFromDaysOfSupplyModel: function(model) {
        var daysOfSupplyView = this.down('overviewaveragedaysofsupplyview');
        daysOfSupplyView.loadFromModel(model);
    }
});
