Ext.define('Jda.SCExecutive.view.Overview.ForecastAccuracy.View', {
    extend: 'Ext.Container',
    xtype: 'overviewforecastaccuracyview',

    config: {
        cls: 'sub-metric-panel',
        layout: 'vbox',
        items: [{
            layout: 'hbox',
            items:[{
                cls: 'title-container',
                items: [{
                    xtype: 'label',
                    html: '<span class="title">' + Jda.getMessage('jda.scexecutive.forecastaccuracy.Title') + '</span>'
                }, {
                    xtype: 'label',
                    itemId: 'lagLabel',
                    cls: 'subtitle'
                }]
            }, {
                flex: 1 //spacer
            }, {
                xtype: 'pill',
                itemId: 'forecastAccuracyPill'
            }]
        }, {
            layout: {
                type: 'hbox',
                pack: 'center'
            },
            style: 'margin: 0 0 20px 0;',
            items: [{
                flex: 1
            }, {
                itemId: 'totalSalesTrendIndicator',
                xtype: 'trendindicator',
                cls: 'medium',
                iconSide: Jda.SCExecutive.component.TrendIndicator.ICON_LEFT,
                labelText: Jda.getMessage('jda.scexecutive.forecastaccuracy.TotalSalesLabel')
            }, {
                flex: 1
            }, {
                itemId: 'forecastedSalesTrendIndicator',
                xtype: 'trendindicator',
                cls: 'medium',
                iconSide: Jda.SCExecutive.component.TrendIndicator.ICON_LEFT,
                labelText: Jda.getMessage('jda.scexecutive.forecastaccuracy.ForecastedSalesLabel')
            }, {
                flex: 1
            }]
        }, {
            flex: 1,
            xtype: 'scexecutivegrid',
            columns: [{
                text: Jda.getMessage('jda.scexecutive.forecastaccuracy.RegionColumnHeader'),
                dataIndex: 'locationHierarchy',
                width: '40%',
                renderer: function(value) {
                    var color = value.getColor();
                    var name = Ext.String.htmlEncode(value.get('name'));

                    return Ext.String.format('<div class="forecast-accuracy-legend-item" style="background-color: {0};"></div>{1}', color, name);
                }
            }, {
                text: Jda.getMessage('jda.scexecutive.forecastaccuracy.SalesColumnHeader'),
                dataIndex: 'sales',
                width: '20%',
                renderer: function(value) {
                    return Jda.SCExecutive.util.Formatters.MetricFormatter.formatCurrency(value, Jda.SCExecutive.constant.Precision.Medium, true);
                }
            }, {
                text: Jda.getMessage('jda.scexecutive.forecastaccuracy.ForecastedColumnHeader'),
                dataIndex: 'forecast',
                width: '40%',
                renderer: function(value) {
                    return Jda.SCExecutive.util.Formatters.MetricFormatter.formatCurrency(value, Jda.SCExecutive.constant.Precision.Medium, true);
                }
            }]
        }]
    },

    loadFromModel: function(model) {
        var lagLabel = this.down('#lagLabel');
        var lagLabelDisplayValue = Ext.String.format(Jda.getMessage('jda.scexecutive.forecastaccuracy.SubTitleFormat'), model.getLag());
        lagLabel.setHtml(lagLabelDisplayValue);

        var forecastAccuracyPill = this.down('#forecastAccuracyPill');
        var forecastAccuracyPercent = model.getForecastAccuracyPercent();
        var forecastAccuracyDisplayValue = Jda.SCExecutive.util.Formatters.MetricFormatter.formatPercent(forecastAccuracyPercent, Jda.SCExecutive.constant.Precision.Low);
        var forecastAccuracyPercentTarget = model.getForecastAccuracyPercentTarget();

        forecastAccuracyPill.setText(forecastAccuracyDisplayValue);
        forecastAccuracyPill.setGood(model.isForecastAccuracyGood());

        var totalSalesTrendIndicator = this.down('#totalSalesTrendIndicator');
        totalSalesTrendIndicator.configure({
            priorValue: model.getPriorTotalSales(),
            currentValue: model.getTotalSales(),
            priorValueText: Jda.SCExecutive.util.Formatters.MetricFormatter.formatCurrency(model.getPriorTotalSales(), Jda.SCExecutive.constant.Precision.Medium),
            currentValueText: Jda.SCExecutive.util.Formatters.MetricFormatter.formatCurrency(model.getTotalSales(), Jda.SCExecutive.constant.Precision.Medium),
            currentPeriodHierarchy: model.getPeriodHierarchy()
        });

        var forecastedSalesTrendIndicator = this.down('#forecastedSalesTrendIndicator');
        forecastedSalesTrendIndicator.configure({
            priorValue: model.getPriorForecastedSales(),
            currentValue: model.getForecastedSales(),
            priorValueText: Jda.SCExecutive.util.Formatters.MetricFormatter.formatCurrency(model.getPriorForecastedSales(), Jda.SCExecutive.constant.Precision.Medium),
            currentValueText: Jda.SCExecutive.util.Formatters.MetricFormatter.formatCurrency(model.getForecastedSales(), Jda.SCExecutive.constant.Precision.Medium),
            currentPeriodHierarchy: model.getPeriodHierarchy()
        });

        var grid = this.down('scexecutivegrid');
        grid.setStore(model.getStore());
    }
});
