Ext.define('Jda.SCExecutive.view.Overview.CustomerServicePerformance.MaximizedView', {
    extend: 'Ext.Container',

    config: {
        layout: 'vbox',
        cls: 'expanded-metric-panel',
        items: [{
            xtype: 'label',
            itemId: 'overviewcustomerservicetitlelabel',
            cls: 'title-container',
            html: '<span class="title">' + Jda.getMessage('jda.scexecutive.customerservice.Title') + '</span>'
        }, {
            layout: {
                type: 'hbox',
                pack: 'center'
            },
            items: [{
                itemId: 'performanceTrendIndicator',
                xtype: 'trendindicator',
                iconSide: Jda.SCExecutive.component.TrendIndicator.ICON_LEFT,
                labelText: Jda.getMessage('jda.scexecutive.overview.Performance'),
                margin: '0 30 0 0'
            }, {
                itemId: 'ordersFilledTrendIndicator',
                xtype: 'trendindicator',
                iconSide: Jda.SCExecutive.component.TrendIndicator.ICON_LEFT,
                labelText: Jda.getMessage('jda.scexecutive.customerservice.OrdersFilledLabel')
            }]
        }, {
            xtype: 'customerserviceperformancechart',
            flex: 1,
            isMaximized: true
        }]
    },

    loadFromModel: function(model) {
        var performanceTrendIndicator = this.down('#performanceTrendIndicator');
        performanceTrendIndicator.configure({
            priorValue: model.getPriorAverageCustomerServiceLevelPercent(),
            currentValue: model.getAverageCustomerServiceLevelPercent(),
            priorValueText: Jda.SCExecutive.util.Formatters.MetricFormatter.formatPercent(model.getPriorAverageCustomerServiceLevelPercent(), Jda.SCExecutive.constant.Precision.Medium),
            currentValueText: Jda.SCExecutive.util.Formatters.MetricFormatter.formatPercent(model.getAverageCustomerServiceLevelPercent(), Jda.SCExecutive.constant.Precision.Medium),
            currentPeriodHierarchy: model.getPeriodHierarchy()
        });

        var ordersFilledTrendIndicator = this.down('#ordersFilledTrendIndicator');
        ordersFilledTrendIndicator.configure({
            priorValue: model.getPriorOrdersFilledValue(),
            currentValue: model.getOrdersFilledValue(),
            priorValueText: Jda.SCExecutive.util.Formatters.MetricFormatter.formatCurrency(model.getPriorOrdersFilledValue(), Jda.SCExecutive.constant.Precision.Medium), 
            currentValueText: Jda.SCExecutive.util.Formatters.MetricFormatter.formatCurrency(model.getOrdersFilledValue(), Jda.SCExecutive.constant.Precision.Medium),
            currentPeriodHierarchy: model.getPeriodHierarchy()
        });

        var chart = this.down('customerserviceperformancechart');
        chart.loadFromModel(model);
    }
});
