Ext.define('Jda.SCExecutive.view.Overview.Labor.LaborSpend.View', {
    extend: 'Ext.Panel',
    xtype: 'overviewlaborspendview',

    config: {
        layout: 'vbox',
        items: [{
            xtype: 'label',
            itemId: 'overviewlaborspendtitlelabel',
            cls: 'title-container',
            html: '<span class="title">' + Jda.getMessage('jda.scexecutive.laborspend.Title') + '</span>'
        }, {
            flex: 1,
            xtype: 'laborspendchart',
            showAggregatedData: true
        }, {
            xtype: 'progressbar'
        }],

        model: null,
        isMaximized: false
    },

    updateIsMaximized: function(isMaximized) {
        var chart = this.down('laborspendchart');
        chart.setIsMaximized(isMaximized);
    },

    loadFromModel: function(model) {
        var spend = model.getLaborBudgetSpend();
        var budget = model.getLaborBudget();

        var progressBar = this.down('progressbar');
        progressBar.updatePeriodHierarchy(model.getPeriodHierarchy());
        progressBar.updateValues(spend, budget);

        var chart = this.down('laborspendchart');
        chart.loadFromModel(model);

        this.setModel(model);
    }
});
