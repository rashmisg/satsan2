Ext.define('Jda.SCExecutive.view.Overview.Labor.MaximizedView', {
    extend: 'Ext.Panel',

    config: {
        layout: 'hbox',
        cls: 'expanded-metric-panel',
        items: [{
            xtype: 'overviewlaborspendview',
            flex: 1,
            isMaximized: true
        }, {
            xtype: 'component',
            cls: 'metric-divider-vertical'
        }, {
            xtype: 'overviewlaborhoursview'
        }]
    },

    loadFromLaborSpendModel: function(model) {
        var laborSpendView = this.down('overviewlaborspendview');
        laborSpendView.loadFromModel(model);
    },

    loadFromLaborHoursModel: function(model) {
        var laborHoursView = this.down('overviewlaborhoursview');
        laborHoursView.loadFromModel(model);
    }
});
