Ext.define('Jda.SCExecutive.view.Overview.Labor.LaborHours.View', {
    extend: 'Ext.Panel',
    xtype: 'overviewlaborhoursview',

    config: {
        layout: {
            type: 'vbox',
            align: 'stretch'
        },
        items: [{
            cls: 'labor-hours-region-title',
            layout: 'hbox',
            items: [{
                xtype: 'label',
                cls: 'labor-hours-region-title-label',
                html: Jda.getMessage('jda.scexecutive.laborspend.LaborHours')
            }, {
                xtype: 'pill',
                itemId: 'laborHoursPill',
                flex: 1
            }]
        }, {
            xtype: 'dataview',
            itemId: 'locationHoursList',
            itemCls: 'location-hours-list-cell',
            scrollable: 'vertical',
            cls: 'location-hours-list',
            flex: 1,
            itemTpl: Ext.XTemplate([
                '<div class="location-hours-name-label" style="color: {color};">{locationName}</div>',
                '<div class="small trend-indicator {totalHoursTrend}"></div>',
                '<span class="hours-label">{[Jda.SCExecutive.util.Formatters.MetricFormatter.formatNumber(values.totalHours)]} </span><span class="abbr-label">' + Jda.getMessage('jda.scexecutive.laborspend.HoursAbbr') + '</span>'
            ]),
            listeners: {
                itemtap: function(dataView, index, target, record) {
                    var priorTotalHours = record.get('priorTotalHours');

                    // Don't do anything if there is no comparison value. Note that this
                    // value will also be empty if there is no prior period hierarchy
                    if (Ext.isEmpty(priorTotalHours)) {
                        return;
                    }

                    var abbrLabel = ' <span class="location-hours-trend-tooltip-abbr-label">' + Jda.getMessage('jda.scexecutive.laborspend.HoursAbbr') + '</span>';

                    Jda.SCExecutive.component.MetricPeriodComparisonPopover.show({
                        title: record.get('locationName'),
                        priorValue: priorTotalHours,
                        currentValue: record.get('totalHours'),
                        formattedPriorValue: Jda.SCExecutive.util.Formatters.MetricFormatter.formatNumber(priorTotalHours) + abbrLabel,
                        formattedCurrentValue: Jda.SCExecutive.util.Formatters.MetricFormatter.formatNumber(record.get('totalHours')) + abbrLabel,
                        periodHierarchy: record.get('periodHierarchy')
                    }, target);
                }
            }
        }],
        model: null
    },

    loadFromModel: function(model) {
        var store = model.getStore();
        var locationHoursList = this.down('#locationHoursList');
        locationHoursList.setStore(store);

        var formattedHours = Jda.SCExecutive.util.Formatters.MetricFormatter.formatNumber(model.getTotalCombinedHours(), Jda.SCExecutive.constant.Precision.Medium);
        var laborHoursPill = this.down('#laborHoursPill');
        laborHoursPill.setGood(true); // No Target, always good
        laborHoursPill.setText(formattedHours);

        this.setModel(model);
    }
});
