Ext.define('Jda.SCExecutive.view.Overview.Labor.View', {
    extend: 'Ext.Panel',
    xtype: 'overviewlaborview',

    config: {
        layout: 'hbox',
        cls: 'sub-metric-panel',
        items: [{
            xtype: 'overviewlaborspendview',
            flex: 1
        }, {
            xtype: 'component',
            cls: 'metric-divider-vertical'
        }, {
            xtype: 'overviewlaborhoursview'
        }],
        plugins: [ 'maximize' ]
    },

    getMaximizedView: function() {
        var laborSpendView = this.down('overviewlaborspendview');
        var laborSpendModel = laborSpendView.getModel();

        var laborHoursView = this.down('overviewlaborhoursview');
        var laborHoursModel = laborHoursView.getModel();

        var maximizedView = Ext.create('Jda.SCExecutive.view.Overview.Labor.MaximizedView');
        maximizedView.loadFromLaborSpendModel(laborSpendModel);
        maximizedView.loadFromLaborHoursModel(laborHoursModel);

        return maximizedView;
    }
});
