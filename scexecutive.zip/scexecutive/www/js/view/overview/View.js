Ext.define('Jda.SCExecutive.view.Overview.View', {
    extend: 'Ext.Panel',
    xtype: 'overview',

    config: {
        cls: 'main-view',
        layout: {
            type: 'vbox'
        },
        items: [{
            xtype: 'contextcontainer'
        }, {
            flex: 1,
            layout: 'hbox',
            cls: 'sub-metric-row',
            items: [{
                flex: 2,
                layout: 'fit',
                items: {
                    // this d00d is wrapped because of some limitiations of the 'sub-metric-row' and
                    // the 'sub-metric-panel' classes.  if you collapse the view back a level, you'll
                    // see the margin issues which result in the layout not being pixel perfect.  we
                    // might be able to separate those two css classes into separate ones (some for
                    // normal styling, and some for layout), kind of like how twitter bootstrap does it
                    xtype: 'overviewcustomerserviceperformanceview'
                }
            }, {
                flex: 1,
                xtype: 'overviewforecastaccuracyview',
                cls: 'sub-metric-panel'
            }]
        }, {
            flex: 2,
            layout: 'hbox',
            cls: 'sub-metric-row',
            items: [{
                flex: 2,
                layout: 'vbox',
                items: [{
                    flex: 1,
                    xtype: 'overviewtransportationspendview'
                }, {
                    flex: 1,
                    xtype: 'overviewlaborview'
                }]
            }, {
                xtype: 'overviewinventoryview',
                flex: 1
            }]
        }, {
            xtype: 'legendcontainer'
        }]
    }
});
