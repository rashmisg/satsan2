Ext.define('Jda.SCExecutive.view.Overview.TransportationSpend.View', {
    extend: 'Ext.Panel',
    xtype: 'overviewtransportationspendview',

    config: {
        layout: 'vbox',
        cls: 'sub-metric-panel',
        items: [{
            flex: 1,
            layout: 'hbox',
            items: [{
                layout: 'vbox',
                flex: 1,
                items: [{
                    xtype: 'label',
                    itemId: 'overviewtransspendtitlelabel',
                    cls: 'title-container',
                    html: '<span class="title">' + Jda.getMessage('jda.scexecutive.transportationspend.Title') + '</span>'
                }, {
                    flex: 1,
                    xtype: 'transportationspendchart',
                    showAggregatedData: true
                }]
            }, {
                layout: {
                    type: 'vbox',
                    align: 'stretch'
                },
                cls: 'transportation-spend-metric-stats-container',
                items: [{
                    flex: 1
                }, {
                    xtype: 'horsepill',
                    layout: 'vbox',
                    itemId: 'currentSpendingPill'
                }, {
                    flex: 5,
                    layout: 'hbox',
                    items: [{
                        flex: 1
                    }, {
                        layout: {
                            type: 'vbox',
                            align: 'end'
                        },
                        items: [{
                            flex: 1
                        }, {
                            xtype: 'trendindicator',
                            itemId: 'inboundSpendTrendIndicator',
                            iconSide: Jda.SCExecutive.component.TrendIndicator.ICON_RIGHT,
                            labelText: Jda.getMessage('jda.scexecutive.transportationspend.Inbound')
                        }, {
                            flex: 1
                        }, {
                            xtype: 'trendindicator',
                            itemId: 'outboundSpendTrendIndicator',
                            iconSide: Jda.SCExecutive.component.TrendIndicator.ICON_RIGHT,
                            labelText: Jda.getMessage('jda.scexecutive.transportationspend.Outbound')
                        }, {
                            flex: 1
                        }]
                    }, {
                        flex: 1
                    }]
                }]
            }]
        }, {
            xtype: 'progressbar'
        }],
        plugins: [ 'maximize' ],

        model: null
    },

    loadFromModel: function(model) {
        var chart = this.down('transportationspendchart');
        chart.loadFromModel(model);

        var progressBar = this.down('progressbar');
        progressBar.updatePeriodHierarchy(model.getPeriodHierarchy());
        progressBar.updateValues(model.getTotalBudgetSpend(), model.getTotalBudget());

        var currentSpendingPill = this.down('#currentSpendingPill');
        currentSpendingPill.setGood(true);
        currentSpendingPill.displaySpendingTextForPeriod(model.getTotalSpend(), model.getPeriodHierarchy());

        var inboundSpendTrendIndicator = this.down('#inboundSpendTrendIndicator');
        inboundSpendTrendIndicator.configure({
            priorValue: model.getPriorInboundSpend(),
            currentValue: model.getInboundSpend(),
            priorValueText: Jda.SCExecutive.util.Formatters.MetricFormatter.formatCurrency(model.getPriorInboundSpend()),
            currentValueText: Jda.SCExecutive.util.Formatters.MetricFormatter.formatCurrency(model.getInboundSpend()),
            currentPeriodHierarchy: model.getPeriodHierarchy()
        });

        var outboundSpendTrendIndicator = this.down('#outboundSpendTrendIndicator');
        outboundSpendTrendIndicator.configure({
            priorValue: model.getPriorOutboundSpend(),
            currentValue: model.getOutboundSpend(),
            priorValueText: Jda.SCExecutive.util.Formatters.MetricFormatter.formatCurrency(model.getPriorOutboundSpend()),
            currentValueText: Jda.SCExecutive.util.Formatters.MetricFormatter.formatCurrency(model.getOutboundSpend()),
            currentPeriodHierarchy: model.getPeriodHierarchy()
        });

        this.setModel(model);
    },

    getMaximizedView: function() {
        var maximizedView = Ext.create('Jda.SCExecutive.view.Overview.TransportationSpend.MaximizedView');

        maximizedView.loadFromModel(this.getModel());

        return maximizedView;
    }
});
