Ext.define('Jda.SCExecutive.view.Overview.TransportationSpend.MaximizedView', {
    extend: 'Ext.Panel',

    config: {
        layout: 'vbox',
        cls: 'expanded-metric-panel',
        items: [{
            xtype: 'label',
            itemId: 'overviewtransspendtitlelabel',
            cls: 'title-container',
            html: '<span class="title">' + Jda.getMessage('jda.scexecutive.transportationspend.Title') + '</span>'
        }, {
            layout: {
                type: 'hbox',
                pack: 'center',
                align: 'center'
            },
            margin: '10px 0 15px',
            items: [{
                xtype: 'horsepill',
                layout: 'vbox',
                itemId: 'currentSpendingPill'
            }, {
                xtype: 'trendindicator',
                itemId: 'inboundSpendTrendIndicator',
                iconSide: Jda.SCExecutive.component.TrendIndicator.ICON_LEFT,
                labelText: Jda.getMessage('jda.scexecutive.transportationspend.Inbound'),
                margin: '0 30px'
            }, {
                xtype: 'trendindicator',
                itemId: 'outboundSpendTrendIndicator',
                iconSide: Jda.SCExecutive.component.TrendIndicator.ICON_LEFT,
                labelText: Jda.getMessage('jda.scexecutive.transportationspend.Outbound')
            }]
        }, {
            flex: 1,
            xtype: 'transportationspendchart',
            showAggregatedData: true,
            isMaximized: true
        }, {
            xtype: 'progressbar'
        }]
    },

    loadFromModel: function(model) {
        var chart = this.down('transportationspendchart');
        chart.loadFromModel(model);

        var progressBar = this.down('progressbar');
        progressBar.updatePeriodHierarchy(model.getPeriodHierarchy());
        progressBar.updateValues(model.getTotalBudgetSpend(), model.getTotalBudget());

        var currentSpendingPill = this.down('#currentSpendingPill');
        currentSpendingPill.setGood(true);
        currentSpendingPill.displaySpendingTextForPeriod(model.getTotalSpend(), model.getPeriodHierarchy());

        var inboundSpendTrendIndicator = this.down('#inboundSpendTrendIndicator');
        inboundSpendTrendIndicator.configure({
            priorValue: model.getPriorInboundSpend(),
            currentValue: model.getInboundSpend(),
            priorValueText: Jda.SCExecutive.util.Formatters.MetricFormatter.formatCurrency(model.getPriorInboundSpend()),
            currentValueText: Jda.SCExecutive.util.Formatters.MetricFormatter.formatCurrency(model.getInboundSpend()),
            currentPeriodHierarchy: model.getPeriodHierarchy()
        });

        var outboundSpendTrendIndicator = this.down('#outboundSpendTrendIndicator');
        outboundSpendTrendIndicator.configure({
            priorValue: model.getPriorOutboundSpend(),
            currentValue: model.getOutboundSpend(),
            priorValueText: Jda.SCExecutive.util.Formatters.MetricFormatter.formatCurrency(model.getPriorOutboundSpend()),
            currentValueText: Jda.SCExecutive.util.Formatters.MetricFormatter.formatCurrency(model.getOutboundSpend()),
            currentPeriodHierarchy: model.getPeriodHierarchy()
        });
    }
});
