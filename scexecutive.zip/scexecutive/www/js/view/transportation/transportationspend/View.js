Ext.define('Jda.SCExecutive.view.Transportation.TransportationSpend.View', {
    extend: 'Ext.Panel',
    xtype: 'transportationspendpanel',

    config: {
        layout: 'vbox',
        items: [{
            layout: 'hbox',
            items: [{
                xtype: 'label',
                cls: 'title-container',
                html: '<span class="title">' + Jda.getMessage('jda.scexecutive.transportationspend.Title') + '</span>'
            }, {
                flex: 1 // spacer
            }, {
                xtype: 'tabselector',
                itemId: 'transportationfilter',
                tabs: [
                    Jda.getMessage('jda.scexecutive.transportationspend.Total'),
                    Jda.getMessage('jda.scexecutive.transportationspend.Inbound'),
                    Jda.getMessage('jda.scexecutive.transportationspend.Outbound')
                ]
            }]
        }, {
            flex: 1,
            layout: 'hbox',
            padding: '20 0 40',
            items: [{
                width: 200,
                layout: {
                    type: 'vbox'
                },
                cls: 'transportation-spend-metrics',
                items: [{
                    layout: 'hbox',
                    padding: 10,
                    items: [{
                        flex: 1
                    }, {
                        xtype: 'horsepill',
                        width: 150,
                        layout: 'vbox',
                        itemId: 'spentThisPeriodHorsePill'
                    }, {
                        flex: 1
                    }]
                }, {
                    xtype: 'metricstat',
                    itemId: 'transSpendBudgetStat',
                    qualifierText: Jda.getMessage('jda.scexecutive.transportationspend.BudgetLabel'),
                    padding: '0 0 10px'
                }, {
                    xtype: 'metricstat',
                    itemId: 'transSpendSpentStat',
                    qualifierText: Jda.getMessage('jda.scexecutive.transportationspend.SpentLabel'),
                    padding: '0 0 10px'
                }, {
                    xtype: 'metricstat',
                    itemId: 'transSpendRemainingStat',
                    qualifierText: Jda.getMessage('jda.scexecutive.transportationspend.RemainingLabel')
                }]
            }, {
                xtype: 'transportationspendchart',
                flex: 1
            }]
        }, {
            xtype: 'progressbar',
            style: 'padding-bottom: 20px'
        }]
    },

    loadFromModel: function(model, selectedTabIndex) {
        var budgetSpend, budget, periodSpend;

        if (selectedTabIndex === Jda.SCExecutive.view.Transportation.View.TOTAL_TAB_INDEX) {
            periodSpend = model.getTotalSpend();
            budgetSpend = model.getTotalBudgetSpend();
            budget = model.getTotalBudget();
        }
        else if (selectedTabIndex === Jda.SCExecutive.view.Transportation.View.INBOUND_TAB_INDEX) {
            periodSpend = model.getInboundSpend();
            budgetSpend = model.getInboundBudgetSpend();
            budget = model.getInboundBudget();
        }
        else if (selectedTabIndex === Jda.SCExecutive.view.Transportation.View.OUTBOUND_TAB_INDEX) {
            periodSpend = model.getOutboundSpend();
            budgetSpend = model.getOutboundBudgetSpend();
            budget = model.getOutboundBudget();
        }

        var progressBar = this.down('progressbar');
        progressBar.updatePeriodHierarchy(model.getPeriodHierarchy());
        progressBar.updateValues(budgetSpend, budget);

        var currentSpendingPill = this.down('#spentThisPeriodHorsePill');
        currentSpendingPill.setGood(true); // No target, always good
        currentSpendingPill.displaySpendingTextForPeriod(periodSpend, model.getPeriodHierarchy());

        var budgetStat = this.down('#transSpendBudgetStat');
        budgetStat.updateValueText(Jda.SCExecutive.util.Formatters.MetricFormatter.formatCurrency(budget));

        var spentStat = this.down('#transSpendSpentStat');
        spentStat.updateValueText(Jda.SCExecutive.util.Formatters.MetricFormatter.formatCurrency(budgetSpend));

        var isGood = budgetSpend <= budget;
        var remainingValueStat= this.down('#transSpendRemainingStat');
        remainingValueStat.setGood(isGood);

        if (isGood) {
            remainingValueStat.updateValueText(Jda.SCExecutive.util.Formatters.MetricFormatter.formatCurrency(budget - budgetSpend));
            remainingValueStat.setQualifierText(Jda.getMessage('jda.scexecutive.transportationspend.RemainingLabel'));
        }
        else {
            remainingValueStat.updateValueText(Jda.SCExecutive.util.Formatters.MetricFormatter.formatCurrency(budgetSpend - budget));
            remainingValueStat.setQualifierText(Jda.getMessage('jda.scexecutive.transportationspend.OverLabel'));
        }

        var chart = this.down('transportationspendchart');
        chart.setSelectedTabIndex(selectedTabIndex);
        chart.loadFromModel(model);
    }
});
