Ext.define('Jda.SCExecutive.view.Transportation.TransportationSpend.Chart', {
    extend: 'Jda.SCExecutive.chart.LocationBarChart',
    xtype: 'transportationspendchart',

    config: {
        selectedTabIndex: Jda.SCExecutive.view.Transportation.View.TOTAL_TAB_INDEX
    },

    getTotalField: function() {
        return 'totalSpend';
    },

    getDateField: function() {
        return 'periodHierarchy';
    },

    getStoreFromModel: function(model) {
        switch (this.getSelectedTabIndex()) {
            case Jda.SCExecutive.view.Transportation.View.TOTAL_TAB_INDEX: return model.getTotalStore();
            case Jda.SCExecutive.view.Transportation.View.INBOUND_TAB_INDEX: return model.getInboundStore();
            case Jda.SCExecutive.view.Transportation.View.OUTBOUND_TAB_INDEX: return model.getOutboundStore();
        }
    },

    getAggregatedMinimumFromModel: function(model) {
        return model.getTotalMinimumValue();
    },

    getAggregatedMaximumFromModel: function(model) {
        return model.getTotalMaximumValue();
    },

    getMinimumForLocationsFromModel: function(model) {
        switch (this.getSelectedTabIndex()) {
            case Jda.SCExecutive.view.Transportation.View.TOTAL_TAB_INDEX: return model.getTotalMinimumLocationValue();
            case Jda.SCExecutive.view.Transportation.View.INBOUND_TAB_INDEX: return model.getInboundMinimumValue();
            case Jda.SCExecutive.view.Transportation.View.OUTBOUND_TAB_INDEX: return model.getOutboundMinimumValue();
        }
    },

    getMaximumForLocationsFromModel: function(model) {
        switch (this.getSelectedTabIndex()) {
            case Jda.SCExecutive.view.Transportation.View.TOTAL_TAB_INDEX: return model.getTotalMaximumLocationValue();
            case Jda.SCExecutive.view.Transportation.View.INBOUND_TAB_INDEX: return model.getInboundMaximumValue();
            case Jda.SCExecutive.view.Transportation.View.OUTBOUND_TAB_INDEX: return model.getOutboundMaximumValue();
        }
    },

    getLocationHierarchiesFromModel: function(model) {
        switch (this.getSelectedTabIndex()) {
            case Jda.SCExecutive.view.Transportation.View.TOTAL_TAB_INDEX: return model.getTotalLocationHierarchies();
            case Jda.SCExecutive.view.Transportation.View.INBOUND_TAB_INDEX: return model.getInboundLocationHierarchies();
            case Jda.SCExecutive.view.Transportation.View.OUTBOUND_TAB_INDEX: return model.getOutboundLocationHierarchies();
        }
    },

    getPeriodHierarchyFromModel: function(model) {
        return model.getPeriodHierarchy();
    }
});
