Ext.define('Jda.SCExecutive.view.Transportation.PartyLoads.View', {
    extend: 'Ext.Container',
    xtype: 'partyloadspanel',

    config: {
        cls: 'main-metric-panel',
        layout: 'hbox',

        // the horse pills in the layout below are nested 2 levels deep to workaround an issue where
        // nested box layouts (in this case the container, and then the pill itself) causes the inner
        // box layout to ignore padding... causing the horse pills to look messed up.

        items: [{
            flex: 1,
            layout: {
                type: 'vbox',
                pack: 'center'
            },
            padding: '0 0 0 30',
            items: [{
                items: [{
                    xtype: 'horsepill',
                    itemId: 'loadsPill',
                    width: 135,
                    detailText: Jda.getMessage('jda.scexecutive.partyloads.LoadsLabel'),
                    good: true
                }]
            }]
        }, {
            flex: 1,
            layout: {
                type: 'vbox',
                pack: 'center'
            },
            padding: '0 30 0 0',
            items: [{
                xtype: 'metricstat',
                itemId: 'averageCostStat',
                margin: '0 0 15 0',
                qualifierText: Jda.getMessage('jda.scexecutive.partyloads.AverageCostLabel')
            }, {
                xtype: 'metricstat',
                itemId: 'averageValueStat',
                qualifierText: Jda.getMessage('jda.scexecutive.partyloads.AverageValueLabel')
            }]
        }, {
            xtype: 'component',
            cls: 'metric-divider-vertical'
        }, {
            flex: 1,
            layout: {
                type: 'vbox',
                pack: 'center'
            },
            padding: '0 0 0 30',
            items: [{
                items: [{
                    xtype: 'horsepill',
                    itemId: 'partiesPill',
                    width: 135,
                    detailText: Jda.getMessage('jda.scexecutive.partyloads.PartiesLabel'),
                    good: true
                }]
            }]
        }, {
            flex: 1,
            layout: {
                type: 'vbox',
                pack: 'center'
            },
            padding: '0 30 0 0',
            defaults: {
                margin: '0 0 5 0'
            },
            items: [{
                xtype: 'metricstat',
                itemId: 'carriersStat',
                qualifierText: Jda.getMessage('jda.scexecutive.partyloads.CarriersLabel')
            }, {
                xtype: 'metricstat',
                itemId: 'customersStat',
                qualifierText: Jda.getMessage('jda.scexecutive.partyloads.CustomersLabel')
            }, {
                xtype: 'metricstat',
                itemId: 'suppliersStat',
                qualifierText: Jda.getMessage('jda.scexecutive.partyloads.SuppliersLabel')
            }]
        }]
    },

    loadFromModel: function(model, selectedTabIndex) {
        var loadsPill = this.down('#loadsPill');
        var averageCostStat = this.down('#averageCostStat');
        var averageValueStat = this.down('#averageValueStat');
        var partiesPill = this.down('#partiesPill');
        var carriersStat = this.down('#carriersStat');
        var customersStat = this.down('#customersStat');
        var suppliersStat = this.down('#suppliersStat');
        var formatter = Jda.SCExecutive.util.Formatters.MetricFormatter;

        if (selectedTabIndex === Jda.SCExecutive.view.Transportation.View.TOTAL_TAB_INDEX) {
            loadsPill.setText(formatter.formatNumber(model.getTotalLoads()));
            averageCostStat.setValueText(formatter.formatCurrency(model.getTotalAverageCost()));
            averageValueStat.setValueText(formatter.formatCurrency(model.getTotalAverageValue()));
            partiesPill.setText(formatter.formatNumber(model.getTotalParties()));
            carriersStat.setValueText(formatter.formatNumber(model.getTotalCarriers()));
            customersStat.setValueText(formatter.formatNumber(model.getTotalCustomers()));
            suppliersStat.setValueText(formatter.formatNumber(model.getTotalSuppliers()));

            customersStat.show();
            suppliersStat.show();
        }
        else if (selectedTabIndex === Jda.SCExecutive.view.Transportation.View.INBOUND_TAB_INDEX) {
            loadsPill.setText(formatter.formatNumber(model.getInboundLoads()));
            averageCostStat.setValueText(formatter.formatCurrency(model.getInboundAverageCost()));
            averageValueStat.setValueText(formatter.formatCurrency(model.getInboundAverageValue()));
            partiesPill.setText(formatter.formatNumber(model.getInboundParties()));
            carriersStat.setValueText(formatter.formatNumber(model.getInboundCarriers()));
            suppliersStat.setValueText(formatter.formatNumber(model.getInboundSuppliers()));

            customersStat.hide();
            suppliersStat.show();
        }
        else if (selectedTabIndex === Jda.SCExecutive.view.Transportation.View.OUTBOUND_TAB_INDEX) {
            loadsPill.setText(formatter.formatNumber(model.getOutboundLoads()));
            averageCostStat.setValueText(formatter.formatCurrency(model.getOutboundAverageCost()));
            averageValueStat.setValueText(formatter.formatCurrency(model.getOutboundAverageValue()));
            partiesPill.setText(formatter.formatNumber(model.getOutboundParties()));
            carriersStat.setValueText(formatter.formatNumber(model.getOutboundCarriers()));
            customersStat.setValueText(formatter.formatNumber(model.getOutboundCustomers()));

            customersStat.show();
            suppliersStat.hide();
        }
    }
});
