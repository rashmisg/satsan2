Ext.define('Jda.SCExecutive.view.Transportation.View', {
    extend: 'Ext.Panel',
    xtype: 'transportation',

    statics: {
        TOTAL_TAB_INDEX: 0,
        INBOUND_TAB_INDEX: 1,
        OUTBOUND_TAB_INDEX: 2
    },

    config: {
        cls: 'main-view',
        layout: {
            type: 'vbox'
        },
        items: [{
            xtype: 'contextcontainer'
        }, {
            cls: 'main-metric-panel',
            flex: 1,
            layout: 'vbox',
            items: [{
                flex: 5,
                xtype: 'transportationspendpanel'
            }, {
                xtype: 'component',
                cls: 'metric-divider-horizontal'
            }, {
                flex: 4,
                xtype: 'transontimedeliverypanel'
            }]
        }, {
            xtype: 'partyloadspanel',
            height: 130
        }, {
            xtype: 'legendcontainer'
        }]
    }
});
