Ext.define('Jda.SCExecutive.view.Transportation.OnTimeDelivery.Chart', {
    extend: 'Jda.SCExecutive.chart.LocationBarChart',
    xtype: 'transportationontimedeliverychart',

    config: {
        axes: [
            Jda.SCExecutive.chart.AxisConfig.percentYAxisConfig(),
            Jda.SCExecutive.chart.AxisConfig.barXAxisConfig()
        ],
        selectedTabIndex: Jda.SCExecutive.view.Transportation.View.TOTAL_TAB_INDEX,

        yAxisMinimum: 0,
        yAxisMaximum: 100
    },

    getDateField: function() {
        return 'periodHierarchy';
    },

    getStoreFromModel: function(model) {
        var store;
        switch (this.getSelectedTabIndex()) {
            case Jda.SCExecutive.view.Transportation.View.TOTAL_TAB_INDEX: store = model.getTotalStore(); break;
            case Jda.SCExecutive.view.Transportation.View.INBOUND_TAB_INDEX: store = model.getInboundStore(); break;
            case Jda.SCExecutive.view.Transportation.View.OUTBOUND_TAB_INDEX: store = model.getOutboundStore(); break;
        }

        return store;
    },

    getMinimumForLocationsFromModel: function(model) {
        switch (this.getSelectedTabIndex()) {
            case Jda.SCExecutive.view.Transportation.View.TOTAL_TAB_INDEX: return model.getTotalLowestValue();
            case Jda.SCExecutive.view.Transportation.View.INBOUND_TAB_INDEX: return model.getInboundLowestValue();
            case Jda.SCExecutive.view.Transportation.View.OUTBOUND_TAB_INDEX: return model.getOutboundLowestValue();
        }
    },

    getMaximumForLocationsFromModel: function(model) {
        switch (this.getSelectedTabIndex()) {
            case Jda.SCExecutive.view.Transportation.View.TOTAL_TAB_INDEX: return model.getTotalHighestValue();
            case Jda.SCExecutive.view.Transportation.View.INBOUND_TAB_INDEX: return model.getInboundHighestValue();
            case Jda.SCExecutive.view.Transportation.View.OUTBOUND_TAB_INDEX: return model.getOutboundHighestValue();
        }
    },

    getLocationHierarchiesFromModel: function(model) {
        var locationFields;
        switch (this.getSelectedTabIndex()) {
            case Jda.SCExecutive.view.Transportation.View.TOTAL_TAB_INDEX: locationFields = model.getTotalLocationHierarchies(); break;
            case Jda.SCExecutive.view.Transportation.View.INBOUND_TAB_INDEX: locationFields = model.getInboundLocationHierarchies(); break;
            case Jda.SCExecutive.view.Transportation.View.OUTBOUND_TAB_INDEX: locationFields = model.getOutboundLocationHierarchies(); break;
        }

        return locationFields;
    },

    getPeriodHierarchyFromModel: function(model) {
        return model.getPeriodHierarchy();
    },

    // Add in the series for the target threshold
    applySeries: function(newSeries) {
        if (newSeries.length > 0) {
            newSeries.unshift({
                type: 'threshold',
                style: {
                    stroke: Jda.SCExecutive.constant.Colors.chartThresholdSeriesStroke,
                    lineWidth: 1.5
                },
                xField: 'periodHierarchy',
                yField: 'target'
            });
        }

        return this.callParent(arguments);
    }
});
