Ext.define('Jda.SCExecutive.view.Transportation.OnTimeDelivery.View', {
    extend: 'Ext.Panel',
    xtype: 'transontimedeliverypanel',

    config: {
        layout: 'vbox',
        items: [{
            xtype: 'label',
            cls: 'title-container',
            html: '<span class="title">' + Jda.getMessage('jda.scexecutive.ontimedelivery.Title') + '</span>'
        }, {
            flex: 1,
            layout: 'hbox',
            items: [{
                xtype: 'horsepill',
                margin: 30,
                width: 155,
                itemId: 'transotdaverageforperiodpill'
            }, {
                xtype: 'transportationontimedeliverychart',
                flex: 1
            }]
        }]
    },

    loadFromModel: function(model, selectedTabIndex) {
        var prefix;

        switch (selectedTabIndex) {
            case Jda.SCExecutive.view.Transportation.View.TOTAL_TAB_INDEX: prefix = 'getTotal'; break;
            case Jda.SCExecutive.view.Transportation.View.INBOUND_TAB_INDEX: prefix = 'getInbound'; break;
            case Jda.SCExecutive.view.Transportation.View.OUTBOUND_TAB_INDEX: prefix = 'getOutbound'; break;
        }

        var percentField = prefix + 'OnTimePercent';
        var percent = model[percentField]();
        var targetField = prefix + 'OnTimeTarget';
        var target = model[targetField]();
        var isGood = target === undefined || percent >= target; // Good if no target, or average is greater than or equal to threshold
        var periodHierarchy = model.getPeriodHierarchy();
        var showWeekEndingLabel = periodHierarchy.get('type') === Jda.SCExecutive.model.PeriodHierarchy.types.MONTH;

        var averagePill = this.down('#transotdaverageforperiodpill');
        averagePill.setGood(isGood);
        averagePill.displayAverageTextForPeriod(percent, periodHierarchy);

        var chart = this.down('transportationontimedeliverychart');
        chart.setSelectedTabIndex(selectedTabIndex);
        chart.loadFromModel(model);

        var bottomAxis = chart.getAxes()[1];
        bottomAxis.setShowWeekEndingLabel(showWeekEndingLabel);
    }
});
