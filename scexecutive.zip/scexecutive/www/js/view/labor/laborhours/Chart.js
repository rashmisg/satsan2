Ext.define('Jda.SCExecutive.view.Labor.LaborHours.Chart', {
    extend: 'Jda.SCExecutive.chart.CartesianChart',
    xtype: 'laborhourschart',

    config: {
        animate: false,
        store: {
            fields: [ 'locationHierarchy', 'hours', 'overtimeHours' ]
        },
        axes: [
            Jda.SCExecutive.chart.AxisConfig.unitYAxisConfig({
                minimum: 0
            }),
            Jda.SCExecutive.chart.AxisConfig.emptyXAxisConfig()
        ]
    },

    loadFromModel: function(model) {
        var store = model.getStore();
        var series = this._buildSeriesArray(store);

        this._adjustYAxisConfig(model.getLowestValue(), model.getHighestValue());

        this.bindStore(store);
        this.setSeries(series);

        this.callParent(arguments);
    },

    performLayout: function() {
        this._adjustBarWidth();

        this.callParent(arguments);
    },

    _buildSeriesArray: function(store) {
        var baseConfig = {
            stacked: false,
            type: 'bar',
            xField: 'locationHierarchy',
            renderer: function(sprite, barAttr, storeObj, index) {
                var locationHierarchy = storeObj.store.getAt(index).get('locationHierarchy');
                if (locationHierarchy) {
                    barAttr.fill = locationHierarchy.getColor();
                }
                return barAttr;
            },
            style: {
                inGroupGapWidth: 0
            }
        };

        var series = [ 
            Ext.Object.merge({
                yField: 'hours',
                style: {
                    fillOpacity: Jda.SCExecutive.constant.Colors.chartSeriesDefaultOpacity
                }
            }, baseConfig),
            Ext.Object.merge({
                yField: 'overtimeHours',
                style: {
                    fillOpacity: 0.5
                }
            }, baseConfig)
        ];

        return series;
    },

    _adjustBarWidth: function() {
        var store = this.getStore();
        var series = this.getSeries();
        var barWidth = Jda.SCExecutive.chart.BarWidthCalculator.calculateBarWidthForChart(this, series.length, store.getCount());

        Ext.each(series, function(seriesItem) {
            var sprite = seriesItem.getSprites()[0];

            sprite.setAttributes({
                maxBarWidth: barWidth,
                minBarWidth: barWidth
            });
        });
    },

    _adjustYAxisConfig: function(lowestValue, highestValue) {
        var config = Jda.SCExecutive.util.Renderers.getAdjustedLineChartYAxisConfig({
            lowestValue: lowestValue,
            highestValue: highestValue
        });
        var yAxis = this.getAxes()[0];

        yAxis.setMinimum(config.minimum);
        yAxis.setMaximum(config.maximum);
        yAxis.setMajorTickSteps(config.majorTickSteps);
    }
});
