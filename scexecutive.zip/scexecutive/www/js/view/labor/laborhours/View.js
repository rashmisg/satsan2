Ext.define('Jda.SCExecutive.view.Labor.LaborHours.View', {
    extend: 'Ext.Panel',
    xtype: 'laborhoursview',

    config: {
        cls: 'sub-metric-panel',
        layout: 'vbox',
        items: [{
            xtype: 'label',
            cls: 'title-container',
            html: '<span class="title">' + Jda.getMessage('jda.scexecutive.laborhours.Title') + '</span>'
        }, {
            flex: 1,
            xtype: 'laborhourschart'
        }, {
            layout: {
                type: 'hbox',
                pack: 'center'
            },
            items: [{
                padding: '0 25px 0 0',
                itemId: 'regularHoursTrendIndicator',
                xtype: 'trendindicator',
                iconSide: Jda.SCExecutive.component.TrendIndicator.ICON_LEFT,
                labelText: Jda.getMessage('jda.scexecutive.laborhours.Regular')
            }, {
                itemId: 'overtimeHoursTrendIndicator',
                xtype: 'trendindicator',
                iconSide: Jda.SCExecutive.component.TrendIndicator.ICON_LEFT,
                labelText: Jda.getMessage('jda.scexecutive.laborhours.Overtime'),
                cls: 'labor-hours-overtime-trend'
            }]
        }, {
            xtype: 'component',
            cls: 'metric-divider-horizontal'
        }, {
            xtype: 'label',
            cls: 'title-container',
            html: '<span class="secondary-title">' + Jda.getMessage('jda.scexecutive.laborhours.LaborHoursDetails') + '</span>'
        }, {
            xtype: 'scexecutivegrid',
            flex: 1,
            columns: [{
                text: Jda.getMessage('jda.scexecutive.laborhours.Region'),
                dataIndex: 'locationHierarchy',
                width: '28%',
                renderer: function(value) {
                    var color = value.getColor();
                    var name = Ext.String.htmlEncode(value.get('name'));

                    return Ext.String.format('<div class="forecast-accuracy-legend-item" style="background-color: {0};"></div>{1}', color, name);
                }
            }, {
                text: Jda.getMessage('jda.scexecutive.laborhours.Hours'),
                dataIndex: 'hours',
                width: '16%',
                renderer: function(value) {
                    return Jda.SCExecutive.util.Formatters.MetricFormatter.formatNumber(value, Jda.SCExecutive.constant.Precision.Medium, true);
                }
            }, {
                text: Jda.getMessage('jda.scexecutive.laborhours.Spend'),
                dataIndex: 'spend',
                width: '16%',
                renderer: function(value) {
                    return Jda.SCExecutive.util.Formatters.MetricFormatter.formatCurrency(value, Jda.SCExecutive.constant.Precision.Medium, true);
                }
            }, {
                text: Jda.getMessage('jda.scexecutive.laborhours.OvertimeHours'),
                dataIndex: 'overtimeHours',
                width: '20%',
                renderer: function(value) {
                    return Jda.SCExecutive.util.Formatters.MetricFormatter.formatNumber(value, Jda.SCExecutive.constant.Precision.Medium, true);
                }
            }, {
                text: Jda.getMessage('jda.scexecutive.laborhours.OvertimeSpend'),
                dataIndex: 'overtimeSpend',
                width: '20%',
                renderer: function(value) {
                    return Jda.SCExecutive.util.Formatters.MetricFormatter.formatCurrency(value, Jda.SCExecutive.constant.Precision.Medium, true);
                }
            }]
        }]
    },

    loadFromModel: function(model) {
        var chart = this.down('laborhourschart');
        chart.loadFromModel(model);
        
        var regularHoursTrendIndicator = this.down('#regularHoursTrendIndicator');
        regularHoursTrendIndicator.configure({
            priorValue: model.getPriorTotalRegularHours(),
            currentValue: model.getTotalRegularHours(),
            priorValueText: Jda.SCExecutive.util.Formatters.MetricFormatter.formatNumber(model.getPriorTotalRegularHours(), Jda.SCExecutive.constant.Precision.Medium),
            currentValueText: Jda.SCExecutive.util.Formatters.MetricFormatter.formatNumber(model.getTotalRegularHours(), Jda.SCExecutive.constant.Precision.Medium),
            currentPeriodHierarchy: model.getPeriodHierarchy()
        });

        var overtimeHoursTrendIndicator = this.down('#overtimeHoursTrendIndicator');
        overtimeHoursTrendIndicator.configure({
            priorValue: model.getPriorTotalOvertimeHours(),
            currentValue: model.getTotalOvertimeHours(),
            priorValueText: Jda.SCExecutive.util.Formatters.MetricFormatter.formatNumber(model.getPriorTotalOvertimeHours(), Jda.SCExecutive.constant.Precision.Medium),
            currentValueText: Jda.SCExecutive.util.Formatters.MetricFormatter.formatNumber(model.getTotalOvertimeHours(), Jda.SCExecutive.constant.Precision.Medium),
            currentPeriodHierarchy: model.getPeriodHierarchy()
        });

        var grid = this.down('scexecutivegrid');
        grid.setStore(model.getStore());
    }
});
