Ext.define('Jda.SCExecutive.view.Labor.LaborSpend.MaximizedView', {
    extend: 'Ext.Panel',

    config: {
        cls: 'expanded-metric-panel',
        layout: 'vbox',
        flex: 1,
        items: [{
            xtype: 'label',
            cls: 'title-container',
            html: '<span class="title">' + Jda.getMessage('jda.scexecutive.laborspend.Title') + '</span>'
        }, {
            layout: 'hbox',
            padding: '15px 0',
            items: [{
                flex: 1
            }, {
                xtype: 'horsepill',
                width: 150,
                layout: 'vbox',
                itemId: 'laborSpendPill'
            }, {
                xtype: 'metricstat',
                itemId: 'laborSpendBudgetStat',
                qualifierText: Jda.getMessage('jda.scexecutive.laborspend.Budget'),
                flex: 3
            }, {
                xtype: 'metricstat',
                itemId: 'laborSpendSpentStat',
                qualifierText: Jda.getMessage('jda.scexecutive.laborspend.Spent'),
                flex: 3
            }, {
                xtype: 'metricstat',
                itemId: 'laborSpendRemainingStat',
                qualifierText: Jda.getMessage('jda.scexecutive.laborspend.Remaining'),
                flex: 3
            }, {
                flex: 1
            }]
        }, {
            xtype: 'laborspendchart',
            flex: 1,
            isMaximized: true
        }, {
            xtype: 'progressbar'
        }]
    },

    loadFromModel: function(model) {
        var chart = this.down('laborspendchart');
        chart.loadFromModel(model);

        var spend = model.getLaborSpend();
        var budgetSpend = model.getLaborBudgetSpend();
        var budget = model.getLaborBudget();

        var laborSpendPill = this.down('#laborSpendPill');
        laborSpendPill.setGood(true);
        laborSpendPill.displaySpendingTextForPeriod(spend, model.getPeriodHierarchy());

        var progressBar = this.down('progressbar');
        progressBar.updatePeriodHierarchy(model.getPeriodHierarchy());
        progressBar.updateValues(budgetSpend, budget);

        var spendStat = this.down('#laborSpendSpentStat');
        spendStat.updateValueText(Jda.SCExecutive.util.Formatters.MetricFormatter.formatCurrency(budgetSpend));

        var budgetStat = this.down('#laborSpendBudgetStat');
        budgetStat.updateValueText(Jda.SCExecutive.util.Formatters.MetricFormatter.formatCurrency(budget));

        var isUnderBudget = budgetSpend <= budget;
        var remainingValueStat = this.down('#laborSpendRemainingStat');
        remainingValueStat.setGood(isUnderBudget);

        if (isUnderBudget) {
            remainingValueStat.updateValueText(Jda.SCExecutive.util.Formatters.MetricFormatter.formatCurrency(budget - budgetSpend));
            remainingValueStat.setQualifierText(Jda.getMessage('jda.scexecutive.transportationspend.RemainingLabel'));
        }
        else {
            remainingValueStat.updateValueText(Jda.SCExecutive.util.Formatters.MetricFormatter.formatCurrency(budgetSpend - budget));
            remainingValueStat.setQualifierText(Jda.getMessage('jda.scexecutive.transportationspend.OverLabel'));
        }
    }
});
