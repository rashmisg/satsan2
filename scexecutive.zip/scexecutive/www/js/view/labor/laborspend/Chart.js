Ext.define('Jda.SCExecutive.view.Labor.LaborSpend.Chart', {
    extend: 'Jda.SCExecutive.chart.LocationBarChart',
    xtype: 'laborspendchart',

    getTotalField: function() {
        return 'total';
    },

    getDateField: function() {
        return 'periodHierarchy';
    },

    getStoreFromModel: function(model) {
        return model.getLaborByPeriodStore();
    },

    getAggregatedMinimumFromModel: function(model) {
        return model.getMinimumTotalValue();
    },

    getAggregatedMaximumFromModel: function(model) {
        return model.getMaximumTotalValue();
    },

    getMinimumForLocationsFromModel: function(model) {
        return model.getMinimumLocationValue();
    },

    getMaximumForLocationsFromModel: function(model) {
        return model.getMaximumLocationValue();
    },

    getLocationHierarchiesFromModel: function(model) {
        return model.getLocationHierarchies();
    },

    getPeriodHierarchyFromModel: function(model) {
        return model.getPeriodHierarchy();
    }
});
