Ext.define('Jda.SCExecutive.view.Labor.LaborPerformance.View', {
    extend: 'Ext.Panel',
    xtype: 'laborperformanceview',

    config: {
        cls: 'sub-metric-panel',
        layout: 'vbox',
        items: [{
            layout: 'hbox',
            items:[{
                xtype: 'label',
                cls: 'title-container',
                html: '<span class="title">' + Jda.getMessage('jda.scexecutive.laborperformance.Title') + '</span>'
            }, {
                flex: 1 //spacer
            }, {
                xtype: 'pill',
                itemId: 'hoursPill'
            }]
        }, {
            layout: 'hbox',
            flex: 1,
            items: [{
                xtype: 'laborperformancechart',
                flex: 1,
                margin: '0 0 0 10'
            }, {
                layout: 'vbox',
                width: 160,
                margin: '25 0 25 0',
                defaults: {
                    padding: '0 0 5 0'
                },
                items: [{
                    layout: 'hbox',
                    items: [{
                        width: 50,
                        xtype: 'label',
                        cls: 'labor-performance-hours-value-text',
                        itemId: 'totalDirectHoursLabel'
                    }, {
                        flex: 1,
                        cls: 'labor-performance-hours-label-text',
                        html: Jda.getMessage('jda.scexecutive.laborperformance.DirectHours')
                    }]
                }, {
                    layout: 'hbox',
                    items: [{
                        width: 50,
                        xtype: 'label',
                        cls: 'labor-performance-hours-value-text',
                        itemId: 'totalIndirectHoursLabel'
                    }, {
                        flex: 1,
                        cls: 'labor-performance-hours-label-text',
                        html: Jda.getMessage('jda.scexecutive.laborperformance.IndirectHours')
                    }]
                }, {
                    xtype: 'dataview',
                    itemId: 'categoryList',
                    scrollable: 'vertical',
                    flex: 1,
                    itemTpl:
                        '<div class="labor-performance-legend-item-wrapper">' + 
                            '<div class="labor-performance-legend-item" style="background-color: {color};"></div>' + 
                        '</div>' +
                        '<div class="labor-performance-hours-row-text">' +
                            '{[Ext.String.htmlEncode(values.category)]}' +
                        '</div>' +
                        '<div style="clear:both;"/>'
                }]
            }]
        }, {
            layout: {
                type: 'hbox',
                pack: 'center'
            },
            items: [{
                padding: '0 30px 0 0',
                itemId: 'performanceTrendIndicator',
                xtype: 'trendindicator',
                iconSide: Jda.SCExecutive.component.TrendIndicator.ICON_LEFT,
                labelText: Jda.getMessage('jda.scexecutive.laborperformance.TotalPerformance')
            }, {
                itemId: 'efficiencyTrendIndicator',
                xtype: 'trendindicator',
                iconSide: Jda.SCExecutive.component.TrendIndicator.ICON_LEFT,
                labelText: Jda.getMessage('jda.scexecutive.laborperformance.TotalEfficiency')
            }]
        }, {
            xtype: 'component',
            cls: 'metric-divider-horizontal'
        }, {
            xtype: 'label',
            cls: 'title-container',
            html: '<span class="secondary-title">' + Jda.getMessage('jda.scexecutive.laborperformance.PerformanceDetails') + '</span>'
        }, {
            flex: 1,
            xtype: 'scexecutivegrid',
            columns: [{
                text: Jda.getMessage('jda.scexecutive.laborperformance.Category'),
                dataIndex: 'category',
                width: '36%',
                renderer: function(value) {
                    return Ext.String.htmlEncode(value);
                }
            }, {
                text: Jda.getMessage('jda.scexecutive.laborperformance.Hours'),
                dataIndex: 'hours',
                width: '17%',
                renderer: function(value) {
                    return Jda.SCExecutive.util.Formatters.MetricFormatter.formatNumber(value, Jda.SCExecutive.constant.Precision.Medium, true);
                }
            }, {
                text: Jda.getMessage('jda.scexecutive.laborperformance.UnitsPerHour'),
                dataIndex: 'unitsPerHour',
                width: '18%',
                renderer: function(value) {
                    return Jda.SCExecutive.util.Formatters.MetricFormatter.formatNumber(value, Jda.SCExecutive.constant.Precision.Medium, true);
                }
            }, {
                text: Jda.getMessage('jda.scexecutive.laborperformance.Performance'),
                dataIndex: 'performance',
                width: '29%',
                renderer: function(value) {
                    return Jda.SCExecutive.util.Formatters.MetricFormatter.formatPercent(value, Jda.SCExecutive.constant.Precision.Medium, true);
                }
            }]
        }]
    },

    loadFromModel: function(model) {
        var hoursPill = this.down('#hoursPill');
        var formattedHours = Jda.SCExecutive.util.Formatters.MetricFormatter.formatNumber(model.getTotalHours(), Jda.SCExecutive.constant.Precision.Medium);
        hoursPill.setText('<span class="labor-performance-pill-value">' + formattedHours + '</span> <span class="labor-performance-pill-label">' + Jda.getMessage('jda.scexecutive.laborperformance.TotalHours') + '</span>');
        hoursPill.setGood(true); // Good guy hours pill, never red.

        var performanceTrendIndicator = this.down('#performanceTrendIndicator');
        performanceTrendIndicator.configure({
            priorValue: model.getPriorTotalPerformance(),
            currentValue: model.getTotalPerformance(),
            priorValueText: Jda.SCExecutive.util.Formatters.MetricFormatter.formatPercent(model.getPriorTotalPerformance(), Jda.SCExecutive.constant.Precision.Low),
            currentValueText: Jda.SCExecutive.util.Formatters.MetricFormatter.formatPercent(model.getTotalPerformance(), Jda.SCExecutive.constant.Precision.Low),
            currentPeriodHierarchy: model.getPeriodHierarchy()
        });

        var efficiencyTrendIndicator = this.down('#efficiencyTrendIndicator');
        efficiencyTrendIndicator.configure({
            priorValue: model.getPriorTotalEfficiency(),
            currentValue: model.getTotalEfficiency(),
            priorValueText: Jda.SCExecutive.util.Formatters.MetricFormatter.formatPercent(model.getPriorTotalEfficiency(), Jda.SCExecutive.constant.Precision.Low),
            currentValueText: Jda.SCExecutive.util.Formatters.MetricFormatter.formatPercent(model.getTotalEfficiency(), Jda.SCExecutive.constant.Precision.Low),
            currentPeriodHierarchy: model.getPeriodHierarchy()
        });

        var grid = this.down('scexecutivegrid');
        grid.setStore(model.getDirectPerformanceDetailsStore());

        var chart = this.down('laborperformancechart');
        chart.setColors(model.getColors());
        chart.bindStore(model.getTotalPerformanceDetailsStore());

        var categoryList = this.down('#categoryList');
        categoryList.setStore(model.getTotalPerformanceDetailsStore());

        var totalDirectHoursLabel = this.down('#totalDirectHoursLabel');
        var formattedTotalDirectHours = Jda.SCExecutive.util.Formatters.MetricFormatter.formatNumber(model.getTotalDirectHours(), Jda.SCExecutive.constant.Precision.Medium);
        totalDirectHoursLabel.setHtml(formattedTotalDirectHours);

        var totalIndirectHoursLabel = this.down('#totalIndirectHoursLabel');
        var formattedTotalIndirectHours = Jda.SCExecutive.util.Formatters.MetricFormatter.formatNumber(model.getTotalIndirectHours(), Jda.SCExecutive.constant.Precision.Medium);
        totalIndirectHoursLabel.setHtml(formattedTotalIndirectHours);
    }
});
