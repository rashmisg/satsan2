Ext.define('Jda.SCExecutive.view.Labor.LaborPerformance.Chart', {
    extend: 'Ext.chart.PolarChart',
    xtype: 'laborperformancechart',

    config: {
        animate: false,
        store: {
            fields: [ 'category', 'hours' ]
        },
        series: [{
            type: 'pie',
            rotation: -Math.PI / 2, // Start at the top
            xField: 'hours',
            style: {
                lineWidth: 2,
                strokeStyle: '#fff'
            }
        }]
    }
});
