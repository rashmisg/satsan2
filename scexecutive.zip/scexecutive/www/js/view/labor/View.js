Ext.define('Jda.SCExecutive.view.Labor.View', {
    extend: 'Ext.Panel',
    xtype: 'labor',

    config: {
        cls: 'main-view',
        layout: {
            type: 'vbox'
        },
        items: [{
            xtype: 'contextcontainer'
        }, {
            flex: 1,
            layout: 'fit',
            items: [{
                // wrapped in an additional layer so that all items are flexed equally...  the sub-metric-rows
                // have margin from the underlying widgets, but main-metric-panels don't have.
                xtype: 'laborspendview'
            }]
        }, {
            layout: 'hbox',
            cls: 'sub-metric-row',
            flex: 2,
            items: [{
                xtype: 'laborhoursview',
                flex: 1
            }, {
                xtype: 'laborperformanceview',
                flex: 1
            }]
        }, {
            xtype: 'legendcontainer'
        }]
    }
});
