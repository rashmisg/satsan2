Ext.define('Jda.SCExecutive.view.Inventory.InventoryValue.Chart', {
    extend: 'Jda.SCExecutive.chart.LocationPerformanceLineChart',
    xtype: 'inventoryvaluechart',

    config: {
        axes: [ Jda.SCExecutive.chart.AxisConfig.currencyYAxisConfig(), Jda.SCExecutive.chart.AxisConfig.lineXAxisConfig() ]
    },

    getAggregatedMinimumFromModel: function(model) {
        return model.getInventoryValueTotalMinimum();
    },

    getAggregatedMaximumFromModel: function(model) {
        return model.getInventoryValueTotalMaximum();
    },

    getMinimumForLocationsFromModel: function(model) {
        return model.getInventoryValueMinimum();
    },

    getMaximumForLocationsFromModel: function(model) {
        return model.getInventoryValueMaximum();
    },

    shouldPlotTargetSeries: function(model) {
        return false;
    }
});
