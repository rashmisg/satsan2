Ext.define('Jda.SCExecutive.view.Inventory.InventoryValue.View', {
    extend: 'Ext.Panel',
    xtype: 'inventoryinventoryvalueview',

    config: {
        layout: 'vbox',
        cls: 'sub-metric-panel',
        items: [{
            xtype: 'label',
            cls: 'title-container',
            html: '<span class="title">' + Jda.getMessage('jda.scexecutive.inventoryvalue.Title') + '</span>'
        }, {
            flex: 1,
            xtype: 'inventoryvaluechart'
        }, {
            layout: {
                type: 'hbox',
                pack: 'center'
            },
            padding: '0 0 10px',
            items: [{
                padding: '0 15px 0 0',
                itemId: 'averageInventoryValueTrendIndicator',
                xtype: 'trendindicator',
                iconSide: Jda.SCExecutive.component.TrendIndicator.ICON_LEFT,
                labelText: Jda.getMessage('jda.scexecutive.inventoryvalue.AverageInventoryValueLabel')
            }, {
                itemId: 'averageUnitValueTrendIndicator',
                xtype: 'trendindicator',
                iconSide: Jda.SCExecutive.component.TrendIndicator.ICON_LEFT,
                labelText: Jda.getMessage('jda.scexecutive.inventoryvalue.AverageUnitValueLabel')
            }]
        }],
        plugins: [ 'maximize' ],

        model: null
    },

    loadFromModel: function(model) {
        var chart = this.down('inventoryvaluechart');
        chart.loadFromModel(model);

        var averageInventoryValueTrendIndicator = this.down('#averageInventoryValueTrendIndicator');
        averageInventoryValueTrendIndicator.configure({
            priorValue: model.getPriorAverageInventoryValue(),
            currentValue: model.getAverageInventoryValue(),
            priorValueText: Jda.SCExecutive.util.Formatters.MetricFormatter.formatCurrency(model.getPriorAverageInventoryValue(), Jda.SCExecutive.constant.Precision.Medium),
            currentValueText: Jda.SCExecutive.util.Formatters.MetricFormatter.formatCurrency(model.getAverageInventoryValue(), Jda.SCExecutive.constant.Precision.Medium),
            currentPeriodHierarchy: model.getPeriodHierarchy()
        });

        var averageUnitValueTrendIndicator = this.down('#averageUnitValueTrendIndicator');
        averageUnitValueTrendIndicator.configure({
            priorValue: model.getPriorAverageUnitValue(),
            currentValue: model.getAverageUnitValue(),
            priorValueText: Jda.SCExecutive.util.Formatters.MetricFormatter.formatCurrency(model.getPriorAverageUnitValue(), Jda.SCExecutive.constant.Precision.Medium),
            currentValueText: Jda.SCExecutive.util.Formatters.MetricFormatter.formatCurrency(model.getAverageUnitValue(), Jda.SCExecutive.constant.Precision.Medium),
            currentPeriodHierarchy: model.getPeriodHierarchy()
        });

        this.setModel(model);
    },

    getMaximizedView: function() {
        var maximizedView = Ext.create('Jda.SCExecutive.view.Inventory.InventoryValue.MaximizedView');

        maximizedView.loadFromModel(this.getModel());

        return maximizedView;
    }
});
