Ext.define('Jda.SCExecutive.view.Inventory.AverageDaysOfSupply.Chart', {
    extend: 'Jda.SCExecutive.chart.CartesianChart',
    xtype: 'inventoryaveragedaysofsupplychart',

    config: {
        animate: false,
        store: {
            fields: ['locationHierarchy', 'value']
        },

        axes: [ Jda.SCExecutive.chart.AxisConfig.emptyXAxisConfig(), Jda.SCExecutive.chart.AxisConfig.unitYAxisConfig() ],

        series: [{
            type: 'bar',
            xField: 'locationHierarchy',
            yField: 'value',
            renderer: function(sprite, barAttr, storeObj, index) {
                var locationHierarchy = storeObj.store.getAt(index).get('locationHierarchy');

                barAttr.fill = locationHierarchy.getColor();
                barAttr.fillOpacity = Jda.SCExecutive.constant.Colors.chartSeriesDefaultOpacity;

                return barAttr;
            }
        }],

        isMaximized: false
    },

    loadFromModel: function(model) {
        this.bindStore(model.getStore());

        this._adjustYAxisConfig(model.getLowestSupplyValue(), model.getHighestSupplyValue());

        // Since nothing is changing here (size, series), we have to force a layout
        this.scheduleLayout();
        this.callParent(arguments);
    },

    performLayout: function() {
        this._adjustBarWidth();

        this.callParent(arguments);
    },

    _adjustYAxisConfig: function(lowestValue, highestValue) {
        var config = Jda.SCExecutive.util.Renderers.getAdjustedLineChartYAxisConfig({
            lowestValue: lowestValue,
            highestValue: highestValue,
            hasDoubleTicks: this.getIsMaximized()
        });

        var yAxis = this.getAxes()[1];

        yAxis.setMinimum(config.minimum);
        yAxis.setMaximum(config.maximum);
        yAxis.setMajorTickSteps(config.majorTickSteps);
    },

    _adjustBarWidth: function() {
        var numberOfRecords = this.getStore().getCount();
        var barWidth = Jda.SCExecutive.chart.BarWidthCalculator.calculateBarWidthForChart(this, 1, numberOfRecords);
        var series = this.getSeries()[0];
        var sprite = series.getSprites()[0];

        sprite.setAttributes({
            maxBarWidth: barWidth,
            minBarWidth: barWidth
        });
    }
});
