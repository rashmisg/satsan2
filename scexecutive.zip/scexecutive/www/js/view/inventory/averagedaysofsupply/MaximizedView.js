Ext.define('Jda.SCExecutive.view.Inventory.AverageDaysOfSupply.MaximizedView', {
    extend: 'Ext.Panel',

    config: {
        layout: 'vbox',
        cls: 'expanded-metric-panel',
        items: [{
            xtype: 'label',
            cls: 'title-container',
            html: '<span class="title">' + Jda.getMessage('jda.scexecutive.averagedaysofsupply.Title') + '</span>'
        }, {
            flex: 1,
            xtype: 'inventoryaveragedaysofsupplychart',
            isMaximized: true
        }, {
            margin: '0 0 15px 0',
            layout: {
                type: 'hbox',
                pack: 'center'
            },
            items: [{
                itemId: 'supplyChainAverageTrendIndicator',
                xtype: 'trendindicator',
                iconSide: Jda.SCExecutive.component.TrendIndicator.ICON_LEFT,
                labelText: Jda.getMessage('jda.scexecutive.averagedaysofsupply.SupplyChainAverageLabel')
            }]
        }]
    },

    loadFromModel: function(model) {
        var chart = this.down('inventoryaveragedaysofsupplychart');
        chart.loadFromModel(model);

        var supplyChainAverageTrendIndicator = this.down('#supplyChainAverageTrendIndicator');
        supplyChainAverageTrendIndicator.configure({
            priorValue: model.getPriorSupplyChainAverage(),
            currentValue: model.getSupplyChainAverage(),
            priorValueText: Jda.SCExecutive.util.Formatters.MetricFormatter.formatNumber(model.getPriorSupplyChainAverage(), Jda.SCExecutive.constant.Precision.Medium),
            currentValueText: Jda.SCExecutive.util.Formatters.MetricFormatter.formatNumber(model.getSupplyChainAverage(), Jda.SCExecutive.constant.Precision.Medium),
            currentPeriodHierarchy: model.getPeriodHierarchy()
        });
    }
});
