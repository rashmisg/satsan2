Ext.define('Jda.SCExecutive.view.Inventory.View', {
    extend: 'Ext.Panel',
    xtype: 'inventory',

    config: {
        cls: 'main-view',
        layout: 'vbox',
        items: [{
            xtype: 'contextcontainer'
        }, {
            layout: 'hbox',
            cls: 'sub-metric-row',
            flex: 2,
            items: [{
                layout: 'vbox',
                flex: 1,
                items: [{
                    xtype: 'inventoryinventoryvalueview',
                    flex: 1
                }, {
                    xtype: 'inventoryaveragedaysofsupplyview',
                    flex: 1
                }]
            }, {
                layout: 'vbox',
                flex: 1,
                items: [{
                    xtype: 'inventorywarehouseutilizationview',
                    flex: 1
                }]
            }]
        }, {
            layout: 'hbox',
            flex: 1,
            cls: 'sub-metric-row',
            items: [{
                xtype: 'inventoryorderfillrateview',
                itemId: 'orderFillInboundView',
                isInbound: true,
                flex: 1
            }, {
                xtype: 'inventoryorderfillrateview',
                itemId: 'orderFillOutboundView',
                isInbound: false,
                flex: 1
            }]
        }, {
            xtype: 'legendcontainer'
        }]
    }
});
