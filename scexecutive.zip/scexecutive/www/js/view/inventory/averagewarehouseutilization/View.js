Ext.define('Jda.SCExecutive.view.Inventory.WarehouseUtilization.View', {
    extend: 'Ext.Panel',
    xtype: 'inventorywarehouseutilizationview',

    config: {
        layout: 'vbox',
        cls: 'sub-metric-panel',
        items: [{
            layout:'hbox',
            items:[{
                xtype: 'label',
                cls: 'title-container',
                html: '<span class="title">' + Jda.getMessage('jda.scexecutive.warehouseutilization.Title') + '</span>'
            }, {
                flex: 1 //spacer
            }, {
                xtype: 'pill',
                itemId: 'utilizationPill'
            }]
        }, {
            flex: 1,
            xtype: 'averagewarehouseutilizationchart',
            margin: '0 27px 0 0'
        }, {
            xtype: 'component',
            cls: 'metric-divider-horizontal'
        }, {
            xtype: 'label',
            cls: 'title-container',
            html: '<span class="secondary-title">' + Jda.getMessage('jda.scexecutive.warehouseutilization.UtilizationDetails') + '</span>'
        }, {
            flex: 1,
            xtype: 'scexecutivegrid',
            columns: [{
                text: Jda.getMessage('jda.scexecutive.warehouseutilization.Region'),
                dataIndex: 'locationHierarchy',
                width: '25%',
                renderer: function(locationHierarchy) {
                    var color = locationHierarchy.getColor();
                    var name = Ext.String.htmlEncode(locationHierarchy.get('name'));

                    return Ext.String.format('<div class="forecast-accuracy-legend-item" style="background-color: {0};"></div>{1}', color, name);
                }
            }, {
                text: Jda.getMessage('jda.scexecutive.warehouseutilization.Utilization'),
                dataIndex: 'utilization',
                width: '18%',
                renderer: function(value) {
                    return Jda.SCExecutive.util.Formatters.MetricFormatter.formatPercent(value, Jda.SCExecutive.constant.Precision.Low, true);
                }
            }, {
                text: Jda.getMessage('jda.scexecutive.warehouseutilization.Warehouses'),
                dataIndex: 'warehouses',
                width: '22%',
                renderer: function(value) {
                    return Jda.SCExecutive.util.Formatters.MetricFormatter.formatNumber(value, Jda.SCExecutive.constant.Precision.Low, true);
                }
            }, {
                text: Jda.getMessage('jda.scexecutive.warehouseutilization.InvQty'),
                dataIndex: 'invQuantity',
                width: '15%',
                renderer: function(value) {
                    return Jda.SCExecutive.util.Formatters.MetricFormatter.formatNumber(value, Jda.SCExecutive.constant.Precision.Medium, true);
                }
            }, {
                text: Jda.getMessage('jda.scexecutive.warehouseutilization.InvValue'),
                dataIndex: 'invValue',
                width: '20%',
                renderer: function(value) {
                    return Jda.SCExecutive.util.Formatters.MetricFormatter.formatCurrency(value, Jda.SCExecutive.constant.Precision.Medium, true);
                }
            }]
        }]
    },

    loadFromModel: function(model) {
        var utilizationPill = this.down('#utilizationPill');
        utilizationPill.setText(Jda.SCExecutive.util.Formatters.MetricFormatter.formatPercent(model.getUtilizationPercent()));
        utilizationPill.setGood(true); // always good

        var modelStore = model.getStore();
        var utilizationGrid = this.down('scexecutivegrid');
        utilizationGrid.setStore(modelStore);

        var chart = this.down('averagewarehouseutilizationchart');
        chart.loadFromModel(model);
    }
});
