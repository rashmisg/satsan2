Ext.define('Jda.SCExecutive.view.Inventory.AverageWarehouseUtilization.Chart', {
    extend: 'Jda.SCExecutive.chart.CartesianChart',
    xtype: 'averagewarehouseutilizationchart',

    config: {
        animate: false,
        flipXY: true,
        innerPadding: {
            left: 10,
            right: 10
        },
        // stubbed out store so that the series doesn't blow up
        store: {
            fields: [ 'locationHierarchy', 'utilization', 'trend' ],
            //sorters are reversed direction to accommodate the sencha bug
            sorters: [
                Jda.SCExecutive.util.Sorters.DisplayValueSorter.createSorter({
                    direction: 'ASC',
                    field: 'utilization',
                    precision: 0
                }),
                {
                    property: 'locationHierarchy',
                    direction: 'DESC'
                }
            ]
        },
        axes: [
            Jda.SCExecutive.chart.AxisConfig.emptyXAxisConfig({
                position: 'left',
                style: {
                    axisLine: false,
                    majorTickSize: 0,
                    hideLastGridLine: true
                }
            }),
            Jda.SCExecutive.chart.AxisConfig.percentYAxisConfig({
                position: 'bottom',
                style: {
                    majorTickSize: 0,
                    stroke: Jda.SCExecutive.constant.Colors.chartAxis,
                    hideLastGridLine: true
                },
                minimum: 0,
                maximum: 100,
                majorTickSteps: 4,
                renderer: function(label, layout) {
                    if (label === layout.majorTicks.min) {
                        return '';
                    }

                    return Jda.SCExecutive.util.Formatters.MetricFormatter.formatPercent(label, Jda.SCExecutive.constant.Precision.Low);
                }
            })
        ],
        series: [{
            type: 'trend',
            xField: 'locationHierarchy',
            yField: 'utilization',
            stacked: false,
            renderer: function(sprite, storeItem, barAttr) {
                var locationHierarchy = storeItem.get('locationHierarchy');

                barAttr.fill = locationHierarchy.getColor();
                barAttr.fillOpacity = Jda.SCExecutive.constant.Colors.chartSeriesDefaultOpacity;

                return barAttr;
            }
        }]
    },

    loadFromModel: function(model) {
        // Rather than binding the store here like we do for most charts, we just set the data of the stubbed store in the chart.
        // This is because the sorting for flipXY charts is broken in Sencha, so we need one store sorted ASC and one DESC.
        this.getStore().setData(model.getStore().getData().all);

        this.scheduleLayout();

        this.callParent(arguments);
    },

    performLayout: function() {
        this._adjustBarWidth();

        this.callParent();
    },

    _adjustBarWidth: function() {
        var numberOfRecords = this.getStore().getCount();
        var barWidth = Jda.SCExecutive.chart.BarWidthCalculator.calculateBarWidthForChart(this, 1, numberOfRecords, true);
        var series = this.getSeries()[0];
        var sprite = series.getSprites()[0];

        sprite.setAttributes({
            maxBarWidth: barWidth,
            minBarWidth: barWidth
        });
    }
});
