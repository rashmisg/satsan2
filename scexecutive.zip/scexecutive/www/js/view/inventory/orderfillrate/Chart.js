Ext.define('Jda.SCExecutive.view.Inventory.OrderFillRate.Chart', {
    extend: 'Jda.SCExecutive.chart.CartesianChart',
    xtype: 'orderfillchart',

    config: {
        animate: false,
        axes: [
            Jda.SCExecutive.chart.AxisConfig.currencyYAxisConfig({
                fields: 'orderValue'
            }),
            Jda.SCExecutive.chart.AxisConfig.barXAxisConfig(),
            Jda.SCExecutive.chart.AxisConfig.unitYAxisConfig({
                position: 'right',
                fields: 'orderCount'
            })
        ],

        isMaximized: false
    },

    updateIsMaximized: function(isMaximized) {
        var axes = this.getAxes();
        var valueYAxis = axes[0];
        var xAxis = axes[1];
        var countYAxis = axes[2];

        var majorTickSteps = 5;
        if (isMaximized) {
            majorTickSteps *= 2;
        }

        valueYAxis.setMajorTickSteps(majorTickSteps);
        countYAxis.setMajorTickSteps(majorTickSteps);
        xAxis.setRenderer(Jda.SCExecutive.util.Renderers.getBarChartXAxisRenderer(isMaximized));
    },

    performLayout: function() {
        this._adjustBarWidth();

        this.callParent(arguments);
    },

    loadFromStore: function(store, valueMax, countMax, periodHierarchy) {
        this.bindStore(store);

        var axes = this.getAxes();
        var valueAxis = axes[0];
        var bottomAxis = axes[1];
        var countAxis = axes[2];

        valueAxis.setMaximum(valueMax);
        countAxis.setMaximum(countMax);

        this.setSeries([{
            type: 'bar',
            stacked: false,
            style: {
                fill: Jda.SCExecutive.constant.Colors.chartSeriesPrimaryColor,
                fillOpacity: Jda.SCExecutive.constant.Colors.chartSeriesDefaultOpacity,
                inGroupGapWidth: 0
            },
            xField: 'periodHierarchy',
            yField: 'orderValue'
        }, {
            type: 'bar',
            stacked: false,
            style: {
                fill: Jda.SCExecutive.constant.Colors.chartSeriesSecondaryColor,
                fillOpacity: Jda.SCExecutive.constant.Colors.chartSeriesDefaultOpacity,
                inGroupGapWidth: 0
            },
            xField: 'periodHierarchy',
            yField: 'orderCount'
        }]);

        var showWeekEndingLabel = periodHierarchy.get('type') === Jda.SCExecutive.model.PeriodHierarchy.types.MONTH;
        bottomAxis.setShowWeekEndingLabel(showWeekEndingLabel);

        this.callParent(arguments);
    },

    _adjustBarWidth: function() {
        var store = this.getStore();

        if (!store) {
            return;
        }

        var series = this.getSeries();
        var barWidth = Jda.SCExecutive.chart.BarWidthCalculator.calculateBarWidthForChart(this, 2, store.getCount());

        Ext.each(series, function(seriesItem) {
            var sprite = seriesItem.getSprites()[0];

            sprite.setAttributes({
                maxBarWidth: barWidth,
                minBarWidth: barWidth
            });
        });
    }
});
