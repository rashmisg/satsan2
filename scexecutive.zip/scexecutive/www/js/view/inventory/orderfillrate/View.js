Ext.define('Jda.SCExecutive.view.Inventory.OrderFillRate.View', {
    extend: 'Ext.Panel',
    xtype: 'inventoryorderfillrateview',

    config: {
        isInbound: false,

        layout: 'vbox',
        cls: 'sub-metric-panel',
        items: [{
            layout:'hbox',
            items:[{
                xtype: 'label',
                cls: 'title-container',
                itemId: 'orderfillratetitlelabel'
            }, {
                flex: 1 //spacer
            }, {
                xtype: 'pill',
                itemId: 'partyCountPill'
            }]
        }, {
            layout: 'hbox',
            cls:'chart-axis-header-container',
            items:[{
                xtype: 'label',
                cls: 'subtitle',
                html: Jda.getMessage('jda.scexecutive.orderfillrate.ValueLabel')
            }, {
                flex: 1 //spacer
            }, {
                xtype: 'label',
                cls: 'subtitle',
                html: Jda.getMessage('jda.scexecutive.orderfillrate.OrdersLabel')
            }]
        }, {
            xtype: 'orderfillchart',
            flex: 1
        }, {
            layout: {
                type: 'hbox',
                pack: 'center'
            },
            padding: '0 0 8px',
            items: [{
                layout: 'vbox',
                padding: '0 30px 0 0',
                items: [{
                    xtype: 'label',
                    cls: 'total-orders-value',
                    itemId: 'orderFillValueLabel'
                }, {
                    xtype: 'label',
                    html: Jda.getMessage('jda.scexecutive.orderfillrate.OrderValue'),
                    cls: 'total-orders-value-label'
                }]
            }, {
                layout: 'vbox',
                items: [{
                    xtype: 'label',
                    cls: 'total-orders-count',
                    itemId: 'orderFillCountLabel'
                }, {
                    xtype: 'label',
                    html: Jda.getMessage('jda.scexecutive.orderfillrate.OrdersLabel'),
                    cls: 'total-orders-count-label'
                }]
            }]
        }],
        plugins: [ 'maximize' ],

        model: null
    },

    initialize: function() {
        this.callParent();

        var msgTag;
        if (this.getIsInbound()) {
            msgTag = 'jda.scexecutive.orderfillrate.Inbound';
        }
        else {
            msgTag = 'jda.scexecutive.orderfillrate.Outbound';
        }

        var subTitleMsg = Jda.getMessage(msgTag);
        var titleLabel = this.down('#orderfillratetitlelabel');

        titleLabel.setHtml('<span class="title">' + Jda.getMessage('jda.scexecutive.orderfillrate.Title') + ' </span><span class="subtitle">' + subTitleMsg + '</span>');
    },

    loadFromModel: function(model) {
        var isInbound = this.getIsInbound();
        var modelFieldPrefix = isInbound ? 'getInbound' : 'getOutbound';

        var partyCountPill = this.down('#partyCountPill');
        var partyCountLabelText = Jda.getMessage('jda.scexecutive.orderfillrate.' + (isInbound ? 'Suppliers' : 'Customers'));
        var partyCountMethodName = modelFieldPrefix + 'PartyCount';
        partyCountPill.setGood(true); // always good
        partyCountPill.addCls('ofr-pill');
        partyCountPill.setText('<span class="ofr-pill-value">' + model[partyCountMethodName]() + '</span> <span class="ofr-pill-label">' + partyCountLabelText + '</span>');

        var orderFillValueLabel = this.down('#orderFillValueLabel');
        var orderFillValueMethodName = modelFieldPrefix + 'OrderFillValue';
        orderFillValueLabel.setHtml(Jda.SCExecutive.util.Formatters.MetricFormatter.formatCurrency(model[orderFillValueMethodName]()));

        var orderFillCountLabel = this.down('#orderFillCountLabel');
        var orderFillCountMethodName = modelFieldPrefix + 'OrderFillCount';
        orderFillCountLabel.setHtml(Jda.SCExecutive.util.Formatters.MetricFormatter.formatNumber(model[orderFillCountMethodName]()));

        var orderStoreMethodName = modelFieldPrefix + 'Store';
        var orderStore = model[orderStoreMethodName]();
        var orderValueMaxMethodName = modelFieldPrefix + 'MaximumValue';
        var maximumValue = model[orderValueMaxMethodName]();
        var valueYAxisConfig = Jda.SCExecutive.util.Renderers.getAdjustedLineChartYAxisConfig({ highestValue: maximumValue });
        var orderCountMaxMethodName = modelFieldPrefix + 'MaximumCount';
        var maximumCount = model[orderCountMaxMethodName]();
        var countYAxisConfig = Jda.SCExecutive.util.Renderers.getAdjustedLineChartYAxisConfig({ highestValue: maximumCount });

        var chart = this.down('orderfillchart');
        chart.loadFromStore(orderStore, valueYAxisConfig.maximum, countYAxisConfig.maximum, model.getPeriodHierarchy());

        this.setModel(model);
    },

    getMaximizedView: function() {
        var maximizedView = Ext.create('Jda.SCExecutive.view.Inventory.OrderFillRate.MaximizedView', {
            isInbound: this.getIsInbound()
        });

        maximizedView.loadFromModel(this.getModel());

        return maximizedView;
    }
});
