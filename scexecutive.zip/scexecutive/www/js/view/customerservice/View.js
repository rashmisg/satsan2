Ext.define('Jda.SCExecutive.view.CustomerService.View', {
    extend: 'Ext.Panel',
    xtype: 'customerserviceview',

    config: {
        cls: 'main-view',
        layout: 'vbox',
        items:[{
            xtype: 'contextcontainer'
        }, {
            flex: 1, // Top Row
            layout: 'fit',
            items: [{
                // wrapped in an additional layer so that all items are flexed equally...  the sub-metric-rows
                // have margin from the underlying widgets, but main-metric-panels don't have.
                xtype: 'customerserviceperformanceview'
            }]
        }, {
            cls: 'sub-metric-row', // Middle row
            flex: 1,
            layout: 'hbox',
            items:[{
                flex: 1,
                xtype: 'customerserviceorderfillrateview'
            }, {
                flex: 1,
                xtype: 'customerservicetoptencustomersview'
            }]
        }, {
            cls: 'sub-metric-row', // Bottom row
            flex: 1,
            layout: 'hbox',
            items:[{
                flex: 1,
                xtype: 'customerserviceunshippedordersview'
            }, {
                flex: 1,
                xtype: 'customerserviceontimedeliveryview'
            }]
        }, {
            xtype: 'legendcontainer'
        }]
    }
});
