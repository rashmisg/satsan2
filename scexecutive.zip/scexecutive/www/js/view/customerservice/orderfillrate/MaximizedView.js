Ext.define('Jda.SCExecutive.view.CustomerService.OrderFillRate.MaximizedView', {
    extend: 'Ext.Panel',

    config: {
        layout:'vbox',
        cls: 'expanded-metric-panel',
        items:[{
            layout:'hbox',
            items:[{
                xtype:'label',
                cls:'title-container',
                style:'position: absolute;',
                html:'<span class="title">' + Jda.getMessage('jda.scexecutive.orderfillrate.Title') + ' </span><span class="subtitle">' + Jda.getMessage('jda.scexecutive.orderfillrate.Outbound') + '</span>'
            }, {
                flex: 1 //spacer
            }, {
                xtype:'pill',
                itemId: 'averageOutboundOrderFillRatePercentPill'
            }]
        }, {
            flex: 1,
            xtype: 'customerserviceorderfillratechart',
            isMaximized: true
        }, {
            layout: {
                type: 'hbox',
                pack: 'center'
            },
            padding: 8,
            items: [{
                xtype: 'metricstat',
                itemId: 'totalOrdersStat',
                qualifierText: Jda.getMessage('jda.scexecutive.orderfillrate.OrdersLabel'),
                size: Jda.SCExecutive.component.MetricStat.sizes.MEDIUM,
                shouldFlexItems: false
            }, {
                xtype: 'metricstat',
                itemId: 'ordersFilledStat',
                qualifierText: Jda.getMessage('jda.scexecutive.orderfillrate.FilledLabel'),
                size: Jda.SCExecutive.component.MetricStat.sizes.MEDIUM,
                shouldFlexItems: false
            }]
        }]
    },

    loadFromModel: function(model) {
        var pill = this.down('#averageOutboundOrderFillRatePercentPill');
        var averageOutboundOrderFillRatePercent = model.getAverageOutboundOrderFillRatePercent();
        var pillText = Jda.SCExecutive.util.Formatters.MetricFormatter.formatPercent(averageOutboundOrderFillRatePercent, Jda.SCExecutive.constant.Precision.Low);

        pill.setText(pillText);
        pill.setGood(model.isOrderFillRatePercentGood());

        var totalOrdersStat = this.down('#totalOrdersStat');
        var totalOrdersCount = model.getTotalOrdersCount();
        var totalOrdersCountDisplayValue = Jda.SCExecutive.util.Formatters.MetricFormatter.formatNumber(totalOrdersCount);
        totalOrdersStat.setValueText(totalOrdersCountDisplayValue);

        var ordersFilledStat = this.down('#ordersFilledStat');
        var ordersFilledCount = model.getOrdersFilledCount();
        var ordersFilledCountDisplayValue = Jda.SCExecutive.util.Formatters.MetricFormatter.formatNumber(ordersFilledCount);
        ordersFilledStat.setValueText(ordersFilledCountDisplayValue);

        var chart = this.down('customerserviceorderfillratechart');
        chart.loadFromModel(model);
    }
});
