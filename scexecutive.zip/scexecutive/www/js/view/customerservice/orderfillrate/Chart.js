Ext.define('Jda.SCExecutive.view.CustomerService.OrderFillRate.Chart', {
    extend: 'Jda.SCExecutive.chart.LocationPerformanceLineChart',
    xtype: 'customerserviceorderfillratechart',

    config: {
        yAxisMinimum: 0,
        yAxisMaximum: 100
    },

    getMaximumForLocationsFromModel: function(model) {
        return model.getHighestValue();
    },

    getMinimumForLocationsFromModel: function(model) {
        return model.getLowestValue();
    },

    shouldPlotTargetSeries: function(model) {
        return model.getOrderFillRateTargetPercent() !== undefined;
    }
});
