Ext.define('Jda.SCExecutive.view.CustomerService.OnTimeDelivery.View', {
    extend: 'Ext.Panel',
    xtype: 'customerserviceontimedeliveryview',

    config: {
        layout:'vbox',
        cls:'sub-metric-panel',
        items:[{
            layout:'hbox',
            items:[{
                xtype:'label',
                cls:'title-container',
                style:'position: absolute;',
                html:'<span class="title">' + Jda.getMessage('jda.scexecutive.ontimedelivery.Title') + ' </span><span class="subtitle">' + Jda.getMessage('jda.scexecutive.ontimedelivery.SubTitle') + '</span>'
            }, {
                flex:1 //spacer
            }, {
                xtype:'pill',
                itemId: 'averagePercentPill'
            }]
        }, {
            flex: 1,
            xtype: 'transportationontimedeliverychart'
        }],
        plugins: [ 'maximize' ],

        model: null
    },

    loadFromModel: function(model) {
        var averagePercentPill = this.down('#averagePercentPill');
        var averagePercent = model.getOutboundOnTimePercent();
        var targetPercent = model.getOutboundOnTimeTarget();
        var averagePercentDisplayValue = Jda.SCExecutive.util.Formatters.MetricFormatter.formatPercent(averagePercent, Jda.SCExecutive.constant.Precision.Low);
        var isGood = targetPercent === undefined || averagePercent >= targetPercent;
        var periodHierarchy = model.getPeriodHierarchy();
        var showWeekEndingLabel = periodHierarchy.get('type') === Jda.SCExecutive.model.PeriodHierarchy.types.MONTH;

        averagePercentPill.setText(averagePercentDisplayValue);
        averagePercentPill.setGood(isGood);

        var chart = this.down('transportationontimedeliverychart');
        chart.setSelectedTabIndex(Jda.SCExecutive.view.Transportation.View.OUTBOUND_TAB_INDEX); // always outbound
        chart.loadFromModel(model);

        var bottomAxis = chart.getAxes()[1];
        bottomAxis.setShowWeekEndingLabel(showWeekEndingLabel);

        this.setModel(model);
    },

    getMaximizedView: function() {
        var maximizedView = Ext.create('Jda.SCExecutive.view.CustomerService.OnTimeDelivery.MaximizedView');

        maximizedView.loadFromModel(this.getModel());

        return maximizedView;
    }
});
