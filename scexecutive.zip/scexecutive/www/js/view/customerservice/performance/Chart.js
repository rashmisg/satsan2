Ext.define('Jda.SCExecutive.view.CustomerService.Performance.Chart', {
    extend: 'Jda.SCExecutive.chart.LocationPerformanceLineChart',
    xtype: 'customerserviceperformancechart',

    config: {
        yAxisMinimum: 0,
        yAxisMaximum: 100
    },

    getMaximumForLocationsFromModel: function(model) {
        return model.getHighestValue();
    },

    getMinimumForLocationsFromModel: function(model) {
        return model.getLowestValue();
    },

    shouldPlotTargetSeries: function(model) {
        return model.getCustomerServiceLevelTargetPercent() !== undefined;
    },

    buildSeriesConfig: function(model) {
        var series = this.callParent(arguments);

        series.unshift({
            type: 'line',
            style: {
                stroke: Jda.SCExecutive.constant.Colors.chartSeriesPrimaryColor,
                strokeOpacity: 0.25,
                fill: Jda.SCExecutive.constant.Colors.chartSeriesPrimaryColor,
                fillOpacity: 0.05
            },
            fill: true,
            xField: this.getDateFieldName(),
            yField: 'average'
        });

        return series;
    }
});
