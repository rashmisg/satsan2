Ext.define('Jda.SCExecutive.view.CustomerService.Performance.View', {
    extend: 'Ext.Container',
    xtype: 'customerserviceperformanceview',

    config: {
        xtype: 'container',
        cls: 'main-metric-panel',
        layout: 'vbox',
        items: [{
            xtype: 'label',
            cls: 'title-container',
            html: '<span class="title">' + Jda.getMessage('jda.scexecutive.customerservice.Title') + '</span>'
        }, {
            flex: 1,
            layout: 'hbox',
            items: [{
                width: 240,
                layout: 'vbox',
                items: [{
                    layout: 'hbox',
                    padding: 10,
                    items: [{
                        flex: 1
                    }, {
                        xtype: 'horsepill',
                        width: 150,
                        itemId: 'averageCustomerServiceLevelPill'
                    }, {
                        flex: 1
                    }]
                }, {
                    xtype: 'metricstat',
                    itemId: 'ordersFilledStat',
                    qualifierText: Jda.getMessage('jda.scexecutive.customerservice.OrdersFilledLabel'),
                    margin: '0 40px 0 0'
                }, {
                    xtype: 'metricstat',
                    itemId: 'customersStat',
                    qualifierText: Jda.getMessage('jda.scexecutive.customerservice.CustomersLabel'),
                    margin: '0 40px 0 0'
                }, {
                    xtype: 'metricstat',
                    itemId: 'loadsStat',
                    qualifierText: Jda.getMessage('jda.scexecutive.customerservice.LoadsLabel'),
                    margin: '0 40px 0 0'
                }]
            }, {
                xtype: 'customerserviceperformancechart',
                flex: 1
            }]
        }],
        plugins: [ 'maximize' ],

        model: null
    },

    loadFromModel: function(model) {
        var averageCustomerServiceLevelPill = this.down('#averageCustomerServiceLevelPill');
        averageCustomerServiceLevelPill.setGood(model.isCustomerServiceLevelGood());
        averageCustomerServiceLevelPill.displayAverageTextForPeriod(model.getAverageCustomerServiceLevelPercent(), model.getPeriodHierarchy());

        var ordersFilledStat = this.down('#ordersFilledStat');
        var ordersFilledValue = model.getOrdersFilledValue();
        var ordersFilledDisplayValue = Jda.SCExecutive.util.Formatters.MetricFormatter.formatCurrency(ordersFilledValue);
        ordersFilledStat.updateValueText(ordersFilledDisplayValue);

        var customersStat = this.down('#customersStat');
        var customersCount = model.getCustomersCount();
        var customersCountDisplayValue = Jda.SCExecutive.util.Formatters.MetricFormatter.formatNumber(customersCount);
        customersStat.updateValueText(customersCountDisplayValue);

        var loadsStat = this.down('#loadsStat');
        var loadsCount = model.getLoadsCount();
        var loadsCountDisplayValue = Jda.SCExecutive.util.Formatters.MetricFormatter.formatNumber(loadsCount);
        loadsStat.updateValueText(loadsCountDisplayValue);

        var chart = this.down('customerserviceperformancechart');
        chart.loadFromModel(model);

        this.setModel(model);
    },

    getMaximizedView: function() {
        var maximizedView = Ext.create('Jda.SCExecutive.view.CustomerService.Performance.MaximizedView');

        maximizedView.loadFromModel(this.getModel());

        return maximizedView;
    }
});
