Ext.define('Jda.SCExecutive.view.CustomerService.Performance.MaximizedView', {
    extend: 'Ext.Container',

    config: {
        xtype: 'container',
        cls: 'expanded-metric-panel',
        layout: 'vbox',
        items: [{
            xtype: 'label',
            cls: 'title-container',
            html: '<span class="title">' + Jda.getMessage('jda.scexecutive.customerservice.Title') + '</span>'
        }, {
            layout: 'hbox',
            padding: '15px 0',
            items: [{
                flex: 1
            }, {
                xtype: 'horsepill',
                width: 150,
                itemId: 'averageCustomerServiceLevelPill'
            }, {
                xtype: 'metricstat',
                flex: 3,
                itemId: 'ordersFilledStat',
                qualifierText: Jda.getMessage('jda.scexecutive.customerservice.OrdersFilledLabel')
            }, {
                xtype: 'metricstat',
                flex: 3,
                itemId: 'customersStat',
                qualifierText: Jda.getMessage('jda.scexecutive.customerservice.CustomersLabel')
            }, {
                xtype: 'metricstat',
                flex: 3,
                itemId: 'loadsStat',
                qualifierText: Jda.getMessage('jda.scexecutive.customerservice.LoadsLabel')
            }, {
                flex: 1
            }]
        }, {
            xtype: 'customerserviceperformancechart',
            flex: 1,
            isMaximized: true
        }]
    },

    loadFromModel: function(model) {
        var averageCustomerServiceLevelPill = this.down('#averageCustomerServiceLevelPill');
        averageCustomerServiceLevelPill.setGood(model.isCustomerServiceLevelGood());
        averageCustomerServiceLevelPill.displayAverageTextForPeriod(model.getAverageCustomerServiceLevelPercent(), model.getPeriodHierarchy());

        var ordersFilledStat = this.down('#ordersFilledStat');
        var ordersFilledValue = model.getOrdersFilledValue();
        var ordersFilledDisplayValue = Jda.SCExecutive.util.Formatters.MetricFormatter.formatCurrency(ordersFilledValue);
        ordersFilledStat.updateValueText(ordersFilledDisplayValue);

        var customersStat = this.down('#customersStat');
        var customersCount = model.getCustomersCount();
        var customersCountDisplayValue = Jda.SCExecutive.util.Formatters.MetricFormatter.formatNumber(customersCount);
        customersStat.updateValueText(customersCountDisplayValue);

        var loadsStat = this.down('#loadsStat');
        var loadsCount = model.getLoadsCount();
        var loadsCountDisplayValue = Jda.SCExecutive.util.Formatters.MetricFormatter.formatNumber(loadsCount);
        loadsStat.updateValueText(loadsCountDisplayValue);

        var chart = this.down('customerserviceperformancechart');
        chart.loadFromModel(model);
    }
});
