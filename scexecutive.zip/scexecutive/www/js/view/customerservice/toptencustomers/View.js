Ext.define('Jda.SCExecutive.view.CustomerService.TopTenCustomers.View', {
    extend: 'Ext.Panel',
    xtype: 'customerservicetoptencustomersview',

    config: {
        layout: 'vbox',
        cls: 'sub-metric-panel',
        items:[{
            xtype: 'label',
            cls:'title-container',
            html: '<span class="title">' + Jda.getMessage('jda.scexecutive.toptencustomers.Title') + '</span>'
        }, {
            flex: 1,
            xtype: 'scexecutivegrid',
            
            columns: [{
                text: Jda.getMessage('jda.scexecutive.toptencustomers.CustomerColumnHeader'),
                dataIndex: 'name',
                renderer: function(value) {
                    return Ext.String.htmlEncode(value);
                }
            }, {
                text: Jda.getMessage('jda.scexecutive.toptencustomers.RevenueColumnHeader'),
                dataIndex: 'revenue',
                width: '15%',
                renderer: function(value) {
                    return Jda.SCExecutive.util.Formatters.MetricFormatter.formatCurrency(value, Jda.SCExecutive.constant.Precision.Medium, true);
                }
            }, {
                text: Jda.getMessage('jda.scexecutive.toptencustomers.FillRateColumnHeader'),
                dataIndex: 'fillRate',
                width: '17%',
                renderer: function(value) {
                    return Jda.SCExecutive.util.Formatters.MetricFormatter.formatPercent(value, Jda.SCExecutive.constant.Precision.Low);
                }
            }, {
                text: Jda.getMessage('jda.scexecutive.toptencustomers.OnTimeColumnHeader'),
                dataIndex: 'onTime',
                width: '15%',
                renderer: function(value) {
                    return Jda.SCExecutive.util.Formatters.MetricFormatter.formatPercent(value, Jda.SCExecutive.constant.Precision.Low);
                }
            }, {
                text: Jda.getMessage('jda.scexecutive.toptencustomers.UnshippedColumnHeader'),
                dataIndex: 'unshipped',
                width: '22%',
                renderer: function(value) {
                    return Jda.SCExecutive.util.Formatters.MetricFormatter.formatCurrency(value, Jda.SCExecutive.constant.Precision.Medium, true);
                }
            }]
        }]
    },

    loadFromModel: function(model) {
        var grid = this.down('scexecutivegrid');
        grid.setStore(model.getStore());
    }
});
