Ext.define('Jda.SCExecutive.view.CustomerService.UnshippedOrders.Chart', {
    extend: 'Jda.SCExecutive.chart.CartesianChart',
    xtype: 'customerserviceunshippedorderschart',

    config: {
        animate: false,

        // apparently you need to have a stubbed out store so that series don't blow up
        store: {
            fields: [ 'locationHierarchy', 'value', 'percent']
        },
        innerPadding: {
            top: 5
        },
        series: [{
            type: 'bar',
            xField: 'locationHierarchy',
            yField: 'value',
            renderer: function(sprite, barAttr, storeObj, index) {
                var store = storeObj.store,
                    record = store.getAt(index),
                    locationHierarchy = record.get('locationHierarchy');

                barAttr.fill = locationHierarchy.getColor();
                barAttr.fillOpacity = Jda.SCExecutive.constant.Colors.chartSeriesDefaultOpacity;

                return barAttr;
            }
        }, {
            type: 'line',
            xField: 'locationHierarchy',
            yField: 'percent',
            style: {
                stroke: '#000'
            },
            marker: {
                type: 'circle',
                radius: 2.5,
                fill: '#000',
                strokeStyle: 'none' // don't inherit stroke from series' style
            }
        }],
        axes: [
            Jda.SCExecutive.chart.AxisConfig.emptyXAxisConfig(),
            Jda.SCExecutive.chart.AxisConfig.currencyYAxisConfig({
                fields: [ 'value' ],
                minimum: 0,
                majorTickSteps: 5
            }), 
            Jda.SCExecutive.chart.AxisConfig.unitYAxisConfig({
                position: 'right',
                fields: [ 'percent' ],
                minimum: 0,
                maximum: 100,
                majorTickSteps: 5
            })
        ],
        isMaximized: false
    },

    loadFromModel: function(model) {
        var maxY = model.getMaximumValue();
        this._adjustYAxisConfig(maxY);

        this.bindStore(model.getStore());

        this.callParent(arguments);
    },

    updateIsMaximized: function(isMaximized) {
        var axes = this.getAxes();
        var xAxis = axes[0];
        var valueYAxis = axes[1];
        var percentYAxis = axes[2];

        var majorTickSteps = 5;
        if (isMaximized) {
            majorTickSteps *= 2;
        }

        valueYAxis.setMajorTickSteps(majorTickSteps);
        percentYAxis.setMajorTickSteps(majorTickSteps);
    },

    performLayout: function() {
        this._adjustBarWidth();

        this.callParent(arguments);
    },

    _adjustYAxisConfig: function(maximumDataValue) {
        //trying to determine a good value for maximum
        var config = Jda.SCExecutive.util.Renderers.getAdjustedLineChartYAxisConfig({ highestValue: maximumDataValue }); 
        var yAxis = this.getAxes()[1]; //currency y axis

        yAxis.setMaximum(config.maximum);
    },

    _adjustBarWidth: function() {
        var numberOfRecords = this.getStore().getCount();
        var barWidth = Jda.SCExecutive.chart.BarWidthCalculator.calculateBarWidthForChart(this, 1, numberOfRecords);
        var series = this.getSeries()[0];
        var sprite = series.getSprites()[0];

        sprite.setAttributes({
            maxBarWidth: barWidth,
            minBarWidth: barWidth
        });
    }
});
