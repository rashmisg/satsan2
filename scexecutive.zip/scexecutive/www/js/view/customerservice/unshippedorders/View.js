Ext.define('Jda.SCExecutive.view.CustomerService.UnshippedOrders.View', {
    extend: 'Ext.Panel',
    xtype: 'customerserviceunshippedordersview',

    config: {
        layout: 'vbox',
        cls: 'sub-metric-panel',
        items:[{
            layout: 'hbox',
            items:[{
                xtype: 'label',
                cls:'title-container',
                html: '<span class="title">' + Jda.getMessage('jda.scexecutive.unshippedorders.Title') + '</span>'
            }, {
                flex: 1 //spacer
            }, {
                xtype: 'pill',
                itemId: 'totalRevenuePill'
            }]
        }, {
            layout: 'hbox',
            cls:'chart-axis-header-container',
            items:[{
                xtype: 'label',
                cls: 'subtitle',
                html: Jda.getMessage('jda.scexecutive.unshippedorders.PendingRevenue')
            }, {
                flex: 1 //spacer
            }, {
                xtype: 'label',
                cls: 'subtitle',
                html: Jda.getMessage('jda.scexecutive.unshippedorders.CumulativePercent')
            }]
        }, {
            xtype: 'customerserviceunshippedorderschart',
            flex: 1
        }, {
            xtype: 'metricstat',
            itemId: 'unshippedOrdersStat',
            qualifierText: Jda.getMessage('jda.scexecutive.unshippedorders.UnshippedOrdersCountLabel'),
            size: Jda.SCExecutive.component.MetricStat.sizes.MEDIUM,
            shouldFlexItems: false
        }, {
            html: Jda.getMessage('jda.scexecutive.unshippedorders.TimeFrame'),
            cls: 'unshipped-orders-time-frame'
        }],
        plugins: [ 'maximize' ],

        model: null
    },

    loadFromModel: function(model) {
        var totalRevenuePill = this.down('#totalRevenuePill');

        var totalRevenue = model.getTotalRevenue();
        var totalRevenueDisplayValue = Jda.SCExecutive.util.Formatters.MetricFormatter.formatCurrency(totalRevenue);
        totalRevenuePill.setText(totalRevenueDisplayValue);
        totalRevenuePill.setGood(true); //no threshold, so always set to good

        var unshippedOrdersStat = this.down('#unshippedOrdersStat');
        var unshippedOrders = model.getUnshippedOrdersCount();
        var unshippedOrdersDisplayValue = Jda.SCExecutive.util.Formatters.MetricFormatter.formatNumber(unshippedOrders);
        unshippedOrdersStat.updateValueText(unshippedOrdersDisplayValue);

        var chart = this.down('customerserviceunshippedorderschart');
        chart.loadFromModel(model);

        this.setModel(model);
    },

    getMaximizedView: function() {
        var maximizedView = Ext.create('Jda.SCExecutive.view.CustomerService.UnshippedOrders.MaximizedView');

        maximizedView.loadFromModel(this.getModel());

        return maximizedView;
    }
});
