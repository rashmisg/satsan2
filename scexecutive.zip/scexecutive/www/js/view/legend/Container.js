Ext.define('Jda.SCExecutive.view.Legend.Container', {
    extend: 'Ext.Panel',
    xtype: 'legendcontainer',

    config: {
        layout: 'fit',
        margin: '0 0 10px',
        height: 58
    }
});
