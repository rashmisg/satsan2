Ext.define('Jda.SCExecutive.view.Legend.View', {
    extend: 'Ext.Container',

    config: {
        cls: 'legend-panel',
        layout: 'card',
        width: '100%',
        height: 58,
        itemId: 'sharedLegendView',
        currentLevel: 0 // The location hierarchy level. Used to indicate when we can still navigate upwards.
    },

    statics: {
        sharedLegendView: null,

        getSharedLegendView: function() {
            if (!Jda.SCExecutive.view.Legend.View.sharedLegendView) {
                Jda.SCExecutive.view.Legend.View.sharedLegendView = Ext.create('Jda.SCExecutive.view.Legend.View');
            }

            return Jda.SCExecutive.view.Legend.View.sharedLegendView;
        }
    },

    initialize: function() {
        this.callParent(arguments);

         Jda.SCExecutive.util.AppContext.on('contextchanged', this.onAppContextChanged, this);
    },

    onAppContextChanged: function(context) {
        if (context.forceLoad) {
            var legendItemDataViews = this.query('#legendItemDataView');

            Ext.each(legendItemDataViews, function(legendItemDataView) {
                // Manually force a refresh on the data views so that the color updates are picked up
                legendItemDataView.refresh();
            });
        }
    },

    setupLegendWithRootLocationHierarchy: function(rootLocationHierarchy) {
        this.setCurrentLevel(0);

        var locationHierarchies = rootLocationHierarchy.children().getRange();
        this.createLegendItems(rootLocationHierarchy);
    },

    createLegendItems: function(locationHierarchy) {
        var locationIdentifier = locationHierarchy.getId();

        if (this.checkIfLegendItemExists(locationIdentifier)) {
            return;
        }

        var legendCardContainerItems = [];

        // The up arrow is need if we aren't at the top of the hierarchy aka _currentLevel is 0
        var upArrow = this.createUpArrowIfNeeded();
        if (upArrow) {
            legendCardContainerItems.push(upArrow);
        }

        // Since templates don't provide a way to refer to the record from within a member function, need to create a separate template for each...
        var tpl = new Ext.XTemplate('<div class="box" style="background-color:{[this.getColor(this, values, parent)]}"></div><span>{name}</span>', {
            disableFormats: true,
            getColor: function(me, values, parent) {
                return locationHierarchy.children().getById(values.id).getColor();
            }
        });

        var dataView = Ext.create('Ext.dataview.DataView', {
            itemId: 'legendItemDataView',
            store: locationHierarchy.children(),
            inline: { wrap: false },
            width: '100%',
            scrollable: {
                direction: 'horizontal',
                directionLock: true
            },
            layout: {
                type: 'hbox',
                pack: 'center',
                align: 'center'
            },
            itemCls: 'legend-item',
            itemTpl: tpl,
            listeners: {
                itemtap: this.onTapLegendItem,
                scope: this
            }
        });

        legendCardContainerItems.push(dataView);

        this.add({
            xtype: 'container',
            itemId: 'legend-locations-' + locationIdentifier,
            record: locationHierarchy,
            layout: {
                type: 'hbox',
                pack: 'center'
            },
            items: legendCardContainerItems
        });
    },

    createUpArrowIfNeeded: function() {
        var upArrow;
        if (this.getCurrentLevel() > 0) {
            upArrow = {
                docked: 'left',
                xtype: 'component',
                cls: 'legend-up-arrow',
                itemId: 'legendUpArrow',
                listeners: {
                    initialize: this.onInitializeUpArrow,
                    scope: this
                }
            };
        }

        return upArrow;
    },

    checkIfLegendItemExists: function(locationIdentifier) {
        return this.down('#legend-locations-' + locationIdentifier);
    },

    onInitializeUpArrow: function(upArrow) {
        upArrow.addListener('tap', Ext.Function.bind(this.onTapUpArrow, this, [upArrow], false), this, {
            element: 'element',
            event: 'tap'
        });
    },

    onTapLegendItem: function(dataView, index, target, record) {
        var doesntHaveLocations = record.children().getCount() === 0;
        if (doesntHaveLocations) {
            return;
        }

        this.setCurrentLevel(this.getCurrentLevel() + 1);
        this.changeLegendTo(record);
    },

    onTapUpArrow: function(upArrow) {
        this.setCurrentLevel(this.getCurrentLevel() - 1);
        var legendCardContainer = this.getActiveItem();

        // The boundTo record is the parent record for the currently viewed locations
        var parentLegendItemRecord = legendCardContainer.config.record.get('parent');
        this.changeLegendTo(parentLegendItemRecord);
    },

    changeLegendTo: function(locationHierarchy) {
        var locationIdentifier = locationHierarchy.getId();

        this.createLegendItems(locationHierarchy);

        var legendLocationItem = this.child('#legend-locations-' + locationIdentifier);
        this.setActiveItem(legendLocationItem);

        // Reset the scroll offset so that it always starts at the beginning
        legendLocationItem.child('#legendItemDataView').getScrollable().getScroller().scrollTo(0);

        Jda.SCExecutive.util.AppContext.setCurrentLocationHierarchy(locationHierarchy);
    }
});
