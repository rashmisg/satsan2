Ext.define('Jda.SCExecutive.context.Container', {
    extend: 'Ext.Panel',
    xtype: 'contextcontainer',

    config: {
        layout: 'fit',
        margin: '4px 10px 2px'
    }
});
