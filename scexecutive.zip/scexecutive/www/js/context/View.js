Ext.define('Jda.SCExecutive.context.View', {
    extend: 'Ext.Container',

    config: {
        layout: 'hbox',
        items: [{
            xtype: 'label',
            cls: 'location-context-label',
            itemId: 'contextContainerLocationLabel'
        }, {
            flex: 1 // spacer
        }, {
            xtype: 'label',
            cls: 'period-context-label',
            itemId: 'contextContainerPeriodLabel'
        }]
    },

    statics: {
        sharedContextView: null,

        getSharedContextView: function() {
            if (!Jda.SCExecutive.context.View.sharedContextView) {
                Jda.SCExecutive.context.View.sharedContextView = Ext.create('Jda.SCExecutive.context.View');
            }

            return Jda.SCExecutive.context.View.sharedContextView;
        }
    },

    initialize: function() {
        this.callParent(arguments);

         Jda.SCExecutive.util.AppContext.on('contextchanged', this._onAppContextChanged, this);
    },

    _onAppContextChanged: function(context) {
        var periodLabel = this.down('#contextContainerPeriodLabel');
        var locationLabel = this.down('#contextContainerLocationLabel');

        periodLabel.setHtml(context.periodHierarchy.getDisplayString());
        locationLabel.setHtml(context.locationHierarchy.getViewingString());
    }
});
