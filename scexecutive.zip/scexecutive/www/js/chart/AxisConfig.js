Ext.define('Jda.SCExecutive.chart.AxisConfig', {
    singleton: true,

    /***** X Axis *****/
    barXAxisConfig: function(config) {
        return Ext.apply({
            renderer: Jda.SCExecutive.util.Renderers.getBarChartXAxisRenderer()
        }, config, this.baseXAxisConfig);
    },

    lineXAxisConfig: function(config) {
        return Ext.apply({
            grid: {
                stroke: Jda.SCExecutive.constant.Colors.chartAxisGridStroke,
                lineWidth: 0.5,
                boundary: {
                    stroke: Jda.SCExecutive.constant.Colors.chartAxisBoundaryLine,
                    lineWidth: 1
                }
            },
            renderer: Jda.SCExecutive.util.Renderers.getLineChartXAxisRenderer()
        }, config, this.baseXAxisConfig);
    },

    emptyXAxisConfig: function(config) {
        return Ext.apply({
            renderer: function() { return ''; }//removing label text
        }, config, this.baseXAxisConfig);
    },

    baseXAxisConfig: {
        type: 'fiscaldate',
        position: 'bottom',
        label: {
            color: Jda.SCExecutive.constant.Colors.chartAxisLabel,
            fontSize: 10
        },
        style: {
            majorTickSize: 0,
            stroke: Jda.SCExecutive.constant.Colors.chartAxis,
            hideLastGridLine: true
        }
    },

    /***** Y Axis *****/
    currencyYAxisConfig: function(config) {
        return Ext.apply({
            renderer: this.currencyRenderer
        }, config, this.baseYAxisConfig);
    },

    percentYAxisConfig: function(config) {
        return Ext.apply({
            renderer: this.percentRenderer
        }, config, this.baseYAxisConfig);
    },

    unitYAxisConfig: function(config) {
        return Ext.apply({
            renderer: this.unitRenderer
        }, config, this.baseYAxisConfig);
    },

    baseYAxisConfig: {
        type: 'numeric',
        position: 'left',
        minimum: 0,
        grid: {
            stroke: Jda.SCExecutive.constant.Colors.chartAxisGridStroke,
            lineWidth: 0.5
        },
        label: {
            color: Jda.SCExecutive.constant.Colors.chartAxisLabel,
            fontSize: 10
        },
        style: {
            axisLine: false,
            majorTickSize: 0,
            hideLastGridLine: true
        }
    },

    currencyRenderer: function(label, layout) {
        if (label === layout.majorTicks.max) {
            return Jda.SCExecutive.util.Formatters.MetricFormatter.formatCurrency(label, Jda.SCExecutive.constant.Precision.Medium);
        }

        // If this is the bottom label, and it's zero, and zero was the intended bottom, don't show it. If the
        // intended bottom was something below zero (-1, for instance), then the zero tick should be rendered.
        if (label === layout.majorTicks.min && layout.majorTicks.min === 0) {
            return '';
        }

        return Jda.SCExecutive.util.Formatters.MetricFormatter.formatNumber(label, Jda.SCExecutive.constant.Precision.Medium);
    },

    percentRenderer: function(label, layout) {
        if (label === layout.majorTicks.max) {
            return Jda.SCExecutive.util.Formatters.MetricFormatter.formatPercent(label, Jda.SCExecutive.constant.Precision.Low);
        }

        // If this is the bottom label, and it's zero, and zero was the intended bottom, don't show it. If the
        // intended bottom was something below zero (-1, for instance), then the zero tick should be rendered.
        if (label === layout.majorTicks.min && layout.majorTicks.min === 0) {
            return '';
        }

        return Jda.SCExecutive.util.Formatters.MetricFormatter.formatNumber(label, Jda.SCExecutive.constant.Precision.Low);
    },

    unitRenderer: function(label, layout) {
        // If this is the bottom label, and it's zero, and zero was the intended bottom, don't show it. If the
        // intended bottom was something below zero (-1, for instance), then the zero tick should be rendered.
        if (label === layout.majorTicks.min && layout.majorTicks.min === 0) {
            return '';
        }

        return Jda.SCExecutive.util.Formatters.MetricFormatter.formatNumber(label, Jda.SCExecutive.constant.Precision.Medium);
    }
});
