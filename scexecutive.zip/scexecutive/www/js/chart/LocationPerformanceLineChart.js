Ext.define('Jda.SCExecutive.chart.LocationPerformanceLineChart', {
    extend: 'Jda.SCExecutive.chart.CartesianChart',

    config: {
        /**
         * @cfg {Boolean} showAggregatedData
         * Flag to determine if the chart should show the location data aggregated.  Defaults to false.
         */
        showAggregatedData: false,

        // the field name used for the aggregate data series
        aggregateFieldName: 'total',

        // the field name to use when plotting the target series
        targetSeriesFieldName: 'targetPercent',

        // the field name for the dates of the x axis
        dateFieldName: 'periodHierarchy',

        // whether this chart should act as though it's expanded (more ticks on y-axis, all x-ticks rendered)
        isMaximized: false,

        // storing off the highest and lowest values to be used when maximizing and recalculating the yAxis config
        storedLowestValue: 0,
        storedHighestValue: 100,
        yAxisMinimum: undefined,
        yAxisMaximum: undefined,

        animate: false,
        innerPadding: {
            top: 5,
            left: 20,
            right: 20
        },
        axes: [ Jda.SCExecutive.chart.AxisConfig.percentYAxisConfig(), Jda.SCExecutive.chart.AxisConfig.lineXAxisConfig() ],
        
        seriesStyle: {
            type: 'line',
            style: {
                strokeOpacity: Jda.SCExecutive.constant.Colors.chartSeriesDefaultOpacity
            },
            marker: {
                type: 'circle',
                stroke: Jda.SCExecutive.constant.Colors.chartSeriesMarkerStroke,
                radius: 2,
                lineWidth: 1
            }
        },
        
        aggregateSeriesStyle: {
            type: 'line',
            style: {
                stroke: Jda.SCExecutive.constant.Colors.chartSeriesPrimaryColor,
                strokeOpacity: 0.85,
                fill: Jda.SCExecutive.constant.Colors.chartSeriesPrimaryColor,
                fillOpacity: 0.3,
                lineWidth: 2
            },
            marker: {
                type: 'circle',
                radius: 3,
                fill: Jda.SCExecutive.constant.Colors.chartSeriesPrimaryColor,
                fillOpacity: 1,
                stroke: Jda.SCExecutive.constant.Colors.chartSeriesMarkerStroke,
                lineWidth: 1
            }
        },

        targetSeriesStyle: {
            type: 'line',
            style: {
                stroke: Jda.SCExecutive.constant.Colors.chartThresholdSeriesStroke,
                lineWidth: 1.5
            }
        }
    },

    updateIsMaximized: function(isMaximized) {
        var xAxis = this.getAxes()[1];
        xAxis.setRenderer(Jda.SCExecutive.util.Renderers.getLineChartXAxisRenderer(isMaximized));
        this._adjustYAxisConfig();
    },

    loadFromModel: function(model) {
        var periodHierarchy = model.getPeriodHierarchy();
        this.bindStore(model.getStore());

        if (this.getShowAggregatedData()) {
            this.setStoredLowestValue(this.getAggregatedMinimumFromModel(model));
            this.setStoredHighestValue(this.getAggregatedMaximumFromModel(model));
            this._adjustYAxisConfig();

            this.setSeries([
                Ext.Object.merge({
                    xField: this.getDateFieldName(),
                    yField: this.getAggregateFieldName()
                }, this.getAggregateSeriesStyle())
            ]);
        }
        else {
            this.setStoredLowestValue(this.getMinimumForLocationsFromModel(model));
            this.setStoredHighestValue(this.getMaximumForLocationsFromModel(model));
            this._adjustYAxisConfig();
            this.setSeries(this.buildSeriesConfig(model));
        }

        var shouldShowWeekEndingLabel = periodHierarchy.get('type') === Jda.SCExecutive.model.PeriodHierarchy.types.MONTH;
        var bottomAxis = this.getAxes()[1];
        bottomAxis.setShowWeekEndingLabel(shouldShowWeekEndingLabel);

        this.callParent(arguments);
    },

    getAggregatedMinimumFromModel: function(model) {
        throw new Error(this.$className + ' must implement getAggregatedMinimumFromModel.');
    },

    getAggregatedMaximumFromModel: function(model) {
        throw new Error(this.$className + ' must implement getAggregatedMaximumFromModel.');
    },

    getMinimumForLocationsFromModel: function(model) {
        throw new Error(this.$className + ' must implement getMinimumForLocationsFromModel.');
    },

    getMaximumForLocationsFromModel: function(model) {
        throw new Error(this.$className + ' must implement getMaximumForLocationsFromModel.');
    },

    shouldPlotTargetSeries: function(model) {
        throw new Error(this.$className + ' must implement shouldPlotTargetSeries.');
    },

    buildSeriesConfig: function(model) {
        var locationHierarchies = model.getLocationHierarchies();
        var series = [];

        if (this.shouldPlotTargetSeries(model)) {
            series.push(
                Ext.Object.merge({
                    xField: this.getDateFieldName(),
                    yField: this.getTargetSeriesFieldName()
                }, this.getTargetSeriesStyle())
            );
        }

        Ext.each(locationHierarchies, function(locationHierarchy) {
            series.push(this.buildLocationSeriesConfig(locationHierarchy));
        }, this);

        return series;
    },

    buildLocationSeriesConfig: function(locationHierarchy) {
        return Ext.Object.merge({
            style: {
                stroke: locationHierarchy.getColor()
            },
            marker: {
                fillStyle: locationHierarchy.getColor()
            },
            xField: this.getDateFieldName(),
            yField: locationHierarchy
        }, this.getSeriesStyle());
    },

    _adjustYAxisConfig: function() {
        var config = Jda.SCExecutive.util.Renderers.getAdjustedLineChartYAxisConfig({
            minimumCap: this.getYAxisMinimum(),
            maximumCap: this.getYAxisMaximum(),
            lowestValue: this.getStoredLowestValue(),
            highestValue: this.getStoredHighestValue(),
            hasDoubleTicks: this.getIsMaximized()
        });

        var yAxis = this.getAxes()[0];

        yAxis.setMinimum(config.minimum);
        yAxis.setMaximum(config.maximum);
        yAxis.setMajorTickSteps(config.majorTickSteps);
    }
});
