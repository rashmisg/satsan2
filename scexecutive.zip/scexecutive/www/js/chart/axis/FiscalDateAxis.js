Ext.define('Jda.SCExecutive.chart.axis.FiscalDateAxis', {
    extend: 'Ext.chart.axis.Category',
    alias: 'axis.fiscaldate',

    config: {
        weekEndingSprite: null,
        boundaryLineSprite: null,
        showWeekEndingLabel: null
    },

    constructor: function() {
        this.callParent(arguments);

        var weekEndingSprite = Ext.create('Jda.SCExecutive.chart.axis.sprite.WeekEndingSprite', {
            axis: this
        });

        this.setWeekEndingSprite(weekEndingSprite);
        this.setShowWeekEndingLabel(false);
    },

    updateShowWeekEndingLabel: function(showWeekEndingSprite) {
        var weekEndingSprite = this.getWeekEndingSprite();
        weekEndingSprite.setAttributes({ hidden: !showWeekEndingSprite });

        // Reset insetPadding if the Week Ending sprite modified it, and it's no longer being shown
        var originalLeftInsetPadding = weekEndingSprite.getOriginalChartLeftInsetPadding();
        if (!showWeekEndingSprite && originalLeftInsetPadding) {
            var chart = this.getChart();
            var insetPadding = chart.getInsetPadding();
            insetPadding.left = originalLeftInsetPadding;

            chart.setInsetPadding(insetPadding);
        }
    },

    // Note, this function is primarily taken directly out of the base class, with some overrides.
    getSprites: function () {
        if (!this.getChart()) {
            return;
        }
        var range = this.getRange(),
            position = this.getPosition(),
            chart = this.getChart(),
            animation = chart.getAnimate(),
            baseSprite, style,
            length = this.getLength();

        // If animation is false, then stop animation.
        if (animation === false) {
            animation = {
                duration: 0
            };
        }
        if (range) {
            style = Ext.applyIf({
                position: position,
                axis: this,
                min: range[0],
                max: range[1],
                length: length,
                grid: this.getGrid(),
                hidden: this.getHidden(),
                titleOffset: this.titleOffset,
                layout: this.getLayout(),
                segmenter: this.getSegmenter(),
                label: this.getLabel()
            }, this.getStyle());

            // If the sprites are not created.
            if (!this.sprites.length) {
                // OVERRIDE replace base axis type with our custom axis
                baseSprite = Ext.create('Jda.SCExecutive.chart.axis.sprite.BoundaryLineAxis', style);
                baseSprite.fx.setCustomDuration({
                    baseRotation: 0
                });
                baseSprite.fx.on("animationstart", "onAnimationStart", this);
                baseSprite.fx.on("animationend", "onAnimationEnd", this);
                this.sprites.push(baseSprite);

                // OVERRIDE add our week ending sprite
                this.sprites.push(this.getWeekEndingSprite());
                this.updateTitleSprite();
            }
            else {
                baseSprite = this.sprites[0];
                baseSprite.fx.setConfig(animation);
                baseSprite.setAttributes(style);
                baseSprite.setLayout(this.getLayout());
                baseSprite.setSegmenter(this.getSegmenter());
                baseSprite.setLabel(this.getLabel());
            }

            if (this.getRenderer()) {
                baseSprite.setRenderer(this.getRenderer());
            }
        }

        return this.sprites;
    },

    getThickness: function() {
        if (this.getHidden()) {
            return 0;
        }

        var weekEndingTotalHeight = this.getWeekEndingSprite().getBBox().y + this.getWeekEndingSprite().getBBox().height;
        var mainSpriteHeight = (this.sprites[0] && this.sprites[0].thickness || 1) + this.titleOffset;

        return Math.max(weekEndingTotalHeight, mainSpriteHeight);
    },

    // Note, this function is primarily taken directly out of the base class, with some overrides.
    getSurface: function() {
        this.callParent();

        var chart = this.getChart();
        if (!chart) {
            return null;
        }
        var surface = this.surface = chart.getSurface(this.getId(), 'axis'),
            gridSurface = this.gridSurface = chart.getSurface('main'),
            sprites = this.getSprites(),
            sprite = sprites[0],
            grid = this.getGrid(),
            gridAlignment = this.getGridAlignment(),
            gridSprite;
        if (grid) {
            gridSprite = new Ext.chart.Markers();
            gridSprite.setTemplate({xclass: 'grid.' + gridAlignment});
            if (Ext.isObject(grid)) {
                gridSprite.getTemplate().setAttributes(grid);
                if (Ext.isObject(grid.boundary)) {
                    gridSprite.getTemplate().setAttributes(grid.boundary);
                }
            }
            gridSurface.add(gridSprite);

            // OVERRIDE don't add even/odd, only add boundary marker
            sprite.bindMarker(gridAlignment + '-boundary', gridSprite);

            gridSurface.waitFor(surface);
        }

        return this.surface;
    }
});
