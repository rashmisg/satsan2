Ext.define('Jda.SCExecutive.chart.axis.sprite.WeekEndingSprite', {
    extend: 'Ext.draw.sprite.Text',

    config: {
        axis: null,

        // Used for resetting the chart inset if this sprite overrides the inset to fit itself.
        originalChartLeftInsetPadding: 0
    },

    constructor: function() {
        this.callParent(arguments);

        var attr = {
            text: Jda.getMessage('jda.scexecutive.chart.WeekEnding'),
            fillStyle: Jda.SCExecutive.constant.Colors.chartAxisLabel,
            textBaseline: 'top'
        };

        this.setAttributes(attr);
    },

    render: function() {
        var axis = this.getAxis();
        if (axis) {
            var chart = axis.getChart();
            var innerPadding = chart.getInnerPadding();
            var weekEndingSpriteWidth = this.getBBox().width;
            var x = -weekEndingSpriteWidth - innerPadding.left; // Shift it over by its width plus the amount the graph is inset

            var axisHeight = axis.getThickness();
            var titleMargin = axis.getTitleMargin();
            var weekEndingSpriteHeight = this.getBBox().height;
            var axisHeightWithoutTitle = axisHeight - axis.titleOffset;//titleOffset includes title height and title margin
            var y = axisHeightWithoutTitle - weekEndingSpriteHeight + titleMargin / 2 - 0.5; //add in the top margin, minus .5 for retina

            this.setAttributes({ x: x, y: y });

            var leftAxis;
            Ext.each(chart.getAxes(), function(axis) {
                if (axis.getPosition() === 'left') {
                    leftAxis = axis;
                    return false; // break
                }
            });

            // If there is a left axis, check that the width of the insetPadding and the left axis is enough
            // to account for the width of the Week Ending sprite. If it isn't enough, add the difference
            // of the two plus some padding to the chart's inset padding to allow the whole sprite to fit.
            if (leftAxis) {
                var chartInsetPadding = chart.getInsetPadding();
                var chartLeftInset = chartInsetPadding.left;
                var leftSideWidth = leftAxis.getThickness() + chartLeftInset;

                if (leftSideWidth < weekEndingSpriteWidth) {
                    // Inset is the difference between the Sprite width and the Axis width, plus some padding
                    var additionalInset = weekEndingSpriteWidth - leftSideWidth + 10;
                    chartInsetPadding.left += additionalInset;

                    chart.setInsetPadding(chartInsetPadding);
                    chart.scheduleLayout();
                    this.setOriginalChartLeftInsetPadding(chartLeftInset);
                }
            }
        }

        this.callParent(arguments);
    }
});
