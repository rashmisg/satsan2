Ext.define('Jda.SCExecutive.chart.axis.sprite.BoundaryLineAxis', {
    extend: 'Ext.chart.axis.sprite.Axis',

    renderGridLines: function (surface, ctx, layout, clipRegion) {
        this.callParent(arguments);
        var attr = this.attr;
        var matrix = attr.matrix;
        var startGap = attr.startGap;
        var endGap = attr.endGap;
        var xx = matrix.getXX();
        var dx = matrix.getDX();
        var position = attr.position;
        var majorTicks = layout.majorTicks;
        var anchor;
        var lastAnchor;

        if (attr.grid) {
            if (majorTicks) {
                if (position === 'top' || position === 'bottom') {
                    lastAnchor = attr.min * xx + dx + startGap;

                    this.iterate(majorTicks, function (position, labelText, i) {
                        anchor = position * xx + dx + startGap;
                        if (labelText && labelText.get && labelText.get('type') === Jda.SCExecutive.model.PeriodHierarchy.types.WEEK && majorTicks.max !== i) {
                            this._putBoundaryMarkersForWeek(majorTicks, labelText, anchor, lastAnchor, i);
                        }
                        lastAnchor = anchor;
                    });
                }
            }
        }
    },

    _putBoundaryMarkersForWeek: function(majorTicks, labelText, anchor, lastAnchor, i) {
        var month = labelText.data.parent;
        var quarter = month.data.parent;
        var months = quarter.childrenStore.data.all;
        var weeks = month.childrenStore.data.all;
        var lastWeekId = weeks[weeks.length - 1].id;
        var lastMonthInQuarterId = months[months.length - 1].id;

        var isInLastMonth = lastMonthInQuarterId === month.id;

        var nextWeekLabel = majorTicks.getLabel(i + 1);
        if(lastWeekId === labelText.id && !isInLastMonth) {
            this.putMarker('vertical-boundary', {
                x: anchor,
                width: lastAnchor - anchor
            }, i, true);
        }
        else if (nextWeekLabel && month.children().find('id', nextWeekLabel.get('id')) === -1) {
            // We didn't add a boundary line but the next major ticket is in next month which means the interval is not incrementing by one
            // and we need to put the boundary line in between ticks so figure out the actual x position.
            var weekPosition = weeks.length - (month.children().findExact('id', labelText.id) + 1);
            var shiftAnchor = ((anchor - lastAnchor) / majorTicks.step) * weekPosition;
            this.putMarker('vertical-boundary', {
                x: anchor + shiftAnchor,
                width: lastAnchor - anchor
            }, i, true);
        }
    }
});
