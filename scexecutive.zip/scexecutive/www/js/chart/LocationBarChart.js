Ext.define('Jda.SCExecutive.chart.LocationBarChart', {
    extend: 'Jda.SCExecutive.chart.CartesianChart',
    xtype: 'locationbarchart',

    config: {
        /**
         * @cfg {Boolean} showAggregatedData
         * Flag to determine if the chart should show the location data aggregated.  Defaults to false.
         */
        showAggregatedData: false,

        // whether this chart should act as though it's expaned (more ticks on y-axis, all x-ticks rendered)
        isMaximized: false,

        // storing off the highest and lowest values to be used when maximizing and recalculating the yAxis config
        storedLowestValue: 0,
        storedHighestValue: 100,
        yAxisMinimum: undefined,
        yAxisMaximum: undefined,

        animate: false,

        axes: [
            Jda.SCExecutive.chart.AxisConfig.currencyYAxisConfig(),
            Jda.SCExecutive.chart.AxisConfig.barXAxisConfig()
        ]
    },

    updateIsMaximized: function(isMaximized) {
        var xAxis = this.getAxes()[1];
        xAxis.setRenderer(Jda.SCExecutive.util.Renderers.getBarChartXAxisRenderer(isMaximized));

        this._adjustYAxisConfig();
    },

    loadFromModel: function(model) {
        var store = this.getStoreFromModel(model);
        this.bindStore(store);

        if (this.getShowAggregatedData()) {
            this.setStoredLowestValue(this.getAggregatedMinimumFromModel(model));
            this.setStoredHighestValue(this.getAggregatedMaximumFromModel(model));

            this._adjustYAxisConfig();

            this.setSeries([{
                type: 'bar',
                xField: this.getDateField(),
                yField: this.getTotalField(),
                style: {
                    fill: Jda.SCExecutive.constant.Colors.chartSeriesPrimaryColor,
                    fillOpacity: Jda.SCExecutive.constant.Colors.chartSeriesDefaultOpacity
                }
            }]);
        }
        else {
            this.setStoredLowestValue(this.getMinimumForLocationsFromModel(model));
            this.setStoredHighestValue(this.getMaximumForLocationsFromModel(model));

            this._adjustYAxisConfig();

            var locationHierarchiesFromModel = this.getLocationHierarchiesFromModel(model);
            this.setSeries(this._buildLocationSeriesArray(locationHierarchiesFromModel));
        }

        var xAxis = this.getAxes()[1];
        var shouldShowWeekEndingLabel = this.getPeriodHierarchyFromModel(model).get('type') === Jda.SCExecutive.model.PeriodHierarchy.types.MONTH;
        xAxis.setShowWeekEndingLabel(shouldShowWeekEndingLabel);

        this.callParent(arguments);
    },

    performLayout: function() {
        this._adjustSeriesBarWidth();

        this.callParent(arguments);
    },

    getTotalField: function() {
        throw new Error(this.$className + ' must implement getTotalField.');
    },

    getDateField: function() {
        throw new Error(this.$className + ' must implement getDateField.');
    },

    getStoreFromModel: function(model) {
        throw new Error(this.$className + ' must implement getStoreFromModel.');
    },

    getAggregatedMinimumFromModel: function(model) {
        throw new Error(this.$className + ' must implement getAggregatedMinimumFromModel.');
    },

    getAggregatedMaximumFromModel: function(model) {
        throw new Error(this.$className + ' must implement getAggregatedMaximumFromModel.');
    },

    getMinimumForLocationsFromModel: function(model) {
        throw new Error(this.$className + ' must implement getMinimumForLocationsFromModel.');
    },

    getMaximumForLocationsFromModel: function(model) {
        throw new Error(this.$className + ' must implement getMaximumForLocationsFromModel.');
    },

    getLocationHierarchiesFromModel: function(model) {
        throw new Error(this.$className + ' must implement getLocationHierarchiesFromModel.');
    },

    getPeriodHierarchyFromModel: function(model) {
        throw new Error(this.$className + ' must implement getPeriodHierarchyFromModel.');
    },

    _buildLocationSeriesArray: function(locationHierarchies) {
        var series = [];

        Ext.each(locationHierarchies, function(locationHierarchy) {
            series.push({
                stacked: false,
                type: 'bar',
                style: {
                    fill: locationHierarchy.getColor(),
                    fillOpacity: Jda.SCExecutive.constant.Colors.chartSeriesDefaultOpacity,
                    inGroupGapWidth: 1
                },
                xField: this.getDateField(),
                yField: locationHierarchy
            });
        }, this);

        return series;
    },

    _adjustSeriesBarWidth: function() {
        var series = this.getSeries();
        var store = this.getStore();

        // Nothing to do here
        if (!series || !series.length) {
            return;
        }

        // Only calculate width for number of bar series. Don't include things like threshold/line series.
        var numberOfBarSeries = 0;
        Ext.each(series, function(seriesObj) {
            if (seriesObj instanceof Ext.chart.series.Bar) {
                numberOfBarSeries++;
            }
        });

        var barWidth = Jda.SCExecutive.chart.BarWidthCalculator.calculateBarWidthForChart(this, numberOfBarSeries, store.getCount());

        Ext.each(series, function(seriesItem) {
            var sprite = seriesItem.getSprites()[0];

            sprite.setAttributes({
                maxBarWidth: barWidth,
                minBarWidth: barWidth
            });
        });
    },

    _adjustYAxisConfig: function() {
        var config = Jda.SCExecutive.util.Renderers.getAdjustedLineChartYAxisConfig({
            minimumCap: this.getYAxisMinimum(),
            maximumCap: this.getYAxisMaximum(),
            lowestValue: this.getStoredLowestValue(),
            highestValue: this.getStoredHighestValue(),
            hasDoubleTicks: this.getIsMaximized()
        });

        var yAxis = this.getAxes()[0];

        yAxis.setMinimum(config.minimum);
        yAxis.setMaximum(config.maximum);
        yAxis.setMajorTickSteps(config.majorTickSteps);
    }
});
