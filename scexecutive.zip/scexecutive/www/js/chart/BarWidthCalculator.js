Ext.define('Jda.SCExecutive.chart.BarWidthCalculator', {
    singleton: true,

    calculateBarWidthForChart: function(chart, seriesFieldCount, xAxisTickCount, horizontalBars) {
        var chartWidth = this._calculateWidth(chart, horizontalBars);
        var uxSpecifiedWidthPercentage = 0.6;
        var widthPerTick = (chartWidth / xAxisTickCount) * uxSpecifiedWidthPercentage;
        var widthPerSeries = widthPerTick / seriesFieldCount;

        return widthPerSeries;
    },

    // The goal here is to calculate the actual width of the charting area. This is mostly taken from the performLayout method on Cartesian
    // Chart. The simple explanation is overall element width, minus the axes width (left and right), the inset padding, and inner padding.
    _calculateWidth: function(chart, horizontalBars) {
        var chartElement = chart.element;
        var chartWidth = horizontalBars ? chartElement.getHeight() : chartElement.getWidth();
        var axes = chart.getAxes();

        // Subtract the width of the axes
        var axis, axisPosition;
        for (var axisIndex = 0; axisIndex < axes.length; axisIndex++) {
            axis = axes[axisIndex];

            axisPosition = axis.getPosition();
            if (horizontalBars) {
                if (axisPosition === 'top' || axisPosition === 'bottom') {
                    chartWidth -= axis.getThickness();
                }
            }
            else {
                if (axisPosition === 'left' || axisPosition === 'right') {
                    chartWidth -= axis.getThickness();
                }
            }
        }

        // Subtract inset paddings
        var insetPadding = chart.getInsetPadding();
        if (horizontalBars) {
            chartWidth -= insetPadding.top + insetPadding.bottom;
        }
        else {
            chartWidth -= insetPadding.left + insetPadding.right;
        }

        // Subtract inner paddings
        var innerPadding = chart.getInnerPadding();
        if (horizontalBars) {
            chartWidth -= innerPadding.top + innerPadding.bottom;
        }
        else {
            chartWidth -= innerPadding.left + innerPadding.right;
        }

        return chartWidth;
    }
});
