
Ext.define('Jda.SCExecutive.chart.series.RightRangeMarker', {
    extend: 'Ext.chart.series.Bar',

    alias: 'series.rightrangemarker',
    type: 'rightrangemarker',
    seriesType: 'rightrangemarkerSeries',

    config: {
        markerFieldNameSuffix: null
    },

    getDefaultSpriteConfig: function() {
        var config = this.callParent(arguments);
        
        config.chart = this.getChart();
        config.markerFieldNameSuffix = this.getMarkerFieldNameSuffix();

        return config;
    }
});
