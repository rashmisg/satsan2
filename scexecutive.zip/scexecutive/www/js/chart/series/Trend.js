
Ext.define('Jda.SCExecutive.chart.series.Trend', {
    extend: 'Ext.chart.series.Bar',

    alias: 'series.trend',
    type: 'trend',
    seriesType: 'trendSeries'
});
