
Ext.define('Jda.SCExecutive.chart.series.sprite.Trend', {
    extend: 'Ext.chart.series.sprite.Bar',

    alias: 'sprite.trendSeries',

    config: {
        trendField: 'trend' // default
    },

    renderClipped: function (surface, ctx, clip, clipRegion) {
        if (this.cleanRedraw) {
            return;
        }

        var attr = this.attr,
            dataX = attr.dataX,
            dataY = attr.dataY,
            dataText = attr.labels,
            dataStartY = attr.dataStartY,
            groupCount = attr.groupCount,
            groupOffset = attr.groupOffset - (groupCount - 1) * 0.5,
            inGroupGapWidth = attr.inGroupGapWidth,
            yLow, yHi,
            lineWidth = ctx.lineWidth,
            matrix = attr.matrix,
            xx = matrix.elements[0],
            yy = matrix.elements[3],
            dx = matrix.elements[4],
            dy = surface.roundPixel(matrix.elements[5]) - 1,
            maxBarWidth = xx - attr.minGapWidth,
            barWidth = surface.roundPixel(Math.max(attr.minBarWidth, (Math.min(maxBarWidth, attr.maxBarWidth) - inGroupGapWidth * (groupCount - 1)) / groupCount)),
            surfaceMatrix = this.surfaceMatrix,
            left, right, bottom, top, i, center,
            halfLineWidth = 0.5 * attr.lineWidth,
            start = Math.max(0, Math.floor(clip[0])),
            end = Math.min(dataX.length - 1, Math.ceil(clip[2])),
            arrowWidth = 10, trendField = this.getTrendField(), trend, record, extraConfig;

        for (i = start; i <= end; i++) {
            yLow = dataStartY ? dataStartY[i] : 0;
            yHi = dataY[i];

            center = dataX[i] * xx + dx + groupOffset * (barWidth + inGroupGapWidth);
            left = surface.roundPixel(center - barWidth / 2) + halfLineWidth;
            top = surface.roundPixel(yHi * yy + lineWidth + dy);
            right = surface.roundPixel(center + barWidth / 2) - halfLineWidth;
            bottom = surface.roundPixel(yLow * yy + lineWidth + dy);

            record = this.getStore().getAt(i);
            trend = record.get(trendField);

            if (attr.renderer) {
                extraConfig = attr.renderer(this, record, attr, i);

                if (extraConfig.fill) {
                    ctx.fillStyle = extraConfig.fill;
                }

                ctx.fillOpacity = extraConfig.fillOpacity; // this one seems to default to 1 if not set
            }

            ctx.beginPath();

            // Trending down arrow
            if (trend === 'down') {
                ctx.moveTo(center, bottom);
                ctx.lineTo(left, bottom + arrowWidth);
                ctx.lineTo(left, top);
                ctx.lineTo(right, top);
                ctx.lineTo(right, bottom + arrowWidth);
                ctx.lineTo(center, bottom);
            }
            // Trending up arrow
            else {
                ctx.moveTo(left, bottom);
                ctx.lineTo(left, top - arrowWidth);
                ctx.lineTo(center, top);
                ctx.lineTo(right, top - arrowWidth);
                ctx.lineTo(right, bottom);
                ctx.lineTo(left, bottom);
            }

            ctx.fill();
        }
    }
});
