
// rejiggered the renderClipped method of the area series sprite to create a series that
// extends the full width of the chart, instead of just the center of the data point
Ext.define('Jda.SCExecutive.chart.series.sprite.Threshold', {
    extend: 'Ext.chart.series.sprite.StackedCartesian',

    alias: 'sprite.thresholdSeries',

    renderClipped: function (surface, ctx, clip, clipRegion) {
        var me = this,
            attr = me.attr,
            dataX = attr.dataX,
            dataY = attr.dataY,
            dataStartY = attr.dataStartY,
            matrix = attr.matrix,
            x, y, i,
            xx = matrix.elements[0],
            dx = matrix.elements[4],
            yy = matrix.elements[3],
            dy = matrix.elements[5],
            start = Math.max(0, this.binarySearch(clip[0])),
            end = Math.min(dataX.length - 1, this.binarySearch(clip[2]) + 1);

        ctx.beginPath();

        for (i = start; i <= end; i++) {
            x = dataX[i] * (xx + dx);
            y = dataY[i] * yy + dy;

            ctx.lineTo(x, y);
        }

        for (i = end; i >= start; i--) {
            x = dataX[i] * (xx + dx);
            y = dataStartY[i] * yy + dy;

            ctx.lineTo(x, y);
        }

        ctx.fill();

        ctx.beginPath();

        for (i = start; i <= end; i++) {
            x = dataX[i] * (xx + dx);
            y = dataY[i] * (yy + dy);
            ctx.lineTo(x, y);
        }

        ctx.stroke();
    }
});
