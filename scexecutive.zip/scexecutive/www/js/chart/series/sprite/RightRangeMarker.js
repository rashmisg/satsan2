
Ext.define('Jda.SCExecutive.chart.series.sprite.RightRangeMarker', {
    extend: 'Ext.chart.series.sprite.Bar',
    alias: 'sprite.rightrangemarkerSeries',

    config: {
        chart: null,
        markerFieldNameSuffix: null
    },

    renderClipped: function (surface, ctx, clip) {
        if (this.cleanRedraw) {
            return;
        }
        var me = this,
            attr = me.attr,
            dataX = attr.dataX,
            dataY = attr.dataY,
            dataText = attr.labels,
            dataStartY = attr.dataStartY,
            groupCount = attr.groupCount,
            groupOffset = attr.groupOffset - (groupCount - 1) * 0.5,
            inGroupGapWidth = attr.inGroupGapWidth,
            yLow, yHi,
            lineWidth = ctx.lineWidth,
            matrix = attr.matrix,
            xx = matrix.elements[0],
            yy = matrix.elements[3],
            dx = matrix.elements[4],
            dy = surface.roundPixel(matrix.elements[5]) - 1,
            maxBarWidth = xx - attr.minGapWidth,
            barWidth = surface.roundPixel(Math.max(attr.minBarWidth, (Math.min(maxBarWidth, attr.maxBarWidth) - inGroupGapWidth * (groupCount - 1)) / groupCount)),
            surfaceMatrix = this.surfaceMatrix,
            left, right, bottom, top, i, center,
            halfLineWidth = 0.5 * attr.lineWidth,
            start = Math.max(0, Math.floor(clip[0])),
            end = Math.min(dataX.length - 1, Math.ceil(clip[2])),
            drawMarkers = dataText && !!this.getBoundMarker('labels');

        // BEGIN HACK

        // not sure how else to get the original range values, but they're being passed down as configs...
        var axes = this.getChart().getAxes();
        var leftRange = null;
        var rightRange = null;


        Ext.each(this.getChart().getAxes(), function(axis) {
            if (axis.getPosition() === 'left') {
                leftRange = axis.getRange();
            }
            else if (axis.getPosition() === 'right') {
                rightRange = axis.getRange();
            }
        });

        // END HACK

        for (i = start; i <= end; i++) {
            yLow = dataStartY ? dataStartY[i] : 0;
            yHi = dataY[i];

            center = dataX[i] * xx + dx + groupOffset * (barWidth + inGroupGapWidth);
            left = surface.roundPixel(center - barWidth / 2) + halfLineWidth;
            top = surface.roundPixel(yHi * yy + lineWidth + dy);
            right = surface.roundPixel(center + barWidth / 2) - halfLineWidth;
            bottom = surface.roundPixel(yLow * yy + lineWidth + dy);

            me.drawBar(ctx, surface, clip, left, top - halfLineWidth, right, bottom - halfLineWidth, i);

            if (drawMarkers && dataText[i]) {
                me.drawLabel(dataText[i], center, bottom, top, i);
            }

            // BEGIN HACK

            // currently expects the data field to have a prefix that can be used in conjunction with the markerFieldNameSuffix
            // to get the value for positioning the marker (e.g. west-latePercentage -> west-lateOrders)
            var fieldPrefix = this.getField().split('-')[0];
            var lateOrders = this.getStore().getAt(i).get(fieldPrefix + '-' + this.getMarkerFieldNameSuffix());

            // the scaling for this probably isn't 100% accurate, and i'm not sure what would
            // happen if the min values were 0s (if that would mess up the calculations)
            var scaleFromRightRangeToLeftRange = rightRange[1] / leftRange[1];
            var scaledLateOrders = lateOrders / scaleFromRightRangeToLeftRange;

            var newTop = surface.roundPixel(scaledLateOrders * yy + lineWidth + dy);

            // END HACK

            me.putMarker('markers', {
                translationX: surfaceMatrix.x(center, top),
                translationY: surfaceMatrix.y(center, newTop)
            }, i, true);
        }
    }
});
