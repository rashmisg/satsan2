// this custom series is necessary so that on charts like on time delivery, where there are stacked series, to make
// the line stretch across the entire chart.  this doesn't work on charts w/o stacked series though.  it would be
// nice for consistency puproses to find a way to do it consistently across charts
Ext.define('Jda.SCExecutive.chart.series.Threshold', {

    extend: 'Ext.chart.series.StackedCartesian',

    alias: 'series.threshold',
    type: 'threshold',
    seriesType: 'thresholdSeries'
});
