Ext.define('Jda.SCExecutive.chart.CartesianChart', {
    extend: 'Ext.chart.CartesianChart',

    loadFromModel: function(model) {
        var store = this.getStoreFromModel ? this.getStoreFromModel(model) : model.getStore();
        this._hideLabelAndGridLinesIfNoRecords(store);
    },

    loadFromStore: function(store) {
        this._hideLabelAndGridLinesIfNoRecords(store);
    },

    _hideLabelAndGridLinesIfNoRecords: function(store) {
        var hideLabelsAndGridLines = !store.getCount();
        Ext.Array.each(this.getAxes(), function(axis) {
            if (axis.getPosition() === 'left' || axis.getPosition() === 'right') {
                if (hideLabelsAndGridLines) {
                    axis.hideLabels();
                    axis.gridSurface.hide();
                }
                else {
                    axis.showLabels();
                    axis.gridSurface.show();
                }
            }
        });
    }
});