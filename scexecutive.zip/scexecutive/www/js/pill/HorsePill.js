Ext.define('Jda.SCExecutive.pill.HorsePill', {
    extend: 'Ext.Container',
    xtype: 'horsepill',

    config: {
        height: 44, // safe/default value per UX guidelines, since this control isn't (yet) meant to wrap lines

        good: 0, // just has to be a non (true|false) value, would prefer to use null, but then the updater won't be called
        text: null,
        detailText: null,

        layout: {
            type: 'hbox',
            align: 'center'
        },
        items: [{
            xtype: 'label',
            cls: 'horse-pill-text',
            itemId: 'horsePilltext'
        }, {
            xtype: 'label',
            flex: 1,
            cls: 'horse-pill-detail-text',
            itemId: 'horsePillDetailText'
        }]
    },

    initialize: function() {
        this.callParent(arguments);

        this.addCls('pill');
        this.addCls('horse');
    },

    updateGood: function(newGood) {
        var cls = 'unknown';

        if (newGood === true) {
            cls = 'good';
        }
        else if (newGood === false) {
            cls = 'bad';
        }

        this.setCls([ 'horse', 'pill', cls ]);
    },

    updateText: function(newText) {
        this.getComponent('horsePilltext').setHtml(newText);
    },

    updateDetailText: function(newDetailText) {
        this.getComponent('horsePillDetailText').setHtml(newDetailText);
    },

    displaySpendingTextForPeriod: function(value, periodHierarchy) {
        var timePeriodSpendingMessageString = 'jda.scexecutive.horsepill.';

        switch (periodHierarchy.get('type')) {
            case Jda.SCExecutive.model.PeriodHierarchy.types.WEEK:
                timePeriodSpendingMessageString += 'SpentForWeek';
                break;
            case Jda.SCExecutive.model.PeriodHierarchy.types.MONTH:
                timePeriodSpendingMessageString += 'SpentForMonth';
                break;
            case Jda.SCExecutive.model.PeriodHierarchy.types.QUARTER:
                timePeriodSpendingMessageString += 'SpentForQuarter';
                break;
            case Jda.SCExecutive.model.PeriodHierarchy.types.YEAR:
                timePeriodSpendingMessageString += 'SpentForYear';
                break;
        }

        var spendDisplayValue = Jda.SCExecutive.util.Formatters.MetricFormatter.formatCurrency(value);

        this.setText(spendDisplayValue);
        this.setDetailText(Jda.getMessage(timePeriodSpendingMessageString));
    },

    displayAverageTextForPeriod: function(value, periodHierarchy) {
        var timePeriodAverageMessageString = 'jda.scexecutive.horsepill.';
        switch (periodHierarchy.get('type')) {
            case Jda.SCExecutive.model.PeriodHierarchy.types.WEEK:
                timePeriodAverageMessageString += 'AverageForWeek';
                break;
            case Jda.SCExecutive.model.PeriodHierarchy.types.MONTH:
                timePeriodAverageMessageString += 'AverageForMonth';
                break;
            case Jda.SCExecutive.model.PeriodHierarchy.types.QUARTER:
                timePeriodAverageMessageString += 'AverageForQuarter';
                break;
            case Jda.SCExecutive.model.PeriodHierarchy.types.YEAR:
                timePeriodAverageMessageString += 'AverageForYear';
                break;
        }

        var averageDisplayValue = Jda.SCExecutive.util.Formatters.MetricFormatter.formatPercent(value);

        this.setText(averageDisplayValue);
        this.setDetailText(Jda.getMessage(timePeriodAverageMessageString));
    }
});
