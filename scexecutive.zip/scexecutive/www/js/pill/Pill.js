Ext.define('Jda.SCExecutive.pill.Pill', {
    extend: 'Ext.Component',
    xtype: 'pill',

    config: {
        height: 20, // safe/default value per UX guidelines, since this control isn't (yet) meant to wrap lines

        good: 0, // just has to be a non (true|false) value, would prefer to use null, but then the updater won't be called
        text: null
    },

    initialize: function() {
        this.callParent(arguments);

        this.addCls('pill');
    },

    updateGood: function(newGood) {
        var cls = 'unknown';

        if (newGood === true) {
            cls = 'good';
        }
        else if (newGood === false) {
            cls = 'bad';
        }

        this.setCls([ 'pill', cls ]);
    },

    updateText: function(newText) {
        this.setHtml(newText);
    }
});
