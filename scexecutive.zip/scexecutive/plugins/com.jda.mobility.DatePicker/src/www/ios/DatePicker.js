exports.show = function(options, callback) {
    window.datePicker.show(options, callback);
};
