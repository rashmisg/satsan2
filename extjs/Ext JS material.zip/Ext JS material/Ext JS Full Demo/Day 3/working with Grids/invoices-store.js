var invoiceStore = Ext.create('Ext.data.Store', {
    autoLoad: true,
    autoSync: true,
    pageSize: 10,
    //buffered: true,  // for large datasets
    model: 'Invoice',
    groupField: 'Client',
    proxy: {
        type: 'ajax',
        url: 'invoices.json',
        reader: {
            type: 'json',
            root: 'rows'
        },
        writer: {
            type: 'json',
            writeAllFields: false
        }
    }
});
