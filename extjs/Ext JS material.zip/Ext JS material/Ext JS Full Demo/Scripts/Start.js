﻿Ext.onReady(function(){
    Ext.MessageBox.show(
        {
            "Title": "welcome to Ext JS",
            "msg": "welcome to ExtJS",
            buttons: Ext.MessageBox.OK
        });
   
    

    //Ext.get('mb1').on('click', function (e) {
    //    Ext.MessageBox.confirm('Confirm', 'Are you sure you want to do that?', showResult);
    //});
   
});
