describe('hello Ext test', function () {

  var greeter;
  beforeEach(function () {
    greeter = new Greeter();
  });


    // Assert
  it('should say hello to the Ext JS', function () {
    expect(greeter.say('Ext')).toEqual('Hello, Ext');
  });
});