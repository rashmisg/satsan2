﻿Ext.define("MVCProject.controller.LoginController", {
    extend: "Ext.app.Controller",
    refs: [
    { ref: "userName", selector: "login textfield[id=usernametext]" },
    { ref: "password", selector: "#passwordtext" }
    ],
    views: ["LoginScreen"],
    init: function () {
        this.control({
            "#loginbutton": {
                click: this.authenticate
            }
        });
    },
    authenticate: function () {
        if (this.getUserName().getValue() == "murthy" &&
        this.getPassword().getValue() == "welcome") {
           // Ext.Msg.alert("Welcome to MVC Project");
            this.application.viewport.add({ xtype: "home", id: "homescreen" });
            // dynamically add homescreen view
           // this.application.viewport.getLayout().setActiveItem(1); // set z-index as 1
        }
        else
            Ext.Msg.alert("Invalid credentials");
    }
});