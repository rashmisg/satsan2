﻿//Home controller
Ext.define("MVCProject.controller.HomeController", {
    extend: "Ext.app.Controller",
    id: "HomeController",
    refs: [
   // configure  views
    { ref: "projectactionitemgrid", selector: "home grid" },
    { ref: "projectactionitemdetails", selector: "home form" } 
    ],
    // configure Models and stores
    models: ["ProjectActionItem"],
    stores: ["ProjectActionItemStore"],
    views: ["home.ProjectActionItemDetailsPanel", "home.ProjectActionItemGrid", "home.HomeScreen"],
    init: function () {
        this.control({
            "home form": {
              
                beforerender: this.loadProjectActionItems
                // see below  callback function code
            },

            "home grid": {
                itemclick: this.displayProjectActionItemDetails
                // see below callback function code
            }
        });
    },
    displayProjectActionItemDetails: function (src, record) {
        this.getprojectactionitemdetails().loadRecord(record);
       
    },

    // callback 
     loadProjectActionItems: function () {
            //to access the ProjectActionItemStore instance (if not existing, new one is created  (global/singleton)
            var store = Ext.getStore("ProjectActionItemStore");
            store.load(); // load data

         //The ProjectActionItemStore instance is wired up to the grid using the reconfigure() method.
           
          //this.getActionItemsGrid().reconfigure(store);// like refresh and bind
        }
    
});

