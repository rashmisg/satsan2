﻿Ext.define("MVCProject.model.ProjectActionItem", {
    extend: "Ext.data.Model",
    fields: ["sno", "item", "officer", "status", "createdby", "createddate"]
});