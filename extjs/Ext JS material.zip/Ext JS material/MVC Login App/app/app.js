﻿Ext.Loader.setConfig({ enabled: true });
// enable loading of model, controller and views
Ext.application({
    name: "MVCProject", // root namespace
    appFolder: "app",
    controllers: ["LoginController", "HomeController"],  // configure controllers as array
    launch: function () {
        // you can access the Viewport instance from anywhere in the application by writing this.application.viewport
        this.viewport = Ext.create("Ext.container.Viewport", {
            renderTo: Ext.getBody(),
            layout: "card",
            items: [
            {
               // create an instance of the LoginScreen(.js) and add it to the Viewport
                xtype: "login"
            }
            ]
        });
    }
});