﻿Ext.define("MVCProject.view.LoginScreen", {
    extend: "Ext.form.Panel",
    xtype: "login",
    layout: {
        type : "hbox",
        pack : "center",
        align : "middle"
    },
    defaults : {margin:5},
    title: "MVC  Application",
    titleAlign: "center",
    padding : 250,
    items: [
    {
        xtype: "textfield",
        id: "usernametext",
        fieldLabel: "User name"
    },
    {
        xtype: "textfield",
        id: "passwordtext",
        fieldLabel: "Password",
        inputType: "password"
    },
    {
        xtype: "button",
        id: "loginbutton",  // see LoginController.jsfor event handling
        text: "Login"
    }
    ]
});