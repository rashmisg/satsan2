﻿Ext.define("MVCProject.store.ProjectActionItemStore", {
    extend: "Ext.data.Store",
    model: "MVCProject.model.ProjectActionItem",
    proxy: {
        type: "ajax",
        url: "ActionItems.json",
        reader: {
            type: "json",
            root: "actionitems"
        }
    }
});