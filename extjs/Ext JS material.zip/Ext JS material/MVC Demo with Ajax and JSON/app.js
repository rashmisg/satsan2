Ext.application({
  name: 'Application',
  // Automatically create an instance of Viewport
  // on application launch
  autoCreateViewport: true,
  // Attach controllers
  controllers: ['ItemController']
});