Ext.define('Application.model.Item', {
  extend: 'Ext.data.Model',
  fields: ['item_id', 'name', 'description']
});